import m from 'mithril';
import { isJSONObject as isJSONObject$1 } from '@occultist/mini-jsonld';
import { JsonPointer } from 'json-ptr';
import uriTemplates from 'uri-templates';
import { processTemplate } from '@longform/longform';

/**
  * Creates an Octiron selection instance.
  *
  * @param args - User specified args passed to the Octiron method creating the factory.
  * @param parentArgs - Args passed from the Octiron parent instance of this instance.
  * @param rendererArgs - Args passed from the Mithril renderer component.
  */
function selectionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign({}, args);
    const childArgs = {
        // value: parentArgs.value,
        value: rendererArgs.value,
    };
    const self = octironFactory('selection', {
        factoryArgs,
        parentArgs,
        rendererArgs,
        childArgs,
    });
    return self;
}

/**
 * @description
 * Returns a component based of Octiron's selection rules:
 *
 * 1. If the first pick component is given, return it.
 * 2. If a typedef is defined for the propType (jsonld term or type)
 *    for the given style, return it.
 * 3. If a typedef is defined for the (or one of the) types (jsonld '@type')
 *    value for the given style, return it.
 * 4. If a fallback component is given, return it.
 *
 * @param args.style - The style of presentation.
 * @param args.propType - The propType the component should be configured to
 *                        handle.
 * @param args.type - The type the component should be configured to handle.
 * @param args.firstPickComponent - The component to use if passed by upstream.
 * @param args.fallbackComponent - The component to use if no other component
 *                                 is picked.
 */
function getComponent({ style, propType, type, firstPickComponent, typeHandlers, fallbackComponent, }) {
    if (firstPickComponent != null) {
        return firstPickComponent;
    }
    if (propType != null &&
        typeHandlers[propType]?.[style] != null) {
        return typeHandlers[propType][style];
    }
    if (!Array.isArray(type) &&
        type != null &&
        typeHandlers[type]?.[style] != null) {
        return typeHandlers[type][style];
    }
    if (Array.isArray(type)) {
        for (const item of type) {
            if (typeHandlers[item]?.[style] != null) {
                return typeHandlers[item][style];
            }
        }
    }
    if (fallbackComponent != null) {
        return fallbackComponent;
    }
}

/**
 * @description
 * Returns true if the input value is an object.
 *
 * @param value Any value which should come from a JSON source.
 */
function isJSONObject(value) {
    return typeof value === 'object' && !Array.isArray(value) && value !== null;
}

/**
 * @description
 * Returns true if the given value is a JSON object with a JSON-ld @type value.
 *
 * @param value Any value which should come from a JSON source.
 */
function isTypeObject(value) {
    if (!isJSONObject(value)) {
        return false;
    }
    else if (typeof value['@type'] === 'string') {
        return true;
    }
    else if (!Array.isArray(value['@type'])) {
        return false;
    }
    for (const item of value['@type']) {
        if (typeof item !== 'string') {
            return false;
        }
    }
    return true;
}

/**
 * @description
 * Returns the type value of the input if it is a type object.
 *
 * @param value A JSON value which might be a typed JSON-ld object.
 */
function getDataType(value) {
    if (isTypeObject(value)) {
        return value['@type'];
    }
}

/**
 * Selects the component and attrs to render with from args provided to an Octiron
 * factory instance or the render method.
 */
const selectComponentFromArgs = (style, parentArgs, rendererArgs, args, factoryArgs) => {
    const attrs = Object.assign({}, args?.attrs ?? factoryArgs?.attrs);
    // null for a component arg indicates this is being called by a `o.default()` method
    // which will cause infinite recursion if it ends up re-selecting itself via factory args.
    const firstPickComponent = (args?.component ?? (args?.component !== null ? factoryArgs?.component : null));
    const fallbackComponent = (args?.fallbackComponent ?? (args?.component !== null ? factoryArgs?.fallbackComponent : null));
    const component = getComponent({
        style,
        propType: rendererArgs?.propType,
        type: getDataType(rendererArgs.value),
        firstPickComponent,
        fallbackComponent,
        typeHandlers: args?.typeHandlers ?? parentArgs.typeHandlers,
    });
    return [attrs, component];
};

const EditRenderer = ({ attrs: { args, factoryArgs, parentArgs, rendererArgs, }, }) => {
    const [attrs, component] = selectComponentFromArgs('edit', parentArgs, rendererArgs, args, factoryArgs);
    return {
        view({ attrs: { o, rendererArgs }, children }) {
            if (component == null) {
                return null;
            }
            // deno-lint-ignore no-explicit-any
            return m(component, {
                o,
                attrs,
                renderType: "edit",
                name: o.inputName,
                value: rendererArgs.value,
                spec: rendererArgs.spec,
                onchange: rendererArgs.update,
                onChange: rendererArgs.update,
            }, children);
        },
    };
};

/**
 * Expands a object's keys to be their RDF type equivlent.
 *
 * @param store   - An Octiron store with expansion context.
 * @param value   - A JSON object to expand.
 */
function expandValue(store, value) {
    let expanded = Object.create(null);
    for (let [key, item] of Object.entries(value)) {
        if (item != null) {
            expanded[store.expand(key)] = item;
        }
    }
    return expanded;
}

/**
 * @description
 * Returns true if a json-ld value is an array or has an iterable value,
 * i.e.: an object with an `@list` or `@set` array value.
 *
 * This function returns an empty array in the cases where a non-iterable value
 * is given.
 *
 * @param {JSONValue} value - A json-ld value
 */
function getIterableValue(value) {
    if (Array.isArray(value)) {
        return value;
    }
    else if (Array.isArray(value['@list'])) {
        return value['@list'];
    }
    else if (Array.isArray(value['@set'])) {
        return value['@set'];
    }
    return [];
}

/**
 * @description
 * Returns true if a json-ld value is an array or has an iterable value,
 * i.e.: an object with an `@list` or `@set` array value.
 *
 * @param {JSONValue} value - A json-ld value
 */
function isIterable(value) {
    if (Array.isArray(value)) {
        return true;
    }
    else if (isJSONObject(value)) {
        if (Array.isArray(value["@list"])) {
            return true;
        }
        else if (Array.isArray(value["@set"])) {
            return true;
        }
    }
    return false;
}

const isBrowserRender = typeof window !== 'undefined';

/**
 * @description
 * Calls Mithril's redraw function if the window object exists.
 */
function mithrilRedraw() {
    if (isBrowserRender) {
        m.redraw();
    }
}

/**
 * @description
 * Numerous Octiron view functions take a combination of string selector,
 * object args and function view arguments.
 *
 * This `unravelArgs` identifies which arguments are present and returns
 * defaults for the missing arguments.
 *
 * @param arg1 - A selector string, args object or view function if present.
 * @param arg2 - An args object or view function if present.
 * @param arg3 - A view function if present.
 */
function unravelArgs(arg1, arg2, arg3) {
    let selector;
    let args = {};
    let view;
    if (typeof arg1 === "string") {
        selector = arg1;
    }
    else if (typeof arg1 === "function") {
        view = arg1;
    }
    else if (arg1 != null) {
        args = arg1;
    }
    if (typeof arg2 === 'function') {
        view = arg2;
    }
    else if (arg2 != null) {
        args = arg2;
    }
    if (typeof arg3 === 'function') {
        view = arg3;
    }
    if (typeof view === "undefined") {
        view = ((o) => o.default(args));
    }
    return [
        selector,
        args,
        view,
    ];
}

function actionSelectionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign({}, args);
    const childArgs = {
        action: parentArgs.action,
        submitting: parentArgs.submitting,
        value: rendererArgs.value,
    };
    const refs = {
        factoryArgs,
        parentArgs,
        rendererArgs,
        childArgs,
    };
    const self = octironFactory('action-selection', refs);
    self.readonly = rendererArgs.spec == null ? true : (rendererArgs.spec.readonly ?? false);
    self.inputName = rendererArgs.spec?.name != null ? rendererArgs.spec?.name : rendererArgs.propType;
    self.submitting = parentArgs.submitting;
    self.action = parentArgs.action;
    childArgs.updatePointer = (pointer, value, args, interceptor = factoryArgs.interceptor) => {
        const prev = refs.rendererArgs.value;
        if (!isJSONObject(prev)) {
            console.warn(`Non object action change intercepted.`);
            return;
        }
        let next = Object.assign({}, prev);
        const ptr = JsonPointer.create(pointer);
        if (value == null) {
            ptr.unset(next);
        }
        else {
            ptr.set(next, value, true);
        }
        if (typeof interceptor === 'function') {
            next = interceptor({
                next,
                prev,
                o: self,
                actionValue: self.actionValue.value,
            });
            if (next === false)
                return;
        }
        refs.parentArgs.updatePointer(refs.rendererArgs.pointer, next, args);
    };
    self.update = async (arg1, args) => {
        const value = refs.rendererArgs.value;
        if (!isJSONObject(value)) {
            throw new Error(`Cannot call update on a non object selection instance`);
        }
        if (typeof arg1 === 'function') {
            refs.rendererArgs.update(arg1(value));
        }
        else if (arg1 != null) {
            refs.rendererArgs.update(arg1);
        }
        if (args?.submit || args?.submitOnChange) {
            await refs.parentArgs.submit();
        }
        else {
            mithrilRedraw();
        }
    };
    self.submit = () => {
        return refs.parentArgs.submit();
    };
    self.select = (arg1, arg2, arg3) => {
        if (!isJSONObject(refs.rendererArgs.value)) {
            return null;
        }
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(ActionSelectionRenderer, {
            parentArgs: childArgs,
            selector,
            value: refs.rendererArgs.value,
            actionValue: refs.rendererArgs.actionValue.value,
            args,
            view,
        });
    };
    self.edit = (args) => {
        if (self.readonly) {
            return self.present(args);
        }
        return m(EditRenderer, {
            o: self,
            args,
            factoryArgs,
            parentArgs: refs.parentArgs,
            rendererArgs: refs.rendererArgs,
        });
    };
    self.default = (args) => {
        return self.edit(Object.assign({ component: null }, args));
    };
    self.initial = parentArgs.action.initial;
    self.success = parentArgs.action.success;
    self.failure = parentArgs.action.failure;
    self.remove = (_args = {}) => {
        if (refs.rendererArgs.propType == null) {
            return;
        }
        const parentValue = refs.parentArgs.parent.value;
        const value = parentValue[refs.rendererArgs.propType];
        if (isIterable(value)) {
            const arrValue = getIterableValue(value);
            arrValue.splice(self.index, 1);
            if (arrValue.length === 0) {
                delete parentValue[refs.rendererArgs.propType];
            }
        }
        else if (isJSONObject(value)) {
            delete parentValue[refs.rendererArgs.propType];
        }
        mithrilRedraw();
    };
    self.append = (termOrType, value = {}, args = {}) => {
        if (!isJSONObject(refs.rendererArgs.value)) {
            console.warn(`Attempt to append to non object octiron selection ${termOrType}`);
            return;
        }
        let nextValue;
        const type = refs.parentArgs.store.expand(termOrType);
        const lastValue = refs.rendererArgs.value[type];
        if (isJSONObject(value)) {
            value = expandValue(self.store, value);
        }
        if (lastValue == null) {
            nextValue = value;
        }
        else if (Array.isArray(lastValue)) {
            nextValue = [...lastValue, value];
        }
        else {
            nextValue = [lastValue, value];
        }
        return refs.parentArgs.updatePointer(refs.rendererArgs.pointer, Object.assign({}, refs.rendererArgs.value, { [type]: nextValue }), args);
    };
    return self;
}

/**
 * @description
 * Espects a list of json pointer parts and returns a json pointer.
 */
function escapeJSONPointerParts(...parts) {
    const escaped = parts
        .map((part) => part.replace(/~/g, '~0').replace(/\//g, '~1'))
        .join('/');
    return `${escaped}`;
}

/**
 * @description
 * Returns true if the given value is a JSON object with a JSON-ld @id value.
 *
 * @param value Any value which should come from a JSON source.
 */
function isIRIObject(value) {
    return isJSONObject(value)
        && typeof value['@id'] === 'string'
        && value['@id'] !== '';
}

/**
 * @description
 * Some JSON-ld objects contain special JSON-ld values, such as @type which
 * can inform the software on what to expect when retrieving the object but
 * otherwise require fetching an entity from an endpoint to get the values
 * they relate to. For Octiron's purposes these are considered metadata objects.
 *
 * Objects containing `@value`, `@list`, `@set` are not considered metadata
 * objects as these properties references concrete values.
 *
 * @param value - The JSON object to check for non special properties in.
 */
function isMetadataObject(value) {
    const keys = Object.keys(value);
    if (keys.length === 0) {
        return false;
    }
    for (const term of keys) {
        if (!term.startsWith("@") ||
            term === '@value' ||
            term === '@list' ||
            term === '@set') {
            return false;
        }
    }
    return true;
}

/**
 * @description
 * A value object contains a `@value` value. Often this is used to provide
 * further information about the value like what `@type` it holds, allowing
 * filters to be applied to the referenced value.
 *
 * @param value - A JSON value.
 */
function isValueObject(value) {
    return typeof value['@value'] !== 'undefined';
}

const selectorRe = /\s*(?<subject>([^\[\s]+))(\[(?<filter>([^\]])+)\])?\s*/g;
/**
 * @description
 * Parses a selector string producing a selector list
 * The subject value of a selector could be an iri or a type depending on the
 * outer context.
 *
 * @param selector - The selector string to parse.
 */
function parseSelectorString(selector, store) {
    let match;
    const selectors = [];
    while ((match = selectorRe.exec(selector))) {
        const subject = match.groups?.subject;
        const filter = match.groups?.filter;
        if (typeof filter === 'string' && typeof subject === 'string') {
            selectors.push({
                subject: subject === '@id' ? '@id' : store.expand(subject),
                filter,
            });
        }
        else if (typeof subject === 'string') {
            selectors.push({
                subject: subject === '@id' ? '@id' : store.expand(subject),
            });
        }
        else {
            throw new Error(`Invalid selector: ${selector}`);
        }
    }
    return selectors;
}

const httpRe = /^https?\:\/\//;
const scmCtxRe = /^https?\:\/\/schema\.org/;
const scmTypeRe = /^https?\:\/\/schema\.org\/(?<term>(readonlyValue|valueName|valueRequired|defaultValue|minValue|maxValue|stepValue|valuePattern|multipleValues|valueMinLength|valueMaxLength))/;
function resolvePropertyValueSpecification({ spec, store, }) {
    const pvs = {
        readonlyValue: false,
        valueRequired: false,
    };
    let scmAlias;
    const scmVocab = store.vocab == null ? false : scmCtxRe.test(store.vocab);
    for (const [key, value] of Object.entries(store.aliases)) {
        if (scmCtxRe.test(value)) {
            scmAlias = [key, value];
            break;
        }
    }
    for (const [term, value] of Object.entries(spec)) {
        let type;
        if (!httpRe.test(term)) {
            if (scmVocab && !term.includes(':')) {
                type = `${store.vocab}${term}`;
            }
            else if (scmAlias && term.startsWith(`${scmAlias[0]}:`)) {
                type = term.replace(`${scmAlias[0]}:`, scmAlias[1]);
            }
        }
        else {
            type = term;
        }
        if (!type) {
            continue;
        }
        const result = scmTypeRe.exec(type);
        if (result?.groups?.term) {
            pvs[result.groups.term] = value;
        }
    }
    return {
        readonly: pvs.readonlyValue,
        required: pvs.valueRequired,
        name: pvs.valueName,
        min: pvs.minValue,
        max: pvs.maxValue,
        step: pvs.stepValue,
        pattern: pvs.valuePattern,
        multiple: pvs.multipleValues,
        minLength: pvs.valueMinLength,
        maxLength: pvs.valueMaxLength,
    };
}

/**
 * A circular selection error occurs when two or more
 * entities contain no concrete values and their '@id'
 * values point to each other in a way that creates a
 * loop. The `getSelection` function will throw when
 * this scenario is detected to prevent an infinite
 * loop.
 */
class CircularSelectionError extends Error {
}
/**
 * @description
 * Selects from the given context value and store state.
 *
 * If no `value` is provided the `selector` is assumed to begin with an iri
 * instead of a type. An entity will be selected from the store using the iri,
 * if it exists, to begin the selection.
 *
 * A type selector selects values from the context of a provided value
 * and will pull from the store if any iri objects are selected in the process.
 *
 * @param {string} args.selector            Selector string beginning with a type.
 * @param {string} [args.fragment]          A fragment if passed in as select args.
 * @param {JSONObject} [args.value]         Context object to begin the selection from.
 * @param {JSONObject} [args.actionValue]   The action, or point in the action definition which describes this value.
 * @param {JSONValue} [args.defaultValue]   A default value when used to select action values.
 * @param {Store} args.store                Octiron store to search using.
 * @returns {SelectionDetails}              Selection contained in a details object.
 */
function getSelection({ selector: selectorStr, value, fragment, accept, actionValue, defaultValue, store, }) {
    const details = {
        selector: selectorStr,
        complete: false,
        isProblem: false,
        hasErrors: false,
        hasMissing: false,
        required: [],
        dependencies: [],
        result: [],
    };
    if (value == null) {
        const [{ subject, filter }, ...selector] = parseSelectorString(selectorStr, store);
        const [iri, iriFragment] = subject.split('#');
        selectEntity({
            pointer: '',
            iri,
            fragment: iriFragment ?? fragment,
            accept,
            filter,
            selector: selector.length > 0 ? selector : undefined,
            store,
            details,
        });
        details.complete = details.required.length === 0;
        return details;
    }
    const selector = parseSelectorString(selectorStr, store);
    traverseSelector({
        key: '',
        pointer: '',
        value,
        actionValue,
        selector,
        store,
        details,
        defaultValue,
    });
    details.complete = details.required.length === 0;
    return details;
}
function makePointer(pointer, addition) {
    return `${pointer}/${escapeJSONPointerParts(addition.toString())}`;
}
function updateKey(key, addition) {
    return `${key}[${addition}]`;
}
/**
 * Filters apply to objects with `@type` properties. These can be strings or
 * arrays of strings and are considered a pass if any of the values match the
 * filter.
 *
 * If an object is provided which does not contain an `@type` property it is
 * considered a fail.
 */
function passesFilter({ value, filter, }) {
    if (typeof filter !== 'string') {
        return true;
    }
    if (Array.isArray(value['@type'])) {
        return value['@type'].includes(filter);
    }
    return value['@type'] === filter;
}
/**
 * If a scala value is pulled before a selection is complete the branch
 * can exit early.
 */
function isTraversable(value) {
    return (value !== null &&
        typeof value !== 'boolean' &&
        typeof value !== 'number' &&
        typeof value !== 'string');
}
/**
 * Handles the final value found in a selection.
 * If a @id, @value jsonld object is provided further
 * recursion might be nessacary.
 */
function resolveValue({ key, pointer, value, propType, filter, spec, actionValue, store, details, }) {
    if (value === undefined) {
        details.hasMissing = true;
        return;
    }
    else if (value === null && isJSONObject(actionValue)) {
        for (const item of Object.values(actionValue)) {
            if (isTypeObject(item) && item["@type"] === 'https://schema.org/PropertyValueSpecification') {
                return;
            }
        }
    }
    if (spec != null && (
    // hit the for loop below if the action value
    // has editable properties and the value is an
    // array
    !isIterable(value) || !isJSONObject(actionValue))) {
        const pvs = resolvePropertyValueSpecification({
            spec,
            store,
        });
        if (isJSONObject(value) && isValueObject(value)) {
            value = value['@value'];
        }
        details.result.push({
            key,
            pointer,
            type: 'action-value',
            propType,
            value,
            actionValue,
            spec: pvs,
            readonly: pvs.readonly,
        });
        return;
    }
    if (!isTraversable(value)) {
        details.result.push({
            key,
            pointer: pointer,
            type: 'value',
            propType,
            value,
            readonly: true,
        });
        return;
    }
    else if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            let finalKey = key;
            const item = list[index];
            if (!isIRIObject(item)) {
                finalKey = updateKey(key, index);
            }
            else {
                finalKey = item['@id'];
            }
            resolveValue({
                key: finalKey,
                pointer: makePointer(pointer, index),
                value: item,
                spec,
                actionValue,
                propType,
                filter,
                store,
                details,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    if (typeof filter === 'string' && !passesFilter({ value, filter })) {
        return;
    }
    if (isValueObject(value)) {
        resolveValue({
            key,
            pointer,
            value: value['@value'],
            propType,
            store,
            details,
        });
        return;
    }
    else if (isMetadataObject(value)) {
        selectEntity({
            pointer,
            iri: value['@id'],
            filter,
            store,
            details,
        });
        return;
    }
    if (isIRIObject(value)) {
        const iri = value['@id'];
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri,
            ok: true,
            value,
        });
        return;
    }
    details.result.push({
        key,
        pointer,
        type: 'value',
        readonly: true,
        propType,
        value,
    });
}
/**
 * Selects a type from a json value, handling invalid situations.
 */
function selectTypedValue({ key, pointer, propType, value, actionValue, filter, store, details, }) {
    pointer = makePointer(pointer, propType);
    if (!isTraversable(value)) {
        return;
    }
    if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = updateKey(key, index);
            }
            selectTypedValue({
                key,
                pointer: makePointer(pointer, index),
                propType,
                value: item,
                actionValue,
                filter,
                store,
                details,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    if (isMetadataObject(value) && isIRIObject(value)) {
        selectEntity({
            pointer,
            iri: value['@id'],
            selector: [{ subject: propType, filter }],
            store,
            details,
        });
        return;
    }
    else if (isMetadataObject(value)) {
        return;
    }
    let spec;
    if (isJSONObject(actionValue) && actionValue[`${propType}-input`] == null) {
        // selecting for an action but the type is not editable
        return;
    }
    else if (isJSONObject(actionValue)) {
        spec = actionValue[`${propType}-input`];
    }
    resolveValue({
        key,
        pointer,
        value: value[propType],
        spec,
        actionValue: actionValue?.[propType],
        propType,
        filter,
        store,
        details,
    });
}
/**
 * Recurses through the selection until there are no further selection items.
 */
function traverseSelector({ key, pointer, selector, value, actionValue, store, details, defaultValue, }) {
    if (selector.length === 0) {
        return;
    }
    else if (!isTraversable(value)) {
        return;
    }
    if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = updateKey(key, index);
            }
            // keep nesting on the full selector
            // as only objects can be subscripted
            // with propTypes
            traverseSelector({
                key,
                pointer: makePointer(pointer, index),
                selector,
                value: item,
                actionValue,
                store,
                details,
                defaultValue,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    else if (isValueObject(value)) {
        traverseSelector({
            key,
            pointer,
            selector,
            value: value['@value'],
            actionValue,
            store,
            details,
            defaultValue,
        });
    }
    if (isMetadataObject(value) && isIRIObject(value)) {
        selectEntity({
            pointer,
            selector,
            iri: value['@id'],
            store,
            details,
        });
        return;
    }
    // edit selections are a special case in that an input
    // should render even when no value is present.
    if (isJSONObject(value) &&
        actionValue !== undefined &&
        value[selector[0].subject] == null) {
        value = { [selector[0].subject]: defaultValue ?? null };
    }
    const [next, ...rest] = selector;
    const { subject: propType, filter } = next;
    // null is a placeholder for action payload types with no value.
    // jsonld drops null values otherwise.
    if (value[propType] === undefined) {
        details.hasMissing = true;
        return;
    }
    if (rest.length === 0 && isJSONObject(actionValue?.[propType])) {
        pointer = makePointer(pointer, propType);
        resolveValue({
            key: updateKey(key, propType),
            pointer,
            value: value[propType],
            propType,
            details,
            store,
            actionValue: actionValue?.[propType],
            spec: actionValue[`${propType}-input`],
            filter,
        });
        return;
    }
    else if (rest.length === 0) {
        selectTypedValue({
            key,
            pointer,
            propType: propType,
            filter,
            value,
            actionValue,
            store,
            details,
        });
        return;
    }
    if (typeof filter === 'string' && !passesFilter({ value, filter })) {
        return;
    }
    let traversedActionValue;
    if (isJSONObject(actionValue?.[propType])) {
        traversedActionValue = actionValue[propType];
    }
    traverseSelector({
        key: updateKey(key, propType),
        pointer: makePointer(pointer, propType),
        selector: rest,
        value: value[propType],
        actionValue: traversedActionValue,
        store,
        details,
    });
}
/**
 * Selects an entity from the store and continues the selection
 * if the branch has not completed.
 */
function selectEntity({ pointer, iri, fragment, accept, filter, selector, store, details, handledIRIs, }) {
    const normalizedURL = new URL(iri).toString();
    // reset the key for entities.
    // this creates duplicates if an iri is used twice in a response at the
    // same level of the selection. I see this as being unlikely, so a problem
    // to solve later...
    const key = normalizedURL;
    pointer = makePointer(pointer, normalizedURL);
    const cache = store.entity(normalizedURL, accept);
    details.dependencies.push(normalizedURL);
    // if loading is required mark found as false
    if (cache == null || cache.loading) {
        if (!details.required.includes(normalizedURL)) {
            details.required.push(normalizedURL);
            details.accept = accept;
            details.fragment = fragment;
        }
        return;
    }
    if (!cache.ok) {
        details.hasErrors = true;
        details.isProblem = cache.isProblem;
        if (selector == null || selector.length === 0) {
            return;
        }
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri: cache.iri,
            ok: false,
            status: cache.status,
            value: cache.value,
            reason: cache.reason,
            contentType: cache.contentType,
        });
        return;
    }
    if (cache.type === 'alternative-success') {
        details.result.push({
            key,
            pointer,
            iri: cache.iri,
            fragment,
            ok: cache.ok,
            status: cache.status,
            type: 'alternative',
            contentType: cache.integration.contentType,
            integration: cache.integration,
            accept,
        });
        return;
    }
    const value = cache.value;
    if (isMetadataObject(value)) {
        // in theory several entities could be metadata objects
        // referencing each other and end up looping around...
        if (handledIRIs == null) {
            handledIRIs = new Set([value['@id']]);
        }
        else if (!handledIRIs.has(value['@id'])) {
            handledIRIs.add(value['@id']);
        }
        else {
            throw new CircularSelectionError(`Circular selection loop detected`);
        }
        // select the entity this entity is referencing
        return selectEntity({
            pointer,
            iri: value['@id'],
            filter,
            selector,
            details,
            store,
            handledIRIs,
        });
    }
    // if the entity does not match the filter it is not relevant to the final selection
    if (typeof filter === 'string' && !passesFilter({ filter, value })) {
        return;
    }
    if (typeof selector === 'undefined') {
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri: cache.iri,
            ok: true,
            value: cache.value,
            contentType: cache.contentType,
        });
        return;
    }
    traverseSelector({
        key,
        pointer,
        value,
        selector,
        store,
        details,
    });
    return;
}

function cachePrev(attrs) {
    return {
        selector: attrs.selector,
        value: attrs.value,
        actionValue: attrs.actionValue,
        args: {
            fragment: attrs.args.fragment,
        },
        parentArgs: {
            store: attrs.parentArgs.store,
        },
    };
}
function shouldReselect(next, prev) {
    return next.parentArgs.store !== prev.parentArgs.store ||
        next.selector !== prev.selector ||
        next.args.fragment !== prev.args.fragment ||
        next.value !== prev.value;
}
const ActionSelectionRenderer = (vnode) => {
    let currentAttrs = vnode.attrs;
    let details;
    let prev;
    const instances = new Map();
    function createInstances() {
        let hasChanges = false;
        const { parentArgs, selectionArgs } = currentAttrs;
        const nextKeys = [];
        for (let index = 0; index < details.result.length; index++) {
            const selectionResult = details.result[index];
            nextKeys.push(selectionResult.pointer);
            if (instances.has(selectionResult.pointer)) {
                const { rendererArgs, octiron } = instances.get(selectionResult.pointer);
                const update = (value) => {
                    return parentArgs.updatePointer(selectionResult.pointer, value, selectionArgs);
                };
                rendererArgs.value = octiron.value = selectionResult.value;
                rendererArgs.spec = selectionResult.spec;
                rendererArgs.update = update;
                continue;
            }
            hasChanges = true;
            const update = (value) => {
                return parentArgs.updatePointer(selectionResult.pointer, value, selectionArgs);
            };
            const actionValueRendererArgs = {
                index,
                value: selectionResult.actionValue,
                propType: selectionResult.propType,
            };
            const actionValue = selectionFactory(currentAttrs.args, parentArgs, actionValueRendererArgs);
            const rendererArgs = {
                index,
                update,
                actionValue,
                pointer: selectionResult.pointer,
                propType: selectionResult.propType,
                value: selectionResult.value,
                spec: selectionResult.spec,
            };
            const actionSelection = actionSelectionFactory(currentAttrs.args, parentArgs, rendererArgs);
            instances.set(selectionResult.pointer, {
                rendererArgs,
                selection: actionValue,
                octiron: actionSelection,
                selectionResult,
            });
        }
        const prevKeys = instances.keys();
        for (const key of prevKeys) {
            if (!nextKeys.includes(key)) {
                hasChanges = true;
                instances.delete(key);
            }
        }
        if (hasChanges && typeof window !== 'undefined') {
            mithrilRedraw();
        }
    }
    function updateSelection() {
        const { selector, value, actionValue } = currentAttrs;
        const { store } = currentAttrs.parentArgs;
        if (!isJSONObject(value)) {
            return;
        }
        details = getSelection({
            selector,
            store,
            actionValue,
            value,
            defaultValue: currentAttrs.args.initialValue,
        });
        createInstances();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            prev = cachePrev(attrs);
            updateSelection();
        },
        onbeforeupdate: ({ attrs }) => {
            const reselect = shouldReselect(attrs, prev);
            currentAttrs = attrs;
            if (reselect) {
                updateSelection();
            }
            else {
                for (const instance of instances.values()) {
                    instance.octiron._updateArgs(attrs.args);
                }
            }
        },
        view: ({ attrs: { view, args } }) => {
            if (details == null) {
                return null;
            }
            const { pre, sep, post, fallback, } = args;
            if (typeof view === 'undefined') {
                return;
            }
            const list = Array.from(instances.values());
            const children = [pre];
            for (let index = 0; index < list.length; index++) {
                const { octiron, selectionResult } = list[index];
                octiron.position = index + 1;
                if (index !== 0) {
                    children.push(sep);
                }
                if (selectionResult.value == null && typeof fallback === 'function') {
                    children.push(null);
                    // children.push(fallback(octiron));
                }
                else if (selectionResult.value == null && fallback != null) {
                    children.push(fallback);
                }
                else {
                    children.push(view(octiron));
                }
            }
            children.push(post);
            return children;
        },
    };
};

/**
 * Gets the details on how to perform a submission
 * based off an action, payload and other context.
 *
 * @param args.payload The current payload value.
 * @param args.action The schema.org styled action object.
 */
function getSubmitDetails({ payload, action, }) {
    let urlTemplate;
    let body;
    let method = 'get';
    let contentType;
    let encodingType;
    let target = action['https://schema.org/target'];
    if (Array.isArray(target)) {
        for (const item of target) {
            if (item === 'string') {
                target = item;
                break;
            }
            else if (isJSONObject(target) && (target['https://schema.org/contentType'] == null || (target['https://schema.org/contentType'] === 'multipart/form-data' ||
                target['https://schema.org/contentType'] === 'application/ld+json'))) {
                target = item;
                break;
            }
        }
    }
    if (typeof target === 'string') {
        urlTemplate = target;
    }
    else if (isJSONObject(target)) {
        if (typeof target['https://schema.org/urlTemplate'] === 'string') {
            urlTemplate = target['https://schema.org/urlTemplate'];
        }
        if (typeof target['https://schema.org/httpMethod'] === 'string') {
            method = target['https://schema.org/httpMethod'].toLowerCase();
        }
        if (typeof target['https://schema.org/contentType'] === 'string') {
            contentType = target['https://schema.org/contentType'];
        }
        if (typeof target['https://schema.org/encodingType'] === 'string') {
            encodingType = target['https://schema.org/encodingType'];
        }
    }
    if (typeof urlTemplate !== 'string') {
        throw new Error('Action has invalid https://schema.org/target');
    }
    const fillArgs = {};
    const submitBody = Object.assign({}, payload);
    for (const [type, value] of Object.entries(action)) {
        if (!isTypeObject(value) ||
            value['@type'] !== 'https://schema.org/PropertyValueSpecification') {
            continue;
        }
        const valueName = value['https://schema.org/valueName'];
        if (valueName != null) {
            const propType = type.replace(/-input$/, '');
            fillArgs[valueName] = payload[propType];
            delete submitBody[propType];
        }
    }
    const template = uriTemplates(urlTemplate);
    // deno-lint-ignore no-explicit-any
    const url = template.fill(fillArgs);
    // only add body if supporting HTTP method
    if (method !== 'get' && method !== 'delete') {
        body = JSON.stringify(submitBody);
    }
    else {
        contentType = undefined;
        encodingType = undefined;
    }
    return {
        url,
        method,
        contentType,
        encodingType,
        body,
    };
}

const ActionStateRenderer3 = () => {
    let render;
    let not;
    let type;
    let octiron;
    let args;
    let parentArgs;
    const listener = (submitResult, selectionDetails) => {
        if (submitResult.loading) {
            return;
        }
        if ((!not && type === 'failure' && submitResult.ok) ||
            (not && type === 'failure' && !submitResult.ok) ||
            (not && type === 'success' && submitResult.ok) ||
            (!not && type === 'success' && !submitResult.ok)) {
            render = false;
            return;
        }
        render = true;
        octiron = selectionFactory(args, parentArgs, {
            index: 0,
            value: selectionDetails.result[0].value,
        });
    };
    return {
        oninit(vnode) {
            not = vnode.attrs.not ?? false;
            type = vnode.attrs.type;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            render = not &&
                vnode.attrs.selector == null &&
                vnode.attrs.view == null;
            vnode.attrs.events.addListener(listener);
        },
        onbeforeupdate(vnode) {
            not = vnode.attrs.not ?? false;
            type = vnode.attrs.type;
        },
        onbeforeremove(vnode) {
            vnode.attrs.events.removeListener(listener);
        },
        view(vnode) {
            if (!render)
                return;
            if (vnode.attrs.selector != null && octiron != null) {
                return octiron.select(vnode.attrs.selector, vnode.attrs.args, vnode.attrs.view);
            }
            else if (vnode.attrs.view != null && octiron != null) {
                return vnode.attrs.view(octiron);
            }
            return vnode.children;
        },
    };
};

const ActionStateRenderer = () => {
    let key = Symbol('ActionStateRenderer');
    let submitResult;
    let o;
    function setInstance(attrs) {
        if (attrs.submitResult == null) {
            submitResult = undefined;
            o = undefined;
        }
        else if (submitResult == null ||
            attrs.submitResult.ok !== submitResult.ok ||
            attrs.submitResult.status !== submitResult.status ||
            attrs.submitResult.value !== submitResult.value) {
            submitResult = attrs.submitResult;
            const rendererArgs = {
                index: 0,
                value: attrs.submitResult.value,
            };
            o = selectionFactory(attrs.args, attrs.parentArgs, rendererArgs);
        }
    }
    function listener(next) {
        if (next.result.length === 1 && next.result[0].value != null) {
            submitResult.value = next.result[0].value;
        }
    }
    function updateSubscription(attrs) {
        if (attrs.submitResult == null || attrs.submitResult.loading) {
            attrs.parentArgs.store.unsubscribe(key);
            return;
        }
        attrs.parentArgs.store.unsubscribe(key);
        attrs.parentArgs.store.subscribe({
            key,
            listener,
            selector: attrs.submitResult.iri,
            accept: attrs.args.accept,
            fragment: attrs.args.fragment,
            mainEntity: attrs.args.mainEntity,
        });
    }
    return {
        oninit: ({ attrs }) => {
            updateSubscription(attrs);
            setInstance(attrs);
        },
        onbeforeupdate: ({ attrs }) => {
            updateSubscription(attrs);
            setInstance(attrs);
        },
        view: ({ attrs: { type, selector, args, view, ...attrs }, children }) => {
            if (type === 'initial' && submitResult == null) {
                return children;
            }
            else if (submitResult == null || o == null) {
                return null;
            }
            let shouldRender = (type === 'success' && submitResult.ok) ||
                (type === 'failure' && !submitResult.ok);
            if (attrs.not) {
                shouldRender = !shouldRender;
            }
            o.position = 1;
            if (shouldRender && selector != null) {
                return o.select(selector, args, view);
            }
            else if (shouldRender && view != null) {
                return view(o);
            }
            else if (shouldRender && args != null) {
                return o.present(args);
            }
            o.position = -1;
            return null;
        },
    };
};

function actionFactory(args, parentArgs, rendererArgs, events) {
    const factoryArgs = Object.assign(Object.create(null), args);
    let payload = Object.create(null);
    let submitResult;
    if (isJSONObject(args.initialValue)) {
        payload = expandValue(parentArgs.store, args.initialValue);
    }
    else if (args.initialValue != null) {
        console.warn('o.perform() only supports receiving JSON objects as initial values.');
    }
    async function submit() {
        let isError = false;
        const { url, method, contentType, body } = getSubmitDetails({
            payload,
            action: refs.rendererArgs.value,
        });
        self.submitting = true;
        self.url = new URL(url, self.store.rootIRI);
        mithrilRedraw();
        try {
            if (typeof args.onSubmit === 'function') {
                args.onSubmit(self);
            }
            submitResult = await refs.parentArgs.store.submit(url, {
                mainEntity: args.mainEntity,
                method,
                contentType: contentType ?? 'application/ld+json',
                body,
                accept: args.accept,
            });
            events.onSubmitResult(submitResult);
        }
        catch (err) {
            console.error(err);
            isError = true;
        }
        self.submitting = false;
        mithrilRedraw();
        if (isError && typeof args.onSubmitFailure === 'function' && isBrowserRender) {
            args.onSubmitFailure(self);
        }
        else if (!isError && typeof args.onSubmitSuccess === 'function' && isBrowserRender) {
            args.onSubmitSuccess(self);
        }
    }
    function update(value, args2) {
        const prev = payload;
        const next = {
            ...prev,
            ...value,
        };
        if (typeof args.interceptor === 'function') {
            const res = args.interceptor({
                next,
                prev,
                actionValue: refs.parentArgs.parent.value,
                o: self,
            });
            if (res === false) {
                return false;
            }
            payload = res;
        }
        else {
            payload = next;
        }
        childArgs.value = self.value = value;
        if (args2?.submit !== false && (args2?.submit || args.submitOnChange)) {
            submit();
        }
        else {
            mithrilRedraw();
        }
    }
    const updatePointer = (pointer, value, _args) => {
        const next = Object.assign({}, payload);
        const ptr = JsonPointer.create(pointer);
        if (value == null) {
            ptr.unset(next);
        }
        else {
            ptr.set(next, value, true);
        }
        update(next);
    };
    const childArgs = {
        value: payload,
        submitting: false,
        submit,
        updatePointer,
    };
    const refs = {
        factoryArgs,
        parentArgs,
        rendererArgs,
        childArgs,
    };
    const self = octironFactory('action', refs);
    self.value = payload;
    self.action = parentArgs.parent;
    self.actionValue = rendererArgs.actionValue;
    childArgs.action = self;
    childArgs.submitting = self.submitting;
    self.select = (arg1, arg2, arg3) => {
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(ActionSelectionRenderer, {
            parentArgs: childArgs,
            selector,
            value: self.value,
            actionValue: refs.rendererArgs.actionValue.value,
            args,
            view,
        });
    };
    self.submit = async function (arg1) {
        if (arg1 != null) {
            const res = typeof arg1 === 'function'
                ? update(arg1(payload), { submit: false })
                : update(arg1, { submit: false });
            if (res === false)
                return;
        }
        return submit();
    };
    self.update = async function (arg1, arg2) {
        const res = typeof arg1 === 'function'
            ? update(arg1(payload), arg2)
            : update(arg1, arg2);
        if (res === false)
            return;
    };
    self.append = (termOrType, value = {}, args = {}) => {
        const type = refs.parentArgs.store.expand(termOrType);
        if (!isJSONObject(self.value)) {
            return;
        }
        const prevValue = self.value[type];
        let nextValue = [];
        if (prevValue != null && !Array.isArray(prevValue)) {
            nextValue.push(prevValue);
        }
        else if (Array.isArray(prevValue)) {
            nextValue = [...prevValue.filter((value) => value != undefined)];
        }
        nextValue.push(value);
        return self.update({
            ...self.value,
            [type]: nextValue,
        }, args);
    };
    const makeInitialStateMethod = (not) => {
        return (children) => {
            return m(ActionStateRenderer, {
                not,
                type: 'initial',
                args: {},
                submitResult,
                parentArgs: childArgs,
            }, children);
        };
    };
    const makeActionStateMethod = (type, not) => {
        return (arg1, arg2, arg3) => {
            const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
            return m(ActionStateRenderer3, {
                not,
                type,
                selector,
                args,
                view,
                parentArgs: childArgs,
                events,
            });
        };
    };
    self.initial = makeInitialStateMethod();
    self.not.initial = makeInitialStateMethod(true);
    self.success = makeActionStateMethod('success');
    self.not.success = makeActionStateMethod('success', true);
    self.failure = makeActionStateMethod('failure');
    self.not.failure = makeActionStateMethod('failure', true);
    try {
        const submitDetails = getSubmitDetails({
            payload: self.value,
            action: refs.rendererArgs.value,
        });
        self.url = new URL(submitDetails.url);
        self.method = submitDetails.method;
    }
    catch (err) {
        console.error(err);
    }
    if (self.url != null) {
        submitResult = refs.parentArgs.store.entity(self.url.toString(), args.accept);
    }
    if (isBrowserRender && args.submitOnInit) {
        if (submitResult == null) {
            submit();
        }
        else {
            events.onSubmitResult(submitResult);
        }
    }
    else if (!isBrowserRender &&
        args.submitOnInit) {
        submit();
    }
    return self;
}

function applySubmission(key, listener, store, args, submitResult, listeners) {
    let selectionResult;
    let selectionDetails;
    if (submitResult.type !== 'alternative-success' &&
        isIRIObject(submitResult.value)) {
        selectionDetails = store.subscribe({
            key,
            listener,
            selector: submitResult.value['@id'],
        });
    }
    else {
        if (submitResult.type === 'entity-success') {
            selectionResult = {
                key: '/',
                pointer: '/',
                type: 'value',
                readonly: true,
                status: submitResult.status,
                reason: submitResult.reason,
                value: submitResult.value,
            };
        }
        else if (submitResult.type === 'alternative-success') {
            selectionResult = {
                key: '/',
                pointer: '/',
                type: 'alternative',
                iri: submitResult.iri,
                fragment: args.fragment,
                accept: args.accept,
                ok: submitResult.ok,
                status: submitResult.status,
                contentType: submitResult.contentType,
                reason: submitResult.reason,
                integration: store.integration(submitResult.contentType),
            };
        }
        store.unsubscribe(key);
        selectionDetails = {
            complete: true,
            hasErrors: !submitResult.ok,
            hasMissing: false,
            isProblem: submitResult.isProblem,
            fragment: args.fragment,
            accept: args.accept,
            dependencies: [],
            required: [],
            result: [selectionResult],
            selector: submitResult.iri,
        };
    }
    for (let i = 0, l = listeners.length; i < l; i++) {
        listeners[i](submitResult, selectionDetails);
    }
    return selectionDetails;
}
const ActionRenderer2 = () => {
    const key = Symbol('ActionRenderer');
    let octiron;
    let store;
    let args;
    let parentArgs;
    let submitResult;
    let selectionDetails;
    const listeners = [];
    const addListener = (listener) => {
        listeners.push(listener);
        if (submitResult != null) {
            listener(submitResult, selectionDetails);
        }
    };
    const removeListener = (listener) => {
        listeners.splice(listeners.indexOf(listener), 1);
    };
    const listener = (next) => {
        selectionDetails = next;
        for (let i = 0, l = listeners.length; i < l; i++) {
            listeners[i](submitResult, selectionDetails);
        }
    };
    const onSubmitResult = (next) => {
        submitResult = next;
        selectionDetails = applySubmission(key, listener, store, args, submitResult, listeners);
    };
    return {
        oninit(vnode) {
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            octiron = actionFactory(args, parentArgs, vnode.attrs.rendererArgs, {
                onSubmitResult,
                addListener,
                removeListener,
            });
        },
        onbeforeupdate(vnode) {
            const prev = store;
            const changed = prev !== (vnode.attrs.args.store ?? vnode.attrs.parentArgs.store);
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            store = args.store ?? parentArgs.store;
            if (changed) {
                store.unsubscribe(key);
                if (submitResult != null) {
                    onSubmitResult(submitResult);
                }
            }
        },
        onbeforeremove() {
            store.unsubscribe(key);
        },
        view(vnode) {
            return vnode.attrs.view(octiron);
        },
    };
};

function createInstances$1(instances, args, parentArgs, selectionDetails) {
    const prevKeys = Array.from(instances.keys());
    const nextKeys = [];
    for (let i = 0, l = selectionDetails.result.length; i < l; i++) {
        const selectionResult = selectionDetails.result[i];
        nextKeys.push(selectionResult.pointer);
        if (instances.has(selectionResult.pointer)) {
            const next = selectionResult;
            const prev = instances.get(selectionResult.pointer).selectionResult;
            if (prev.type === 'value' &&
                next.type === 'value' &&
                next.value === prev.value) {
                continue;
            }
            else if (prev.type === 'entity' &&
                next.type === 'entity' &&
                next.ok === prev.ok &&
                next.status === prev.status &&
                next.value === prev.value) {
                continue;
            }
        }
        const selectionRendererArgs = {
            index: i,
            value: selectionResult.value,
            propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
        };
        const octiron = selectionFactory(args, parentArgs, selectionRendererArgs);
        const rendererArgs = {
            index: i,
            value: selectionResult.value,
            propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
            actionValue: octiron,
        };
        instances.set(selectionResult.pointer, {
            octiron,
            selectionResult,
            rendererArgs,
        });
    }
    if (prevKeys.length > 0) {
        for (let i = 0, l = prevKeys.length; i < l; i++) {
            if (!nextKeys.includes(prevKeys[i])) {
                instances.delete(prevKeys[i]);
            }
        }
    }
}
async function fetchRequired$1(store, args, selectionDetails) {
    if (selectionDetails.required.length === 0)
        return;
    const promises = [];
    for (let i = 0, l = selectionDetails.required.length; i < l; i++) {
        promises.push(store.fetch(selectionDetails.required[i], args));
    }
    await Promise.allSettled(promises);
}
function subscribe$1(key, listener, instances, store, selector, args, parentArgs) {
    if (selector != null &&
        !isJSONObject$1(parentArgs.parent.value)) {
        // Actions can only be performed on JSON objects.
        store.unsubscribe(key);
        instances.clear();
        return;
    }
    let selectionDetails;
    if (selector != null) {
        selectionDetails = store.subscribe({
            key,
            listener,
            selector,
            value: parentArgs.parent.value,
        });
        if (selectionDetails.required.length > 0) {
            fetchRequired$1(store, args, selectionDetails);
        }
    }
    else {
        // If there is no selector this perform is being done against the
        // current value.
        selectionDetails = {
            selector: '/',
            complete: true,
            hasErrors: false,
            hasMissing: false,
            isProblem: false,
            dependencies: [],
            required: [],
            result: [{
                    key: '/',
                    pointer: '/',
                    type: 'value',
                    readonly: true,
                    value: parentArgs.parent.value,
                }],
        };
        createInstances$1(instances, args, parentArgs, selectionDetails);
    }
    return selectionDetails;
}
const PerformRenderer3 = () => {
    let key = Symbol('PerformRenderer');
    let loading;
    let store;
    let selector;
    let args;
    let parentArgs;
    let instances;
    const listener = (selectionDetails) => {
        loading = !selectionDetails.complete;
        if (selectionDetails.required.length > 0) {
            fetchRequired$1(store, args, selectionDetails);
        }
        else {
            createInstances$1(instances, args, parentArgs, selectionDetails);
        }
    };
    return {
        oninit(vnode) {
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            instances = new Map();
            loading = !subscribe$1(key, listener, instances, store, selector, args, parentArgs)?.complete;
        },
        onbeforeupdate(vnode) {
            const prev = store;
            const changed = store !== (vnode.attrs.args.store ?? vnode.attrs.parentArgs.store) ||
                selector !== vnode.attrs.selector;
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            if (changed) {
                prev.unsubscribe(key);
                loading = !subscribe$1(key, listener, instances, store, selector, args, parentArgs)?.complete;
            }
        },
        onbeforeremove() {
            store.unsubscribe(key);
        },
        view(vnode) {
            if (loading && instances.size === 0) {
                return vnode.attrs.args.loading;
            }
            const children = [vnode.attrs.args.pre];
            const list = Array.from(instances.values());
            for (let i = 0, l = list.length; i < l; i++) {
                list[i].octiron.position = i + 1;
                if (i !== 0)
                    children.push(vnode.attrs.args.sep);
                if (list[i].selectionResult.type !== 'value' &&
                    !list[i].selectionResult.ok) {
                    if (typeof vnode.attrs.args.fallback === 'function') {
                        children.push(vnode.attrs.args.fallback(list[i].octiron, list[i].selectionResult.reason));
                    }
                    else {
                        children.push(vnode.attrs.args.fallback);
                    }
                }
                else {
                    children.push(m(ActionRenderer2, {
                        args: vnode.attrs.args,
                        parentArgs: vnode.attrs.parentArgs,
                        rendererArgs: list[i].rendererArgs,
                        selection: list[i].octiron,
                        view: vnode.attrs.view,
                    }));
                }
            }
            children.push(vnode.attrs.args.post);
            return children;
        },
    };
};

const PresentRenderer = ({ attrs: { args, factoryArgs, parentArgs, rendererArgs, }, }) => {
    let [attrs, component] = selectComponentFromArgs('present', parentArgs, rendererArgs, args, factoryArgs);
    return {
        //onbeforeupdate({ attrs: { args, factoryArgs, parentArgs, rendererArgs }}) {
        // [attrs, component] = selectComponentFromArgs(
        //   'present',
        //   parentArgs,
        //   rendererArgs,
        //   args,
        //   factoryArgs,
        // );
        //},
        view({ attrs: { o, rendererArgs }, children }) {
            if (component == null) {
                return null;
            }
            // deno-lint-ignore no-explicit-any
            return m(component, {
                o,
                renderType: "present",
                value: rendererArgs.value,
                attrs,
            }, children);
        },
    };
};

/**
 * Creates Octiron instances used when rendering this selection.
 * If an instance is an entity it will get re-ordered into the
 * next selection. Otherwise it will be re-purposed.
 */
function createInstances(instances, args, parentArgs, selectionDetails) {
    let selectionResult;
    const prev = new Map(instances);
    instances.clear();
    for (let i = 0, l = selectionDetails.result.length; i < l; i++) {
        selectionResult = selectionDetails.result[i];
        if (prev.has(selectionResult.key)) {
            const instance = prev.get(selectionResult.key);
            instance.refs.rendererArgs.index = i;
            instance.refs.rendererArgs.value = selectionResult.value;
            instance.refs.rendererArgs.propType = selectionResult.type === 'entity'
                ? undefined
                : selectionResult.propType;
            instance.octiron.index = i;
            instance.octiron.value = instance.refs.rendererArgs.value;
            instance.octiron.propType = instance.refs.rendererArgs.propType;
            instances.set(selectionResult.key, instance);
        }
        else {
            const rendererArgs = {
                index: i,
                value: selectionResult.value,
                propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
            };
            const octiron = selectionFactory(args, parentArgs, rendererArgs);
            const refs = {
                args,
                parentArgs,
                rendererArgs,
            };
            instances.set(selectionResult.key, {
                refs,
                octiron,
                selectionResult,
            });
        }
    }
}
async function fetchRequired(store, args, selectionDetails) {
    if (selectionDetails.required.length === 0)
        return;
    const promises = [];
    for (let i = 0, l = selectionDetails.required.length; i < l; i++) {
        promises.push(store.fetch(selectionDetails.required[i], args));
    }
    await Promise.allSettled(promises);
}
function subscribe(key, listener, instances, store, entity, selector, args, parentArgs) {
    if (!entity && !isJSONObject$1(parentArgs.parent.value)) {
        store.unsubscribe(key);
        instances.clear();
        return;
    }
    const selectionDetails = store.subscribe({
        key,
        selector,
        listener,
        fragment: args.fragment,
        accept: args.accept,
        value: entity ? undefined : parentArgs.value,
        mainEntity: args.mainEntity,
    });
    if (selectionDetails.required.length > 0) {
        fetchRequired(store, args, selectionDetails);
    }
    createInstances(instances, args, parentArgs, selectionDetails);
    return selectionDetails;
}
const SelectionRenderer2 = () => {
    let key = Symbol('SelectionRenderer');
    let loading;
    let store;
    let entity;
    let selector;
    let args;
    let parentArgs;
    let value;
    let instances;
    const listener = (selectionDetails) => {
        loading = !selectionDetails.complete;
        if (selectionDetails.required.length > 0) {
            fetchRequired(store, args, selectionDetails);
        }
        else if (!loading) {
            createInstances(instances, args, parentArgs, selectionDetails);
        }
    };
    return {
        oninit(vnode) {
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            entity = vnode.attrs.entity ?? false;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            value = parentArgs.value;
            instances = new Map();
            loading = !subscribe(key, listener, instances, store, entity, selector, args, parentArgs)?.complete;
        },
        onbeforeupdate(vnode) {
            const prev = store;
            const changed = entity != (vnode.attrs.entity ?? false) ||
                store !== (vnode.attrs.args.store ?? vnode.attrs.parentArgs.store) ||
                selector !== vnode.attrs.selector ||
                value !== vnode.attrs.parentArgs.value;
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            entity = vnode.attrs.entity ?? false;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            value = parentArgs.value;
            if (changed) {
                prev.unsubscribe(key);
                loading = !subscribe(key, listener, instances, store, entity, selector, args, parentArgs)?.complete;
            }
        },
        onbeforeremove() {
            store.unsubscribe(key);
        },
        view(vnode) {
            if (loading && instances.size === 0) {
                return vnode.attrs.args.loading;
            }
            const children = [m.fragment({ key: '@pre' }, [vnode.attrs.args.pre])];
            let child;
            let l1 = Array.from(instances.values());
            let l2;
            if (vnode.attrs.args.predicate != null) {
                l2 = [];
                for (let i = 0, l = l1.length; i < l; i++) {
                    if (vnode.attrs.args.predicate(l1[i].octiron)) {
                        l2.push(l1[i]);
                    }
                }
            }
            else {
                l2 = l1;
            }
            if (vnode.attrs.args.end != null) {
                l2.splice(0, vnode.attrs.args.end);
            }
            if (vnode.attrs.args.start != null) {
                l2.splice(vnode.attrs.args.start);
            }
            for (let i = 0, l = l2.length; i < l; i++) {
                child = [];
                l2[i].octiron.position = i + 1;
                if (i !== 0)
                    child.push(m.fragment({ key: '@sep' }, [vnode.attrs.args.sep]));
                if (l2[i].selectionResult.type === 'value') {
                    child.push(m.fragment({ key: '@value' }, [vnode.attrs.view(l2[i].octiron)]));
                }
                else if (!l2[i].selectionResult.ok && typeof vnode.attrs.args.fallback === 'function') {
                    throw new Error(`Fallback functions are not yet supported`);
                }
                else if (!l2[i].selectionResult.ok) {
                    child.push(m.fragment({ key: '@value' }, [vnode.attrs.args.fallback]));
                }
                else {
                    child.push(m.fragment({ key: '@value' }, [vnode.attrs.view(l2[i].octiron)]));
                }
                children.push(m.fragment({ key: l2[i].selectionResult.key }, child));
            }
            children.push(m.fragment({ key: '@post' }, [vnode.attrs.args.post]));
            return children;
        },
    };
};

const TypeKeys = {
    'root': 0,
    'selection': 1,
    'action': 2,
    'action-selection': 3,
};
/**
 * Creates the base Octiron instance.
 *
 * @param octironType - The Octiron instance type to create.
 * @param factoryArgs - User specified args passed to the Octiron method creating the factory.
 * @param parentArgs - Args passed from the Octiron parent instance of this instance.
 * @param rendererArgs - Args passed from the Mithril renderer component.
 * @param childArgs - Args to pass through to any child renderers, to be their parent args.
 */
function octironFactory(octironType, refs) {
    refs.rendererArgs ??= {};
    refs.childArgs ??= {};
    const typeKey = TypeKeys[octironType];
    const name = isIRIObject(refs.rendererArgs.value)
        ? refs.rendererArgs.value['@id'] : refs.rendererArgs.propType ?? 'octiron';
    // hack to give the function a dynamically set name...
    const self = ({ [name]: (predicate, children) => {
            const passes = predicate(self);
            if (passes) {
                return children;
            }
            return null;
        } })[name];
    self.id = refs.parentArgs.store.key();
    self.isOctiron = true;
    self.octironType = octironType;
    self.readonly = true;
    self.value = refs.rendererArgs.value ?? null;
    self.store = refs.parentArgs.store;
    self.index = refs.rendererArgs.index ?? 0;
    self.position = -1;
    self.expand = (typeOrTerm) => refs.parentArgs.store.expand(typeOrTerm);
    // easiest to define the common child args here
    // but the object is passed in from the parent factory
    // so it has references and control over the values.
    refs.childArgs.parent = self;
    refs.childArgs.store = refs.factoryArgs.store ?? refs.parentArgs.store;
    refs.childArgs.typeHandlers = refs.factoryArgs.typeHandlers ?? refs.parentArgs.typeHandlers;
    if (typeKey !== TypeKeys['root']) {
        self.propType = refs.rendererArgs.propType;
        self.dataType = getDataType(refs.rendererArgs.value);
    }
    self.not = (predicate, children) => {
        if (self == null) {
            return null;
        }
        const passes = predicate(self);
        if (!passes) {
            return children;
        }
        return null;
    };
    self.get = (termOrType) => {
        if (!isJSONObject(self.value)) {
            return null;
        }
        if (termOrType.startsWith('@')) {
            return self.value[termOrType];
        }
        const type = self.store.expand(termOrType);
        const value = self.value[type] ?? null;
        if (isIterable(value)) {
            return getIterableValue(value);
        }
        return self.value[type] ?? null;
    };
    self.enter = (arg1, arg2, arg3) => {
        const [selector, args, view] = unravelArgs(arg1 instanceof URL ? arg1.toString() : arg1, arg2, arg3);
        return m(SelectionRenderer2, {
            entity: true,
            selector,
            args,
            view,
            parentArgs: refs.childArgs,
        });
    };
    const rootChildArgs = {
        ...refs.childArgs,
        value: refs.parentArgs.store.entity(refs.parentArgs.store.rootIRI)?.value,
    };
    self.root = (arg1, arg2, arg3) => {
        let selector;
        const [childSelector, args, view] = unravelArgs(arg1, arg2, arg3);
        if (childSelector == null) {
            selector = refs.parentArgs.store.rootIRI;
        }
        else {
            selector = `${refs.parentArgs.store.rootIRI} ${childSelector}`;
        }
        return m(SelectionRenderer2, {
            entity: true,
            selector,
            args,
            view,
            parentArgs: rootChildArgs,
        });
    };
    // action and action selection define their own select method
    switch (typeKey) {
        case TypeKeys['root']:
            self.select = self.root;
            break;
        case TypeKeys['selection']:
            self.select = ((arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                if (!isJSONObject(refs.rendererArgs.value)) {
                    return null;
                }
                return m(SelectionRenderer2, {
                    selector,
                    args,
                    view,
                    parentArgs: refs.childArgs,
                });
            });
    }
    switch (typeKey) {
        case TypeKeys['root']:
            self.present = self.root;
            break;
        default:
            self.present = (args) => {
                return m(PresentRenderer, {
                    o: self,
                    args: args,
                    factoryArgs: refs.factoryArgs,
                    parentArgs: refs.parentArgs,
                    rendererArgs: refs.rendererArgs,
                });
            };
    }
    self.default = (args) => {
        return self.present(Object.assign({ component: null }, args));
    };
    switch (typeKey) {
        case TypeKeys['root']:
            self.perform = (arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                if (typeof selector === 'string') {
                    return self.select(selector, args, o => o.perform(args, view));
                }
                return self.root(o => o.perform(args, view));
            };
            break;
        default: {
            self.perform = (arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                return m(PerformRenderer3, {
                    selector,
                    args,
                    view,
                    parentArgs: refs.childArgs,
                });
            };
            break;
        }
    }
    if (typeKey !== TypeKeys['root']) {
        const updateArgs = (factoryArgs) => {
            refs.factoryArgs = factoryArgs;
        };
        // deno-lint-ignore no-explicit-any
        self._updateArgs = updateArgs;
    }
    return self;
}

function rootFactory(parentArgs) {
    const factoryArgs = {};
    const self = octironFactory('root', {
        factoryArgs,
        parentArgs,
    });
    return self;
}

function fragmentToHTML(fragment) {
    let html = '';
    for (let i = 0; i < fragment.length; i++) {
        html += fragment[i].outerHTML;
    }
    return html;
}
const HTMLFragmentsIntegrationComponent = () => {
    let fragment;
    let html;
    let prevIRI;
    let prevFragment;
    function setDomServer(attrs) {
        if (fragment === attrs.fragment) {
            return;
        }
        fragment = attrs.fragment;
        if (attrs.fragment == null) {
            html = attrs.output.root;
            return;
        }
        const [id, rest] = attrs.fragment.split('?');
        if (rest == null) {
            html = attrs.output.fragments[id]?.html;
            return;
        }
        const template = attrs.output.templates[id];
        if (template == null) {
            return;
        }
        try {
            const args = Object.fromEntries(new URLSearchParams(rest));
            html = processTemplate(template, args, (fragment) => {
                return attrs.output.fragments[fragment]?.html;
            });
        }
        catch (err) {
            console.error(err);
        }
    }
    function setDomClient(attrs) {
        if (attrs.fragment == null) {
            if (attrs.output.root != null && attrs.output.dom == null) {
                const template = document.createElement('template');
                template.innerHTML = attrs.output.root;
                attrs.output.dom = Array.from(template.content.children);
            }
            html = attrs.output.dom;
            return;
        }
        const [id, rest] = attrs.fragment.split('?');
        const isTemplate = rest != null || attrs.output.templates[id] != null;
        if (!isTemplate) {
            const fragment = attrs.output.fragments[id];
            if (fragment == null) {
                return;
            }
            else if (fragment.type === 'text') {
                html = fragment.html;
                return;
            }
            else if (fragment.dom == null && fragment.html != null) {
                const template = document.createElement('template');
                template.innerHTML = fragment.html;
                fragment.dom = Array.from(template.content.children);
            }
            else if (fragment.dom == null) {
                return;
            }
            html = fragment.dom;
            return;
        }
        const template = attrs.output.templates[id];
        if (template == null) {
            return;
        }
        try {
            const args = Object.fromEntries(new URLSearchParams(rest));
            html = processTemplate(template, args, (ref) => {
                if (attrs.output.fragments[ref] != null &&
                    attrs.output.fragments[ref].html == null &&
                    attrs.output.fragments[ref].dom != null) {
                    attrs.output.fragments[ref].html = fragmentToHTML(attrs.output.fragments[ref].dom);
                }
                return attrs.output.fragments[ref]?.html;
            });
        }
        catch (err) {
            console.error(err);
        }
    }
    return {
        oninit({ attrs }) {
            if (isBrowserRender) {
                setDomClient(attrs);
            }
            else {
                setDomServer(attrs);
            }
            prevIRI = attrs.integration.iri;
            prevFragment = attrs.fragment;
        },
        onupdate({ attrs }) {
            if (prevIRI !== attrs.integration.iri ||
                prevFragment !== attrs.fragment) {
                if (isBrowserRender) {
                    setDomClient(attrs);
                }
                else {
                    setDomServer(attrs);
                }
            }
            prevIRI = attrs.integration.iri;
            prevFragment = attrs.fragment;
        },
        view() {
            if (isBrowserRender && Array.isArray(html)) {
                return m.dom(html);
            }
            else if (typeof html === 'string') {
                return m.trust(html);
            }
            return null;
        },
    };
};
class HTMLFragmentsIntegration {
    static type = 'html-fragments';
    integrationType = 'html-fragments';
    #rootRendered = false;
    #rendered = new Set();
    #iri;
    #contentType;
    #handler;
    #output;
    constructor(handler, { iri, contentType, output, }) {
        this.#handler = handler;
        this.#iri = iri;
        this.#contentType = contentType;
        this.#output = output;
    }
    get iri() {
        return this.#iri;
    }
    get contentType() {
        return this.#contentType;
    }
    get output() {
        return this.#output;
    }
    getFragment(fragment) {
        return fragment != null
            ? this.#output.fragments[fragment]?.html ?? null
            : this.#output.root ?? null;
    }
    #fragmentHTML(fragment) {
        let html = '';
        for (let i = 0; i < fragment.length; i++) {
            html += fragment[i].outerHTML;
        }
        return html;
    }
    /**
     * Returns a text representaion of a fragment.
     */
    text(fragment) {
        if (fragment == null) {
            if (this.output.root == null && this.#output.dom) {
                this.output.root = this.#fragmentHTML(this.#output.dom);
            }
            return this.output.root;
        }
        const [id, rest] = fragment.split('?');
        if (rest == null) {
            const fragment = this.#output.fragments[id];
            if (fragment == null) {
                return;
            }
            if (fragment.html == null && fragment.dom) {
                fragment.html = this.#fragmentHTML(fragment.dom);
            }
            return fragment.html;
        }
        const template = this.#output.templates[id];
        if (template == null) {
            return;
        }
        try {
            const args = Object.fromEntries(new URLSearchParams(rest));
            return processTemplate(template, args, (ref) => {
                const fragment = this.#output.fragments[ref];
                if (fragment == null)
                    return;
                if (fragment.html == null && fragment.dom != null) {
                    fragment.html = this.#fragmentHTML(fragment.dom);
                }
                return fragment.html;
            });
        }
        catch (err) {
            console.error(err);
        }
    }
    /**
     * Renders a HTML fragment.
     *
     * @param o         The octiron instance.
     * @param fragment  A fragment identifier to use when selecting the fragment
     *                  to render and for providing template args. If no fragment
     *                  identifier is provided the root fragment will be rendered.
     */
    render(o, fragment) {
        if (!isBrowserRender) {
            if (fragment == null) {
                this.#rootRendered = true;
            }
            else {
                this.#rendered.add(fragment);
            }
        }
        return m(HTMLFragmentsIntegrationComponent, {
            o,
            integration: this,
            fragment,
            output: this.#output,
        });
    }
    getStateInfo() {
        const texts = {};
        const fragments = [];
        const entries = Object.values(this.#output.fragments);
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].type === 'text') {
                texts[entries[i].id] = entries[i].html;
            }
            else {
                fragments.push({
                    id: entries[i].id,
                    type: entries[i].type,
                    selector: entries[i].selector,
                    rendered: this.#rendered.has(entries[i].id),
                });
            }
        }
        return {
            iri: this.#iri,
            contentType: this.#contentType,
            rendered: this.#rootRendered,
            selector: this.#output.selector,
            templates: this.#output.templates,
            texts,
            fragments,
        };
    }
    toInitialState() {
        let html = '';
        const entries = Object.values(this.#output.fragments);
        if (this.#output.root != null && !this.#rootRendered) {
            html += `<template id="htmlfrag:${this.#iri}|${this.#contentType}">${this.#output.root}</template>\n`;
        }
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].type === 'text') {
                continue;
            }
            if (!this.#rendered.has(entries[i].id)) {
                html += `<template data-htmlfrag="${entries[i].id}">${entries[i].html}</template>\n`;
            }
        }
        return html;
    }
    static fromInitialState({ iri, contentType, rendered, selector, texts, fragments, templates, }, handler) {
        const output = Object.create(null);
        output.fragments = Object.create(null);
        output.templates = templates;
        if (selector != null && rendered) {
            const element = document.querySelector(selector);
            if (element != null) {
                output.root = element.outerHTML;
            }
        }
        else if (selector != null) {
            const template = document.getElementById(`htmlfrag:${iri}|${contentType}`);
            output.root = template?.textContent;
        }
        const textEntries = Object.entries(texts);
        for (let i = 0; i < textEntries.length; i++) {
            output.fragments[textEntries[i][0]] = {
                id: textEntries[i][0],
                type: 'text',
                html: textEntries[i][1],
                selector: '',
            };
        }
        for (let i = 0; i < fragments.length; i++) {
            const fragment = fragments[i];
            document.createDocumentFragment();
            if (fragment.rendered) {
                let element;
                switch (fragment.type) {
                    case 'embed': {
                        element = document.getElementById(fragment.id);
                        if (element == null) {
                            break;
                        }
                        output.fragments[fragment.id] = {
                            id: fragment.id,
                            type: fragment.type,
                            dom: [element],
                            selector: fragment.selector,
                        };
                        break;
                    }
                    case 'bare': {
                        element = document.querySelector(fragment.selector);
                        if (element == null) {
                            break;
                        }
                        output.fragments[fragment.id] = {
                            id: fragment.id,
                            type: fragment.type,
                            dom: [element],
                            selector: fragment.selector,
                        };
                        break;
                    }
                    case 'range': {
                        const elements = document.querySelectorAll(fragment.selector);
                        output.fragments[fragment.id] = {
                            id: fragment.id,
                            type: fragment.type,
                            selector: fragment.selector,
                            dom: Array.from(elements),
                        };
                    }
                }
            }
            else {
                const template = document.querySelector(`[data-htmlfrag="${fragment.id}"]`);
                if (template == null) {
                    continue;
                }
                output.fragments[fragment.id] = {
                    id: fragment.id,
                    type: fragment.type,
                    dom: Array.from(template.content.children),
                    selector: fragment.selector,
                };
            }
        }
        return new HTMLFragmentsIntegration(handler, {
            contentType,
            iri,
            output,
        });
    }
}

/**
 * Handles all responses where the content type is not
 * configured.
 */
class UnrecognizedIntegration {
    static type = 'unrecognized';
    integrationType = 'unrecognized';
    #iri;
    #contentType;
    constructor(args) {
        this.#iri = args.iri;
        this.#contentType = args.contentType;
    }
    error(view) {
        if (typeof view === 'function') {
            return view({ type: 'unrecognized-content-type' });
        }
        return view;
    }
    get iri() {
        return this.#iri;
    }
    get contentType() {
        return this.#contentType;
    }
    getStateInfo() {
        return {
            iri: this.#iri,
            contentType: this.#contentType,
        };
    }
    static fromInitialState({ iri, contentType, }) {
        return new UnrecognizedIntegration({ iri, contentType });
    }
}

class HTTPFailure {
    #status;
    #res;
    constructor(status, res) {
        this.#status = status;
        this.#res = res;
    }
    get status() {
        return this.#status;
    }
    get res() {
        return this.#res;
    }
    undefined() {
        return null;
    }
    http(arg) {
        if (typeof arg === 'function') {
            return arg(this.#status);
        }
        return arg;
    }
    unparserable() {
        return null;
    }
}

/**
 * @description
 * Locates all IRI objects in a potentially deeply nested JSON-ld structure and
 * returns an array of the located IRI objects.
 *
 * Objects identified as IRI objects are not modified beyond being placed in
 * an array together.
 *
 * @param value - The value to flatten.
 * @param agg - An array to fill with the flattened IRI objects.
 *              This is required for the internal recursing performed by this
 *              function and isn't required by upstream callers.
 */
function flattenIRIObjects(value, agg = []) {
    if (Array.isArray(value)) {
        for (const item of value) {
            flattenIRIObjects(item, agg);
        }
    }
    else if (isJSONObject(value)) {
        if (isMetadataObject(value)) {
            return agg;
        }
        if (isIRIObject(value)) {
            agg.push(value);
        }
        if (isValueObject(value)) {
            flattenIRIObjects(value['@value'], agg);
        }
        else if (isIterable(value)) {
            flattenIRIObjects(getIterableValue(value), agg);
        }
        else {
            for (const [term, item] of Object.entries(value)) {
                if (term.startsWith('@')) {
                    continue;
                }
                flattenIRIObjects(item, agg);
            }
        }
    }
    return agg;
}

const defaultAccept = 'application/problem+json, application/ld+json';
const integrationClasses = {
    [HTMLFragmentsIntegration.type]: HTMLFragmentsIntegration,
    [UnrecognizedIntegration.type]: UnrecognizedIntegration,
};
function getJSONLdValues(vocab, aliases) {
    const aliasMap = new Map();
    const context = {};
    if (vocab != null) {
        context['@vocab'] = vocab;
    }
    if (aliases == null) {
        return [aliasMap, context];
    }
    for (const [key, value] of Object.entries(aliases)) {
        context[key] = value;
        aliasMap.set(key, value);
    }
    return [aliasMap, context];
}
function getInternalHeaderValues(headers, origins) {
    const internalHeaders = new Headers([['accept', defaultAccept]]);
    const internalOrigins = new Map();
    if (headers != null) {
        for (const [key, value] of Object.entries(headers)) {
            internalHeaders.set(key, value);
        }
    }
    if (origins != null) {
        for (const [origin, headers] of Object.entries(origins)) {
            const internalHeaders = new Headers([['accept', defaultAccept]]);
            for (const [key, value] of Object.entries(headers)) {
                internalHeaders.set(key, value);
            }
            internalOrigins.set(origin, internalHeaders);
        }
    }
    return [internalHeaders, internalOrigins];
}
class Store {
    #httpStatus;
    #rootIRI;
    #rootOrigin;
    #headers;
    #origins;
    #vocab;
    #aliases;
    #primary = new Map();
    #loading = new Set();
    #integrations = new Map();
    #handlers = new Map();
    #keys = new Set();
    #context;
    #termExpansions = new Map();
    #fetcher;
    #responseHook;
    #dependencies = new Map();
    #listeners = new Map();
    // iri => accept => [loading, contentType]
    #acceptMap = new Map();
    constructor(args) {
        this.#rootIRI = args.rootIRI;
        this.#rootOrigin = new URL(args.rootIRI).origin;
        this.#vocab = args.vocab;
        this.#fetcher = args.fetcher;
        this.#responseHook = args.responseHook;
        [this.#headers, this.#origins] = getInternalHeaderValues(args.headers, args.origins);
        [this.#aliases, this.#context] = getJSONLdValues(args.vocab, args.aliases);
        if (args.handlers != null) {
            for (let i = 0, l = args.handlers.length; i < l; i++) {
                this.#handlers.set(args.handlers[i].contentType, args.handlers[i]);
            }
        }
        if (args.primary != null) {
            this.#primary = new Map(Object.entries(args.primary));
        }
        if (!this.#headers.has('accept')) {
            this.#headers.set('accept', defaultAccept);
        }
        for (const origin of Object.values(this.#origins)) {
            if (!origin.has('accept')) {
                origin.set('accept', defaultAccept);
            }
        }
        if (args.acceptMap != null) {
            for (const [accept, entries] of Object.entries(args.acceptMap)) {
                this.#acceptMap.set(accept, new Map(entries));
            }
        }
        if (args.alternatives != null) {
            this.#integrations = args.alternatives;
        }
    }
    /**
     * Used only in SSR for reporting the HTTP status of the
     * main entity of the page.
     */
    get httpStatus() {
        return this.#httpStatus;
    }
    /**
     * The root IRI this store is configured to work with.
     */
    get rootIRI() {
        return this.#rootIRI;
    }
    /**
     * Retrieves an entity state object relating to an IRI.
     */
    entity(iri, accept) {
        const normalizedURL = new URL(iri).toString();
        const key = this.#getLoadingKey(iri, 'get', accept);
        const loading = this.#loading.has(key);
        if (loading) {
            return {
                type: 'entity-loading',
                iri: normalizedURL,
                loading: true,
                isProblem: false,
            };
        }
        if (accept == null) {
            return this.#primary.get(normalizedURL) ?? null;
        }
        const contentType = this.#acceptMap.get(normalizedURL)?.get?.(accept);
        if (contentType == null) {
            return null;
        }
        const integration = this.#integrations.get(contentType)?.get(normalizedURL);
        if (integration == null) {
            return null;
        }
        return {
            type: 'alternative-success',
            iri: normalizedURL,
            loading: false,
            ok: true,
            contentType,
            isProblem: false,
            integration,
        };
    }
    integration(contentType) {
        const integrationType = this.#handlers.get(contentType)?.integrationType;
        return integrationClasses[integrationType];
    }
    /**
     * Retrieves a text representation of a value in the store
     * if it is supported by the int4egration.
     */
    text(iri, accept) {
        const [key, fragment] = iri.split('#');
        const entity = this.entity(key, accept);
        if (entity == null) {
            return;
        }
        if (entity?.type === 'alternative-success' &&
            entity.integration.text != null) {
            return entity.integration.text(fragment);
        }
    }
    get vocab() {
        return this.#vocab;
    }
    get aliases() {
        return Object.fromEntries(Array.from(this.#aliases.entries())
            .map(([key, value]) => [key.replace(/^/, ''), value]));
    }
    get context() {
        return this.#context;
    }
    /**
     * Expands a term to a type.
     *
     * If an already expanded JSON-ld type is given it will
     * return the input value.
     */
    expand(termOrType) {
        const sym = Symbol.for(termOrType);
        const cached = this.#termExpansions.get(sym);
        if (cached != null) {
            return cached;
        }
        let expanded;
        if (this.#vocab != null && !/^[\w\d]+\:/.test(termOrType)) {
            expanded = this.#vocab + termOrType;
        }
        else if (/https?:\/\//.test(termOrType)) {
            // is a type
            expanded = termOrType;
        }
        else {
            for (const [key, value] of this.#aliases) {
                const reg = new RegExp(`^${key}:`);
                if (reg.test(termOrType)) {
                    expanded = termOrType.replace(reg, value);
                    break;
                }
            }
        }
        this.#termExpansions.set(sym, expanded ?? termOrType);
        return expanded ?? termOrType;
    }
    select(selector, value, { accept, } = {}) {
        return getSelection({
            selector,
            value,
            accept,
            store: this,
        });
    }
    /**
     * Generates a unique key for server rendering only.
     */
    key() {
        while (true) {
            const key = `oct-${Math.random().toString(36).slice(2, 7)}`;
            if (!this.#keys.has(key)) {
                this.#keys.add(key);
                return key;
            }
        }
    }
    /**
     * Creates a cleanup function which should be called
     * when a subscriber unlistens.
     */
    #makeCleanupFn(key, details) {
        return () => {
            this.#listeners.delete(key);
            for (const dependency of details.dependencies) {
                const normalizedURL = new URL(dependency).toString();
                this.#dependencies.delete(normalizedURL);
                if (isBrowserRender) {
                    setTimeout(() => {
                        if (this.#dependencies.get(normalizedURL)?.size === 0) {
                            this.#primary.delete(normalizedURL);
                        }
                    }, 5000);
                }
            }
        };
    }
    /**
     * Creates a unique key for the ir, method and accept headers
     * to be used to mark the request's loading status.
     */
    #getLoadingKey(iri, method, accept) {
        accept = accept ?? this.#headers.get('accept') ?? defaultAccept;
        return `${method?.toLowerCase()}|${iri}|${accept.toLowerCase()}`;
    }
    isLoading(iri) {
        const loadingKey = this.#getLoadingKey(iri, 'get');
        return this.#loading.has(loadingKey);
    }
    /**
     * Called on change to an entity. All listeners with dependencies in their
     * selection for this entity have the latest selection result pushed to
     * their listener functions.
     */
    #publish(iri, contentType) {
        const keys = this.#dependencies.get(iri);
        if (keys == null) {
            return;
        }
        for (const key of keys) {
            const listenerDetails = this.#listeners.get(key);
            if (listenerDetails == null) {
                continue;
            }
            // construct a new url to normalize the iri. Eg add a trailing
            // slash to an iri with no pathname part.
            const mappedType = this.#acceptMap.get(new URL(iri).toString())
                ?.get(listenerDetails.accept ?? defaultAccept);
            // TODO: A more sophisticated check might be required 
            // to correctly check the content type matches the
            // listener's accept header
            if (contentType !== mappedType)
                continue;
            const details = getSelection({
                selector: listenerDetails.selector,
                value: listenerDetails.value,
                fragment: listenerDetails.fragment,
                accept: listenerDetails.accept,
                store: this,
            });
            const cleanup = this.#makeCleanupFn(key, details);
            for (const dependency of details.dependencies) {
                const normalizedURL = new URL(dependency).toString();
                let depSet = this.#dependencies.get(normalizedURL);
                if (depSet == null) {
                    depSet = new Set([key]);
                    this.#dependencies.set(normalizedURL, depSet);
                }
                else {
                    depSet.add(key);
                }
            }
            listenerDetails.cleanup = cleanup;
            listenerDetails.listener(details);
        }
    }
    #handleJSONLD({ iri, res, contentType, output, }) {
        const iris = [iri];
        if (res.ok) {
            this.#primary.set(iri, {
                type: 'entity-success',
                iri,
                loading: false,
                ok: true,
                contentType,
                value: output.jsonld,
                isProblem: false,
            });
        }
        else {
            const reason = new HTTPFailure(res.status, res);
            this.#primary.set(iri, {
                type: 'entity-failure',
                iri,
                loading: false,
                ok: false,
                value: output.jsonld,
                contentType,
                status: res.status,
                isProblem: false,
                reason,
            });
        }
        for (const entity of flattenIRIObjects(output.jsonld)) {
            const normalizedURL = new URL(entity['@id']).toString();
            if (iris.includes(normalizedURL)) {
                continue;
            }
            this.#primary.set(normalizedURL, {
                type: 'entity-success',
                iri: entity['@id'],
                loading: false,
                ok: true,
                value: entity,
                contentType,
                isProblem: false,
            });
        }
        for (const iri of iris) {
            const normalizedURL = new URL(iri).toString();
            this.#publish(normalizedURL, contentType);
        }
    }
    async handleResponse(res, iri) {
        const contentType = res.headers.get('Content-Type')?.split?.(';')?.[0];
        if (contentType == null) {
            throw new Error('Content type not specified in response');
        }
        const handler = this.#handlers.get(contentType);
        if (handler == null) {
            const integration = new UnrecognizedIntegration({
                iri,
                contentType,
            });
            let integrations = this.#integrations.get(contentType);
            if (integrations == null) {
                integrations = new Map();
                this.#integrations.set(contentType, integrations);
            }
            integrations.set(iri, integration);
        }
        else if (handler.integrationType === 'jsonld') {
            const output = await handler.handler({
                res,
                store: this,
            });
            this.#handleJSONLD({
                iri,
                res,
                contentType,
                output,
            });
        }
        else if (handler.integrationType === 'problem-details') {
            const output = await handler.handler({
                res,
                store: this,
            });
            this.#primary.set(iri, {
                type: 'entity-failure',
                iri,
                loading: false,
                ok: false,
                value: output,
                status: res.status,
                isProblem: true,
                reason: new HTTPFailure(res.status, res),
            });
        }
        else if (handler.integrationType === 'html-fragments') {
            const output = await handler.handler({
                res,
                store: this,
            });
            let integrations = this.#integrations.get(contentType);
            if (integrations == null) {
                integrations = new Map();
                this.#integrations.set(contentType, integrations);
            }
            integrations.set(iri, new HTMLFragmentsIntegration(handler, {
                iri,
                contentType,
                output,
            }));
        }
        if (handler?.integrationType !== 'jsonld') {
            this.#publish(iri, contentType);
        }
    }
    async #callFetcher(iri, args = {}) {
        let headers;
        const url = new URL(iri);
        url.hash = '';
        const method = args.method || 'get';
        const accept = args.accept ?? this.#headers.get('accept') ?? defaultAccept;
        const dispatchURL = url.toString();
        const loadingKey = this.#getLoadingKey(dispatchURL, method, args.accept);
        if (this.#loading.has(loadingKey)) {
            return;
        }
        if (url.origin === this.#rootOrigin) {
            headers = new Headers(this.#headers);
        }
        else if (this.#origins.has(url.origin)) {
            headers = new Headers(this.#origins.get(url.origin));
        }
        else {
            throw new Error(`Unconfigured origin "${url.origin}"`);
        }
        headers.set('accept', accept);
        if (args.body != null && args.contentType != null) {
            headers.set('content-type', args.contentType);
        }
        this.#loading.add(loadingKey);
        mithrilRedraw();
        // This promise wrapping is so SSR can hook in and await the promise.
        const promise = new Promise(async (resolve) => {
            let res;
            if (this.#fetcher != null) {
                res = await this.#fetcher(dispatchURL, {
                    method,
                    headers,
                    body: args.body,
                });
            }
            else {
                res = await fetch(dispatchURL, {
                    method,
                    headers,
                    body: args.body,
                });
            }
            if (args?.mainEntity &&
                !isBrowserRender &&
                (this.#httpStatus == null || this.#httpStatus < 400) &&
                !res.status.toString().startsWith('3')) {
                // if SSR store the first 400+ status for the final HTTP response
                this.#httpStatus = res.status;
            }
            if (this.#acceptMap.has(dispatchURL)) {
                this.#acceptMap
                    .get(dispatchURL)?.set(accept, res.headers.get('content-type'));
            }
            else {
                this.#acceptMap.set(dispatchURL, new Map([[accept, res.headers.get('content-type')]]));
            }
            this.#loading.delete(loadingKey);
            await this.handleResponse(res, dispatchURL);
            mithrilRedraw();
            resolve(res);
        });
        if (this.#responseHook != null) {
            this.#responseHook(promise);
        }
        await promise;
    }
    subscribe({ key, selector, fragment, accept, value, listener, mainEntity, }) {
        const details = getSelection({
            selector,
            fragment,
            accept,
            value,
            store: this,
        });
        const cleanup = this.#makeCleanupFn(key, details);
        for (const dependency of details.dependencies) {
            const normalizedURL = new URL(dependency).toString();
            const depSet = this.#dependencies.get(normalizedURL);
            if (depSet == null) {
                this.#dependencies.set(normalizedURL, new Set([key]));
            }
            else {
                depSet.add(key);
            }
        }
        this.#listeners.set(key, {
            key,
            selector,
            value,
            fragment,
            accept,
            required: details.required,
            dependencies: details.dependencies,
            listener,
            cleanup,
        });
        // If this is the main entity and the details has
        // missing deps simulate a 404 if no other bad
        // status code has been set
        if (!isBrowserRender &&
            mainEntity &&
            details.hasMissing &&
            this.#httpStatus < 400) {
            this.#httpStatus = 404;
        }
        return details;
    }
    unsubscribe(key) {
        this.#listeners.get(key)?.cleanup();
    }
    async fetch(iri, args = {}) {
        await this.#callFetcher(iri.toString(), args);
        return this.#primary.get(iri.toString());
    }
    /**
     * Submits an action. Like fetch this will overwrite
     * entities in the store with any entities returned
     * in the response.
     *
     * @param {string} iri                The iri of the request.
     * @param {SubmitArgs} [args]         Arguments to pass to the fetch call.
     * @param {string} [args.method]      The http submit method.
     * @param {string} [args.contentType] The content type header value.
     * @param {string} [args.body]        The body of the request.
     */
    async submit(iri, args) {
        await this.#callFetcher(iri, args);
        return this.entity(iri, args?.accept);
    }
    /**
     * Creates an Octiron store from initial state written to the page's HTML.
     *
     * @param rootIRI       The root endpoint of the API.
     * @param [disableLogs] Disables warning and error logs if the initial state
     *                      is not present or corrupt.
     * @param [vocab]       The JSON-ld @vocab to use for Octiron selectors.
     * @param [aliases]     The JSON-ld aliases to use for Octiron selectors.
     * @param [headers]     Headers to send when making requests to endpoints sharing
     *                      origins with the `rootIRI`.
     * @param [origins]     A map of origins and the headers to use when sending
     *                      requests to them. Octiron will only send requests
     *                      to endpoints which share origins with the `rootIRI`
     *                      or are configured in the origins object. Aside
     *                      from the accept header, which has a common default
     *                      value, headers are not shared between origins.
     */
    static fromInitialState({ disableLogs, rootIRI, vocab, aliases, headers, origins, handlers = [], }) {
        performance.mark('octiron:from-initial-state:start');
        const storeArgs = {
            rootIRI,
            vocab,
            aliases,
            handlers,
            headers,
            origins,
        };
        try {
            const el = document.getElementById('oct-state');
            if (el == null) {
                if (!disableLogs) {
                    console.warn('Failed to construct Octiron state from initial state');
                }
                return new Store(storeArgs);
            }
            const stateInfo = JSON.parse(el.innerText);
            const alternatives = new Map();
            const handlersMap = handlers.reduce((acc, handler) => ({
                ...acc,
                [handler.contentType]: handler,
            }), {});
            for (const [integrationType, entities] of Object.entries(stateInfo.alternatives)) {
                for (const stateInfo of entities) {
                    const handler = handlersMap[stateInfo.contentType];
                    const cls = integrationClasses[integrationType];
                    if (cls === null || cls.type !== handler?.integrationType) {
                        continue;
                    }
                    const state = cls.fromInitialState(stateInfo, handler);
                    if (state == null) {
                        continue;
                    }
                    let integrations = alternatives.get(state.contentType);
                    if (integrations == null) {
                        integrations = new Map();
                        alternatives.set(state.contentType, integrations);
                    }
                    integrations.set(state.iri, state);
                }
            }
            const store = new Store({
                ...storeArgs,
                alternatives,
                primary: stateInfo.primary,
                acceptMap: stateInfo.acceptMap,
            });
            performance.mark('octiron:from-initial-state:end');
            performance.measure('octiron:from-initial-state:duration', 'octiron:from-initial-state:start', 'octiron:from-initial-state:end');
            return store;
        }
        catch (err) {
            if (!disableLogs) {
                console.warn('Failed to construct Octiron state from initial state');
                console.error(err);
            }
            const store = new Store(storeArgs);
            performance.mark('octiron:from-initial-state:end');
            performance.measure('octiron:from-initial-state:duration', 'octiron:from-initial-state:start', 'octiron:from-initial-state:end');
            return store;
        }
    }
    /**
     * Writes the Octiron store's state to a string to be embedded
     * near the end of a HTML document. Ideally this is placed before
     * the closing of the document's body tag. Octiron uses ids prefixed
     * with `oct-`, avoid using these ids to prevent id collision.
     */
    toInitialState() {
        let html = '';
        const stateInfo = {
            primary: Object.fromEntries(this.#primary),
            alternatives: {},
            acceptMap: {},
        };
        for (const [accept, map] of this.#acceptMap.entries()) {
            stateInfo.acceptMap[accept] = Array.from(map.entries());
        }
        for (const alternative of this.#integrations.values()) {
            for (const integration of alternative.values()) {
                if (stateInfo.alternatives[integration.integrationType] == null) {
                    stateInfo.alternatives[integration.integrationType] = [
                        integration.getStateInfo(),
                    ];
                }
                else {
                    stateInfo.alternatives[integration.integrationType].push(integration.getStateInfo());
                }
                if (integration.toInitialState != null)
                    html += integration.toInitialState();
            }
        }
        html += `<script id="oct-state" type="application/json">${JSON.stringify(stateInfo)}</script>`;
        return html;
    }
}

/**
 * @description
 * Aggregates a list of type handlers into an easier to access
 * type handler config object.
 *
 * @param typeHandlers The type handlers to aggregate.
 */
function makeTypeHandlers(
// deno-lint-ignore no-explicit-any
storeOrTypeHandler, ...typeHandlers) {
    const config = {};
    if (storeOrTypeHandler instanceof Store) {
        for (const typeHandler of typeHandlers) {
            if (typeHandler.type === '@id') {
                config['@id'] = typeHandler;
            }
            else {
                // deno-lint-ignore no-explicit-any
                config[storeOrTypeHandler.expand(typeHandler.type)] = typeHandler;
            }
        }
    }
    else {
        // deno-lint-ignore no-explicit-any
        config[storeOrTypeHandler.type] = storeOrTypeHandler;
        for (const typeHandler of typeHandlers) {
            // deno-lint-ignore no-explicit-any
            config[typeHandler.type] = typeHandler;
        }
    }
    return config;
}

/**
 * Merges arguments into a single css class string
 */
function classes(...classArgs) {
    const cls = [];
    for (const classArg of classArgs) {
        if (typeof classArg === 'undefined' || classArg === null) {
            continue;
        }
        else if (typeof classArg === 'string') {
            cls.push(classArg);
        }
        else if (Array.isArray(classArg)) {
            for (const name of classArg) {
                cls.push(name);
            }
        }
        else {
            for (const [name, active] of Object.entries(classArg)) {
                if (active) {
                    cls.push(name);
                }
            }
        }
    }
    return cls.join(' ');
}

/**
 * @description
 * Utility for creating a well typed typeHandler.
 *
 * @param typeHandler An object to property define the types for.
 */
function makeTypeHandler(typeHandler) {
    return typeHandler;
}

let store;
const makeJSONLDHandler = (args) => {
    if (args?.store != null) {
        store = args.store;
    }
    return {
        integrationType: 'jsonld',
        contentType: 'application/ld+json',
        handler: async ({ res }) => {
            const { expand, JSONLDContextStore } = await import('@occultist/mini-jsonld');
            if (store == undefined) {
                store = new JSONLDContextStore({ cacheMethod: 'cache' });
            }
            const json = await res.json();
            const jsonld = await expand(json, { store, url: res.url });
            return {
                jsonld,
            };
        },
    };
};

const longformHandler = {
    integrationType: 'html-fragments',
    contentType: 'text/longform',
    handler: async ({ res }) => {
        const { longform } = await import('@longform/longform');
        return longform(await res.text());
    },
};

const problemDetailsJSONHandler = {
    integrationType: 'problem-details',
    contentType: 'application/problem+json',
    handler: async ({ res }) => {
        return res.json();
    },
};

const OctironJSON = () => {
    function renderIRI(iri) {
        return m('code', [
            m('span.oct-json-quote', '"'),
            m('a.oct-json-iri', {
                href: iri,
            }, iri),
            m('span.oct-json-quote', '"'),
        ]);
    }
    function renderPrimitive(value) {
        const className = typeof value === 'boolean'
            ? 'oct-json-boolean'
            : typeof value === 'number'
                ? 'oct-json-number'
                : 'oct-json-string';
        let presentValue;
        if (typeof value === 'boolean' && value) {
            presentValue = 'true';
        }
        else if (typeof value === 'boolean') ;
        else if (typeof value === 'string') {
            presentValue = [
                m('span.oct-json-quote', '"'),
                value,
                m('span.oct-json-quote', '"'),
            ];
        }
        else {
            presentValue = value;
        }
        return m('code', { className }, presentValue);
    }
    function renderArray(list, url, selector = '') {
        const children = [];
        for (let index = 0; index < list.length; index++) {
            const value = list[index];
            children.push(m('li.oct-json-arr-item', maybeRenderDetails(null, value, url, selector)));
        }
        return m('ul.oct-json-arr', children);
    }
    const terminalTypes = ['@id', '@type', '@context'];
    function renderObject(value, url, selector = '') {
        const items = [];
        const list = Object.entries(value);
        list.sort();
        for (let index = 0; index < list.length; index++) {
            const [term, value] = list[index];
            let children;
            const summary = [
                m('span.oct-json-quote', '"'),
                m('span.oct-json-obj-key', term),
                m('span.oct-json-quote', '"'),
                m('span.oct-json-obj-colon', ': '),
            ];
            if (term === '@id') {
                children = [m('code', summary), renderIRI(value)];
            }
            else if (url == null || terminalTypes.includes(term)) {
                children = maybeRenderDetails(summary, value);
            }
            else if (term.startsWith('@')) {
                children = maybeRenderDetails(summary, value, url, selector);
            }
            else {
                const currentSelector = `${selector} ${term}`;
                const currentURL = new URL(url);
                currentURL.searchParams.set('selector', currentSelector);
                const summary = [
                    m('span.oct-json-quote', '"'),
                    m('span.oct-json-obj-key', m('a', { href: currentURL }, term)),
                    m('span.oct-json-quote', '"'),
                    m('span.oct-json-obj-colon', ': '),
                ];
                children = maybeRenderDetails(summary, value, url, currentSelector);
            }
            items.push(m('li.oct-json-obj-item', children));
        }
        return m('ul.oct-json-obj', items);
    }
    function maybeRenderDetails(summary, value, url, selector = '') {
        if (isJSONObject(value)) {
            return [
                m('details.oct-json-details', { open: true }, m('summary.oct-json-details-sum', m('code', summary, m('span.oct-json-obj-open', '{'))), renderValue(value, url, selector)),
                m('code.oct-json-obj-close', '}'),
            ];
        }
        else if (Array.isArray(value)) {
            return [
                m('details.oct-json-details', { open: true }, m('summary.oct-json-details-sum', m('code', summary, m('span.oct-json-obj-open', '['))), renderValue(value, url, selector)),
                m('code.oct-json-obj-close', ']'),
            ];
        }
        return [m('code', summary), renderValue(value, url, selector)];
    }
    function renderValue(value, url, selector = '') {
        if (isJSONObject(value)) {
            return renderObject(value, url, selector);
        }
        else if (Array.isArray(value)) {
            return renderArray(value, url, selector);
        }
        return renderPrimitive(value);
    }
    return {
        view: ({ attrs: { value, selector, location } }) => {
            const url = location != null ? new URL(location) : undefined;
            return m('.oct-json', [
                maybeRenderDetails(null, value, url, typeof selector === 'string' ? selector.trim() : undefined),
            ]);
        },
    };
};

const OctironDebug = ({ attrs, }) => {
    let currentAttrs = attrs;
    let value = attrs.o.value;
    let rendered;
    let presentationStyle = attrs.initialPresentationStyle ?? 'value';
    function onRender(redraw = true) {
        const { o } = currentAttrs;
        if (presentationStyle === 'value') {
            rendered = m(OctironJSON, {
                value,
                selector: currentAttrs.selector,
                location: currentAttrs.location,
            });
        }
        else if (presentationStyle === 'action-value' && (o.octironType === 'action' ||
            o.octironType === 'action-selection')) {
            rendered = m(OctironJSON, { value: o.actionValue.value, selector: currentAttrs.selector, location: currentAttrs.location });
        }
        if (redraw) {
            mithrilRedraw();
        }
    }
    function onSetValue(e) {
        e.redraw = false;
        presentationStyle = 'value';
        onRender();
    }
    function onSetActionValue(e) {
        e.redraw = false;
        presentationStyle = 'action-value';
        onRender();
    }
    function onSetComponent(e) {
        e.redraw = false;
        presentationStyle = 'component';
        onRender();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            onRender(false);
        },
        onbeforeupdate: ({ attrs }) => {
            if (attrs.o.value !== value) {
                value = attrs.o.value;
                onRender(true);
            }
        },
        view: ({ attrs: { o, availableControls } }) => {
            let children;
            let actionValueAction;
            const controls = [];
            if (presentationStyle === 'component') {
                children = m('.oct-debug-body', o.default());
            }
            else {
                children = m('.oct-debug-body', rendered);
            }
            if (o.octironType === 'action' || o.octironType === 'action-selection') {
                actionValueAction = m('button.oct-button', { type: 'button', onclick: onSetActionValue }, 'Action value');
            }
            if (availableControls == null || availableControls.includes('value')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: onSetValue }, 'Value'));
            }
            else if (actionValueAction != null && (availableControls == null ||
                availableControls.includes('action-value'))) {
                controls.push(actionValueAction);
            }
            else if (availableControls == null || availableControls.includes('component')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: onSetComponent }, 'Component'));
            }
            else if (availableControls == null || availableControls.includes('log')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: () => console.debug(o) }, 'Log'));
            }
            return m('aside.oct-debug', m('.oct-debug-controls', m('.oct-button-group', ...controls)), children);
        },
    };
};
const Debug = {
    view: ({ attrs: { o } }) => {
        return m(OctironDebug, { o });
    },
};

const OctironExplorer = ({ attrs, }) => {
    let value = attrs.selector || '';
    let previousSelector = value;
    let selector = value;
    let presentationStyle = 'value';
    let onChange = attrs.onChange;
    const fallbackComponent = {
        view: ({ attrs: { o } }) => {
            return m(OctironDebug, { o, location: attrs.location });
        },
    };
    function onSearch(evt) {
        value = evt.target.value;
    }
    function onEnter(evt) {
        if (evt.key === 'Enter') {
            onApply();
        }
    }
    function onApply() {
        selector = value;
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    function onSetValue(evt) {
        evt.preventDefault();
        presentationStyle = 'value';
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    function onSetActionValue(evt) {
        evt.preventDefault();
        presentationStyle = 'action-value';
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    return {
        oninit: ({ attrs }) => {
            onChange = attrs.onChange;
        },
        onbeforeupdate: ({ attrs }) => {
            selector = attrs.selector ?? '';
            if (selector !== previousSelector) {
                value = previousSelector = selector;
            }
            onChange = attrs.onChange;
        },
        view: ({ attrs: { autofocus, o } }) => {
            let children;
            let upURL;
            let valueURL;
            let actionValueURL;
            if (selector.length !== 0 && presentationStyle === 'value') {
                children = o.root(selector, (o) => m(OctironDebug, {
                    o,
                    selector,
                    location: attrs.location,
                    initialPresentationStyle: attrs.presentationStyle,
                    availableControls: !!attrs.childControls == false ? undefined : [],
                }));
            }
            else if (selector.length !== 0) {
                children = o.root(selector, (o) => m('div', o.default({ fallbackComponent, attrs: { selector } })));
            }
            else if (presentationStyle === 'value') {
                children = o.root((o) => m(OctironDebug, {
                    o,
                    selector,
                    location: attrs.location,
                    initialPresentationStyle: attrs.presentationStyle,
                    availableControls: !!attrs.childControls ? undefined : [],
                }));
            }
            else {
                children = o.root((o) => m('div', o.default({ fallbackComponent, attrs: { selector } })));
            }
            if (attrs.location != null && selector.length !== 0) {
                const upSelector = attrs.selector.trim().includes(' ')
                    ? attrs.selector.replace(/\s+([^\s]+)$/, '')
                    : '';
                upURL = new URL(attrs.location);
                if (upSelector != null) {
                    upURL.searchParams.set('selector', upSelector);
                }
                else {
                    upURL.searchParams.delete('selector');
                }
            }
            if (attrs.location != null) {
                valueURL = new URL(attrs.location);
                actionValueURL = new URL(attrs.location);
                valueURL.searchParams.set('presentationStyle', 'value');
                actionValueURL.searchParams.set('presentationStyle', 'action-value');
            }
            return m('.oct-explorer', m('.oct-explorer-controls', m('form.oct-form-group', {
                action: attrs.location?.toString?.(),
                onsubmit: (evt) => {
                    evt.preventDefault();
                    onApply();
                },
            }, [
                upURL != null
                    ? m('a.oct-button', { href: upURL.toString() }, 'Up')
                    : m('button.oct-button', { type: 'button', disabled: true }, 'Up'),
                m('input', {
                    name: 'selector',
                    value,
                    autofocus,
                    oninput: onSearch,
                    onkeypress: onEnter,
                }),
                m('button.oct-button', {
                    type: 'submit',
                    disabled: selector === value && typeof window !== 'undefined',
                }, 'Apply'),
            ]), m('.oct-button-group', presentationStyle === 'value' || valueURL == null
                ? m('button.oct-button', {
                    type: 'button',
                    disabled: typeof window === 'undefined',
                    onclick: onSetValue,
                }, 'Value')
                : m('a.oct-button', {
                    href: valueURL.toString(),
                    onclick: onSetValue,
                }, 'Value'), presentationStyle === 'action-value' || actionValueURL == null
                ? m('button.oct-button', {
                    type: 'button',
                    disabled: typeof window === 'undefined',
                    onclick: onSetActionValue,
                }, 'Action value')
                : m('a.oct-button', {
                    href: actionValueURL.toString(),
                    onclick: onSetActionValue,
                }, 'Action value'))), m('pre.oct-explorer-body', children));
        },
    };
};

const OctironForm = (vnode) => {
    const o = vnode.attrs.o;
    const method = o.method?.toUpperCase() || 'POST';
    const enctypes = {
        GET: 'application/x-www-form-urlencoded',
        POST: 'multipart/form-data',
    };
    return {
        view: ({ attrs: { o, ...attrs }, children }) => {
            return m('form.oct-form', {
                ...attrs,
                method,
                enctype: enctypes[method],
                action: o.url,
                onsubmit: (evt) => {
                    evt.preventDefault();
                    o.submit();
                },
            }, children);
        },
    };
};

const OctironSubmitButton = () => {
    return {
        view: ({ attrs, children }) => {
            return m('button.oct-button.oct-submit-button', {
                id: attrs.id,
                type: 'submit',
                class: classes(attrs.class),
            }, children);
        },
    };
};

/**
 * Creates a root octiron instance.
 */
function octiron({ typeHandlers, ...storeArgs }) {
    const store = new Store(storeArgs);
    const config = typeHandlers != null
        ? makeTypeHandlers(store, ...typeHandlers)
        : {};
    return rootFactory({
        store,
        typeHandlers: config,
    });
}
octiron.fromInitialState = ({ typeHandlers, ...storeArgs }) => {
    const store = Store.fromInitialState({
        ...storeArgs,
    });
    const config = typeHandlers != null
        ? makeTypeHandlers(store, ...typeHandlers)
        : {};
    return rootFactory({
        store,
        typeHandlers: config,
    });
};

export { Debug, OctironDebug, OctironExplorer, OctironForm, OctironJSON, OctironSubmitButton, Store, classes, longformHandler, makeJSONLDHandler, makeTypeHandler, makeTypeHandlers, octiron, problemDetailsJSONHandler };
//# sourceMappingURL=octiron.js.map
