import m from 'mithril';
import { JsonPointer } from 'json-ptr';
import uriTemplates from 'uri-templates';
import { processTemplate, longform } from '@longform/longform';
import jsonld from 'jsonld';

/**
  * Creates an Octiron selection instance.
  *
  * @param args - User specified args passed to the Octiron method creating the factory.
  * @param parentArgs - Args passed from the Octiron parent instance of this instance.
  * @param rendererArgs - Args passed from the Mithril renderer component.
  */
function selectionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign({}, args);
    const childArgs = {
        // value: parentArgs.value,
        value: rendererArgs.value,
    };
    const self = octironFactory('selection', factoryArgs, parentArgs, rendererArgs, childArgs);
    return self;
}

const ActionStateRenderer = () => {
    let submitResult;
    let o;
    function setInstance(attrs) {
        if (attrs.submitResult == null) {
            submitResult = undefined;
            o = undefined;
        }
        else if (submitResult == null ||
            attrs.submitResult.ok !== submitResult.ok ||
            attrs.submitResult.status !== submitResult.status ||
            attrs.submitResult.value !== submitResult.value) {
            submitResult = attrs.submitResult;
            const rendererArgs = {
                index: 0,
                value: attrs.submitResult.value,
            };
            o = selectionFactory(attrs.args, attrs.parentArgs, rendererArgs);
        }
    }
    return {
        oninit: ({ attrs }) => {
            setInstance(attrs);
        },
        onbeforeupdate: ({ attrs }) => {
            setInstance(attrs);
        },
        view: ({ attrs: { type, selector, args, view, ...attrs }, children }) => {
            if (type === 'initial' && submitResult == null) {
                return children;
            }
            else if (submitResult == null || o == null) {
                return null;
            }
            let shouldRender = (type === 'success' && submitResult.ok) ||
                (type === 'failure' && !submitResult.ok);
            if (attrs.not) {
                shouldRender = !shouldRender;
            }
            o.position = 1;
            if (shouldRender && selector != null) {
                return o.select(selector, args, view);
            }
            else if (shouldRender && view != null) {
                return view(o);
            }
            else if (shouldRender && args != null) {
                return o.present(args);
            }
            o.position = -1;
            return null;
        },
    };
};

/**
 * @description
 * Returns true if the input value is an object.
 *
 * @param value Any value which should come from a JSON source.
 */
function isJSONObject(value) {
    return typeof value === 'object' && !Array.isArray(value) && value !== null;
}

/**
 * @description
 * Returns true if the given value is a JSON object with a JSON-ld @type value.
 *
 * @param value Any value which should come from a JSON source.
 */
function isTypeObject(value) {
    if (!isJSONObject(value)) {
        return false;
    }
    else if (typeof value['@type'] === 'string') {
        return true;
    }
    else if (!Array.isArray(value['@type'])) {
        return false;
    }
    for (const item of value['@type']) {
        if (typeof item !== 'string') {
            return false;
        }
    }
    return true;
}

/**
 * Gets the details on how to perform a submission
 * based off an action, payload and other context.
 *
 * @param args.payload The current payload value.
 * @param args.action The schema.org styled action object.
 */
function getSubmitDetails({ payload, action, }) {
    let urlTemplate;
    let body;
    let method = 'get';
    let contentType;
    let encodingType;
    let target = action['https://schema.org/target'];
    if (Array.isArray(target)) {
        for (const item of target) {
            if (item === 'string') {
                target = item;
                break;
            }
            else if (isJSONObject(target) && (target['https://schema.org/contentType'] == null || (target['https://schema.org/contentType'] === 'mutipart/form-data' ||
                target['https://schema.org/contentType'] === 'application/ld+json'))) {
                target = item;
                break;
            }
        }
    }
    if (typeof target === 'string') {
        urlTemplate = target;
    }
    else if (isJSONObject(target)) {
        if (typeof target['https://schema.org/urlTemplate'] === 'string') {
            urlTemplate = target['https://schema.org/urlTemplate'];
        }
        if (typeof target['https://schema.org/httpMethod'] === 'string') {
            method = target['https://schema.org/httpMethod'].toLowerCase();
        }
        if (typeof target['https://schema.org/contentType'] === 'string') {
            contentType = target['https://schema.org/contentType'];
        }
        if (typeof target['https://schema.org/encodingType'] === 'string') {
            encodingType = target['https://schema.org/encodingType'];
        }
    }
    if (typeof urlTemplate !== 'string') {
        throw new Error('Action has invalid https://schema.org/target');
    }
    const fillArgs = {};
    const submitBody = Object.assign({}, payload);
    for (const [type, value] of Object.entries(action)) {
        if (!isTypeObject(value) ||
            value['@type'] !== 'https://schema.org/PropertyValueSpecification') {
            continue;
        }
        const valueName = value['https://schema.org/valueName'];
        if (valueName != null) {
            const propType = type.replace(/-input$/, '');
            fillArgs[valueName] = payload[propType];
            delete submitBody[valueName];
        }
    }
    const template = uriTemplates(urlTemplate);
    // deno-lint-ignore no-explicit-any
    const url = template.fill(fillArgs);
    // only add body if supporting HTTP method
    if (method !== 'get' && method !== 'delete') {
        body = JSON.stringify(submitBody);
    }
    else {
        contentType = undefined;
        encodingType = undefined;
    }
    return {
        url,
        method,
        contentType,
        encodingType,
        body,
    };
}

/**
 * @description
 * Numerous Octiron view functions take a combination of string selector,
 * object args and function view arguments.
 *
 * This `unravelArgs` identifies which arguments are present and returns
 * defaults for the missing arguments.
 *
 * @param arg1 - A selector string, args object or view function if present.
 * @param arg2 - An args object or view function if present.
 * @param arg3 - A view function if present.
 */
function unravelArgs(arg1, arg2, arg3) {
    let selector;
    let args = {};
    let view;
    if (typeof arg1 === "string") {
        selector = arg1;
    }
    else if (typeof arg1 === "function") {
        view = arg1;
    }
    else if (arg1 != null) {
        args = arg1;
    }
    if (typeof arg2 === 'function') {
        view = arg2;
    }
    else if (arg2 != null) {
        args = arg2;
    }
    if (typeof arg3 === 'function') {
        view = arg3;
    }
    if (typeof view === "undefined") {
        view = ((o) => o.default(args));
    }
    return [
        selector,
        args,
        view,
    ];
}

const isBrowserRender = typeof window !== 'undefined';

/**
 * @description
 * Calls Mithril's redraw function if the window object exists.
 */
function mithrilRedraw() {
    if (isBrowserRender) {
        m.redraw();
    }
}

/**
 * @description
 * Returns a component based of Octiron's selection rules:
 *
 * 1. If the first pick component is given, return it.
 * 2. If a typedef is defined for the propType (jsonld term or type)
 *    for the given style, return it.
 * 3. If a typedef is defined for the (or one of the) types (jsonld '@type')
 *    value for the given style, return it.
 * 4. If a fallback component is given, return it.
 *
 * @param args.style - The style of presentation.
 * @param args.propType - The propType the component should be configured to
 *                        handle.
 * @param args.type - The type the component should be configured to handle.
 * @param args.firstPickComponent - The component to use if passed by upstream.
 * @param args.fallbackComponent - The component to use if no other component
 *                                 is picked.
 */
function getComponent({ style, propType, type, firstPickComponent, typeDefs, fallbackComponent, }) {
    if (firstPickComponent != null) {
        return firstPickComponent;
    }
    if (propType != null &&
        typeDefs[propType]?.[style] != null) {
        return typeDefs[propType][style];
    }
    if (!Array.isArray(type) &&
        type != null &&
        typeDefs[type]?.[style] != null) {
        return typeDefs[type][style];
    }
    if (Array.isArray(type)) {
        for (const item of type) {
            if (typeDefs[item]?.[style] != null) {
                return typeDefs[item][style];
            }
        }
    }
    if (fallbackComponent != null) {
        return fallbackComponent;
    }
}

/**
 * @description
 * Returns the type value of the input if it is a type object.
 *
 * @param value A JSON value which might be a typed JSON-ld object.
 */
function getDataType(value) {
    if (isTypeObject(value)) {
        return value['@type'];
    }
}

/**
 * Selects the component and attrs to render with from args provided to an Octiron
 * factory instance or the render method.
 */
const selectComponentFromArgs = (style, parentArgs, rendererArgs, args, factoryArgs) => {
    const attrs = Object.assign({}, args?.attrs ?? factoryArgs?.attrs);
    // null for a component arg indicates this is being called by a `o.default()` method
    // which will cause infinite recursion if it ends up re-selecting itself via factory args.
    const firstPickComponent = (args?.component ?? (args?.component !== null ? factoryArgs?.component : null));
    const fallbackComponent = (args?.fallbackComponent ?? (args?.component !== null ? factoryArgs?.fallbackComponent : null));
    const component = getComponent({
        style,
        propType: rendererArgs?.propType,
        type: getDataType(rendererArgs.value),
        firstPickComponent,
        fallbackComponent,
        typeDefs: args?.typeDefs ?? parentArgs.typeDefs,
    });
    return [attrs, component];
};

const EditRenderer = ({ attrs: { args, factoryArgs, parentArgs, rendererArgs, }, }) => {
    const [attrs, component] = selectComponentFromArgs('edit', parentArgs, rendererArgs, args, factoryArgs);
    return {
        //onbeforeupdate({ attrs: { args, factoryArgs, parentArgs, rendererArgs }}) {
        // [attrs, component] = selectComponentFromArgs(
        //   'present',
        //   parentArgs,
        //   rendererArgs,
        //   args,
        //   factoryArgs,
        // );
        //},
        view({ attrs: { o, rendererArgs }, children }) {
            if (component == null) {
                return null;
            }
            // deno-lint-ignore no-explicit-any
            return m(component, {
                o,
                attrs,
                renderType: "edit",
                name: o.inputName,
                value: rendererArgs.value,
                spec: rendererArgs.spec,
                onchange: rendererArgs.update,
                onChange: rendererArgs.update,
            }, children);
        },
    };
};

/**
 * @description
 * Returns true if a json-ld value is an array or has an iterable value,
 * i.e.: an object with an `@list` or `@set` array value.
 *
 * @param {JSONValue} value - A json-ld value
 */
function isIterable(value) {
    if (Array.isArray(value)) {
        return true;
    }
    else if (isJSONObject(value)) {
        if (Array.isArray(value["@list"])) {
            return true;
        }
        else if (Array.isArray(value["@set"])) {
            return true;
        }
    }
    return false;
}

/**
 * @description
 * Returns true if a json-ld value is an array or has an iterable value,
 * i.e.: an object with an `@list` or `@set` array value.
 *
 * This function returns an empty array in the cases where a non-iterable value
 * is given.
 *
 * @param {JSONValue} value - A json-ld value
 */
function getIterableValue(value) {
    if (Array.isArray(value)) {
        return value;
    }
    else if (Array.isArray(value['@list'])) {
        return value['@list'];
    }
    else if (Array.isArray(value['@set'])) {
        return value['@set'];
    }
    return [];
}

/**
 * Expands a object's keys to be their RDF type equivlent.
 *
 * @param store   - An Octiron store with expansion context.
 * @param value   - A JSON object to expand.
 */
function expandValue(store, value) {
    let expanded = {};
    for (let [key, item] of Object.entries(value)) {
        expanded[store.expand(key)] = item;
    }
    return expanded;
}

function actionSelectionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign({}, args);
    const childArgs = {
        action: parentArgs.action,
        submitting: parentArgs.submitting,
        value: rendererArgs.value,
    };
    const self = octironFactory('action-selection', factoryArgs, parentArgs, rendererArgs, childArgs);
    self.readonly = rendererArgs.spec == null ? true : (rendererArgs.spec.readonly ?? false);
    self.inputName = rendererArgs.spec?.name != null ? rendererArgs.spec?.name : rendererArgs.propType;
    self.submitting = parentArgs.submitting;
    self.action = parentArgs.action;
    childArgs.updatePointer = (pointer, value, args, interceptor = factoryArgs.interceptor) => {
        const prev = rendererArgs.value;
        if (!isJSONObject(prev)) {
            console.warn(`Non object action change intercepted.`);
            return;
        }
        let next = Object.assign({}, prev);
        const ptr = JsonPointer.create(pointer);
        if (value == null) {
            ptr.unset(next);
        }
        else {
            ptr.set(next, value, true);
        }
        if (typeof interceptor === 'function') {
            next = interceptor(next, prev, rendererArgs.actionValue?.value);
        }
        parentArgs.updatePointer(rendererArgs.pointer, next, args);
    };
    self.update = async (arg1, args) => {
        const value = rendererArgs.value;
        if (!isJSONObject(value)) {
            throw new Error(`Cannot call update on a non object selection instance`);
        }
        if (typeof arg1 === 'function') {
            rendererArgs.update(arg1(value));
        }
        else if (arg1 != null) {
            rendererArgs.update(arg1);
        }
        if (args?.submit || args?.submitOnChange) {
            await parentArgs.submit();
        }
        else {
            mithrilRedraw();
        }
    };
    self.submit = () => {
        return parentArgs.submit();
    };
    self.select = (arg1, arg2, arg3) => {
        if (!isJSONObject(rendererArgs.value)) {
            return null;
        }
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(ActionSelectionRenderer, {
            parentArgs: childArgs,
            selector,
            value: rendererArgs.value,
            actionValue: rendererArgs.actionValue.value,
            args,
            view,
        });
    };
    self.edit = (args) => {
        if (self.readonly) {
            return self.present(args);
        }
        return m(EditRenderer, {
            o: self,
            args,
            factoryArgs,
            parentArgs,
            rendererArgs,
        });
    };
    self.default = (args) => {
        return self.edit(Object.assign({ component: null }, args));
    };
    self.initial = parentArgs.action.initial;
    self.success = parentArgs.action.success;
    self.failure = parentArgs.action.failure;
    self.remove = (_args = {}) => {
        if (rendererArgs.propType == null) {
            return;
        }
        const parentValue = parentArgs.parent.value;
        const value = parentValue[rendererArgs.propType];
        if (isIterable(value)) {
            const arrValue = getIterableValue(value);
            arrValue.splice(self.index, 1);
            if (arrValue.length === 0) {
                delete parentValue[rendererArgs.propType];
            }
        }
        else if (isJSONObject(value)) {
            delete parentValue[rendererArgs.propType];
        }
        mithrilRedraw();
    };
    self.append = (termOrType, value = {}, args = {}) => {
        if (!isJSONObject(rendererArgs.value)) {
            console.warn(`Attempt to append to non object octiron selection ${termOrType}`);
            return;
        }
        let nextValue;
        const type = parentArgs.store.expand(termOrType);
        const lastValue = rendererArgs.value[type];
        if (isJSONObject(value)) {
            value = expandValue(self.store, value);
        }
        if (lastValue == null) {
            nextValue = value;
        }
        else if (Array.isArray(lastValue)) {
            nextValue = [...lastValue, value];
        }
        else {
            nextValue = [lastValue, value];
        }
        return parentArgs.updatePointer(rendererArgs.pointer, Object.assign({}, rendererArgs.value, { [type]: nextValue }), args);
    };
    return self;
}

/**
 * @description
 * Espects a list of json pointer parts and returns a json pointer.
 */
function escapeJSONPointerParts(...parts) {
    const escaped = parts
        .map((part) => part.replace(/~/g, '~0').replace(/\//g, '~1'))
        .join('/');
    return `${escaped}`;
}

/**
 * @description
 * Returns true if the given value is a JSON object with a JSON-ld @id value.
 *
 * @param value Any value which should come from a JSON source.
 */
function isIRIObject(value) {
    return isJSONObject(value)
        && typeof value['@id'] === 'string'
        && value['@id'] !== '';
}

/**
 * @description
 * Some JSON-ld objects contain special JSON-ld values, such as @type which
 * can inform the software on what to expect when retrieving the object but
 * otherwise require fetching an entity from an endpoint to get the values
 * they relate to. For Octiron's purposes these are considered metadata objects.
 *
 * Objects containing `@value`, `@list`, `@set` are not considered metadata
 * objects as these properties references concrete values.
 *
 * @param value - The JSON object to check for non special properties in.
 */
function isMetadataObject(value) {
    const keys = Object.keys(value);
    if (keys.length === 0) {
        return false;
    }
    for (const term of keys) {
        if (!term.startsWith("@") ||
            term === '@value' ||
            term === '@list' ||
            term === '@set') {
            return false;
        }
    }
    return true;
}

/**
 * @description
 * A value object contains a `@value` value. Often this is used to provide
 * further information about the value like what `@type` it holds, allowing
 * filters to be applied to the referenced value.
 *
 * @param value - A JSON value.
 */
function isValueObject(value) {
    return typeof value['@value'] !== 'undefined';
}

const selectorRe = /\s*(?<subject>([^\[\s]+))(\[(?<filter>([^\]])+)\])?\s*/g;
/**
 * @description
 * Parses a selector string producing a selector list
 * The subject value of a selector could be an iri or a type depending on the
 * outer context.
 *
 * @param selector - The selector string to parse.
 */
function parseSelectorString(selector, store) {
    let match;
    const selectors = [];
    while ((match = selectorRe.exec(selector))) {
        const subject = match.groups?.subject;
        const filter = match.groups?.filter;
        if (typeof filter === 'string' && typeof subject === 'string') {
            selectors.push({
                subject: store.expand(subject),
                filter,
            });
        }
        else if (typeof subject === 'string') {
            selectors.push({
                subject: store.expand(subject),
            });
        }
        else {
            throw new Error(`Invalid selector: ${selector}`);
        }
    }
    return selectors;
}

const httpRe = /^https?\:\/\//;
const scmCtxRe = /^https?\:\/\/schema\.org/;
const scmTypeRe = /^https?\:\/\/schema\.org\/(?<term>(readonlyValue|valueName|valueRequired|defaultValue|minValue|maxValue|stepValue|valuePattern|multipleValues|valueMinLength|valueMaxLength))/;
function resolvePropertyValueSpecification({ spec, store, }) {
    const pvs = {
        readonlyValue: false,
        valueRequired: false,
    };
    let scmAlias;
    const scmVocab = store.vocab == null ? false : scmCtxRe.test(store.vocab);
    for (const [key, value] of Object.entries(store.aliases)) {
        if (scmCtxRe.test(value)) {
            scmAlias = [key, value];
            break;
        }
    }
    for (const [term, value] of Object.entries(spec)) {
        let type;
        if (!httpRe.test(term)) {
            if (scmVocab && !term.includes(':')) {
                type = `${store.vocab}${term}`;
            }
            else if (scmAlias && term.startsWith(`${scmAlias[0]}:`)) {
                type = term.replace(`${scmAlias[0]}:`, scmAlias[1]);
            }
        }
        else {
            type = term;
        }
        if (!type) {
            continue;
        }
        const result = scmTypeRe.exec(type);
        if (result?.groups?.term) {
            pvs[result.groups.term] = value;
        }
    }
    return {
        readonly: pvs.readonlyValue,
        required: pvs.valueRequired,
        name: pvs.valueName,
        min: pvs.minValue,
        max: pvs.maxValue,
        step: pvs.stepValue,
        pattern: pvs.valuePattern,
        multiple: pvs.multipleValues,
        minLength: pvs.valueMinLength,
        maxLength: pvs.valueMaxLength,
    };
}

/**
 * A circular selection error occurs when two or more
 * entities contain no concrete values and their '@id'
 * values point to each other in a way that creates a
 * loop. The `getSelection` function will throw when
 * this scenario is detected to prevent an infinite
 * loop.
 */
class CircularSelectionError extends Error {
}
/**
 * @description
 * Selects from the given context value and store state.
 *
 * If no `value` is provided the `selector` is assumed to begin with an iri
 * instead of a type. An entity will be selected from the store using the iri,
 * if it exists, to begin the selection.
 *
 * A type selector selects values from the context of a provided value
 * and will pull from the store if any iri objects are selected in the process.
 *
 * @param {string} args.selector            Selector string beginning with a type.
 * @param {string} [args.fragment]          A fragment if passed in as select args.
 * @param {JSONObject} [args.value]         Context object to begin the selection from.
 * @param {JSONObject} [args.actionValue]   The action, or point in the action definition which describes this value.
 * @param {JSONValue} [args.defaultValue]   A default value when used to select action values.
 * @param {Store} args.store                Octiron store to search using.
 * @returns {SelectionDetails}              Selection contained in a details object.
 */
function getSelection({ selector: selectorStr, value, fragment, accept, actionValue, defaultValue, store, }) {
    const details = {
        selector: selectorStr,
        complete: false,
        hasErrors: false,
        hasMissing: false,
        required: [],
        dependencies: [],
        result: [],
    };
    if (value == null) {
        const [{ subject, filter }, ...selector] = parseSelectorString(selectorStr, store);
        const [iri, iriFragment] = subject.split('#');
        selectEntity({
            key: '',
            pointer: '',
            iri,
            fragment: iriFragment ?? fragment,
            accept,
            filter,
            selector: selector.length > 0 ? selector : undefined,
            store,
            details,
        });
        details.complete = details.required.length === 0;
        return details;
    }
    const selector = parseSelectorString(selectorStr, store);
    traverseSelector({
        key: '',
        pointer: '',
        value,
        actionValue,
        selector,
        store,
        details,
        defaultValue,
    });
    details.complete = details.required.length === 0;
    return details;
}
function makePointer(pointer, addition) {
    return `${pointer}/${escapeJSONPointerParts(addition.toString())}`;
}
/**
 * Filters apply to objects with `@type` properties. These can be strings or
 * arrays of strings and are considered a pass if any of the values match the
 * filter.
 *
 * If an object is provided which does not contain an `@type` property it is
 * considered a fail.
 */
function passesFilter({ value, filter, }) {
    if (typeof filter !== 'string') {
        return true;
    }
    if (Array.isArray(value['@type'])) {
        return value['@type'].includes(filter);
    }
    return value['@type'] === filter;
}
/**
 * If a scala value is pulled before a selection is complete the branch
 * can exit early.
 */
function isTraversable(value) {
    return (value !== null &&
        typeof value !== 'boolean' &&
        typeof value !== 'number' &&
        typeof value !== 'string');
}
/**
 * Handles the final value found in a selection.
 * If a @id, @value jsonld object is provided further
 * recursion might be nessacary.
 */
function resolveValue({ key, pointer, value, propType, filter, spec, actionValue, store, details, }) {
    if (value === undefined) {
        details.hasMissing = true;
        return;
    }
    else if (value === null && isJSONObject(actionValue)) {
        for (const item of Object.values(actionValue)) {
            if (isTypeObject(item) && item["@type"] === 'https://schema.org/PropertyValueSpecification') {
                return;
            }
        }
    }
    if (spec != null && (
    // hit the for loop below if the action value
    // has editable properties and the value is an
    // array
    !isIterable(value) || !isJSONObject(actionValue))) {
        const pvs = resolvePropertyValueSpecification({
            spec,
            store,
        });
        if (isJSONObject(value) && isValueObject(value)) {
            value = value['@value'];
        }
        details.result.push({
            key: pointer,
            pointer,
            type: 'action-value',
            propType,
            value,
            actionValue,
            spec: pvs,
            readonly: pvs.readonly,
        });
        return;
    }
    if (!isTraversable(value)) {
        details.result.push({
            key: pointer,
            pointer: pointer,
            type: 'value',
            propType,
            value,
            readonly: true,
        });
        return;
    }
    else if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = makePointer(key, index);
            }
            resolveValue({
                key,
                pointer: makePointer(pointer, index),
                value: item,
                spec,
                actionValue,
                propType,
                filter,
                store,
                details,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    if (typeof filter === 'string' && !passesFilter({ value, filter })) {
        return;
    }
    if (isValueObject(value)) {
        resolveValue({
            key,
            pointer,
            value: value['@value'],
            propType,
            store,
            details,
        });
        return;
    }
    else if (isMetadataObject(value)) {
        selectEntity({
            key,
            pointer,
            iri: value['@id'],
            filter,
            store,
            details,
        });
        return;
    }
    if (isIRIObject(value)) {
        const iri = value['@id'];
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri,
            ok: true,
            value,
        });
        return;
    }
    details.result.push({
        key,
        pointer,
        type: 'value',
        readonly: true,
        propType,
        value,
    });
}
/**
 * Selects a type from a json value, handling invalid situations.
 */
function selectTypedValue({ key, pointer, propType, value, actionValue, filter, store, details, }) {
    pointer = makePointer(pointer, propType);
    if (!isTraversable(value)) {
        return;
    }
    if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = makePointer(key, index);
            }
            selectTypedValue({
                key,
                pointer: makePointer(pointer, index),
                propType,
                value: item,
                actionValue,
                filter,
                store,
                details,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    if (isMetadataObject(value) && isIRIObject(value)) {
        selectEntity({
            key,
            pointer,
            iri: value['@id'],
            selector: [{ subject: propType, filter }],
            store,
            details,
        });
        return;
    }
    else if (isMetadataObject(value)) {
        return;
    }
    let spec;
    if (isJSONObject(actionValue) && actionValue[`${propType}-input`] == null) {
        // selecting for an action but the type is not editable
        return;
    }
    else if (isJSONObject(actionValue)) {
        spec = actionValue[`${propType}-input`];
    }
    resolveValue({
        key,
        pointer,
        value: value[propType],
        spec,
        actionValue: actionValue?.[propType],
        propType,
        filter,
        store,
        details,
    });
}
/**
 * Recurses through the selection until there are no further selection items.
 */
function traverseSelector({ key, pointer, selector, value, actionValue, store, details, defaultValue, }) {
    if (selector.length === 0) {
        return;
    }
    else if (!isTraversable(value)) {
        return;
    }
    if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = makePointer(key, index);
            }
            // keep nesting on the full selector
            // as only objects can be subscripted
            // with propTypes
            traverseSelector({
                key,
                pointer: makePointer(pointer, index),
                selector,
                value: item,
                actionValue,
                store,
                details,
                defaultValue,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    else if (isValueObject(value)) {
        traverseSelector({
            key,
            pointer,
            selector,
            value: value['@value'],
            actionValue,
            store,
            details,
            defaultValue,
        });
    }
    if (isMetadataObject(value) && isIRIObject(value)) {
        selectEntity({
            key,
            pointer,
            selector,
            iri: value['@id'],
            store,
            details,
        });
        return;
    }
    // edit selections are a special case in that an input
    // should render even when no value is present.
    if (isJSONObject(value) &&
        actionValue !== undefined &&
        value[selector[0].subject] == null) {
        value = { [selector[0].subject]: defaultValue ?? null };
    }
    const [next, ...rest] = selector;
    const { subject: propType, filter } = next;
    // null is a placeholder for action payload types with no value.
    // jsonld drops null values otherwise.
    if (value[propType] === undefined) {
        details.hasMissing = true;
        return;
    }
    if (rest.length === 0 && isJSONObject(actionValue?.[propType])) {
        pointer = makePointer(pointer, propType);
        resolveValue({
            key: pointer,
            pointer,
            value: value[propType],
            propType,
            details,
            store,
            actionValue: actionValue?.[propType],
            spec: actionValue[`${propType}-input`],
            filter,
        });
        return;
    }
    else if (rest.length === 0) {
        selectTypedValue({
            key,
            pointer,
            propType: propType,
            filter,
            value,
            actionValue,
            store,
            details,
        });
        return;
    }
    if (typeof filter === 'string' && !passesFilter({ value, filter })) {
        return;
    }
    let traversedActionValue;
    if (isJSONObject(actionValue?.[propType])) {
        traversedActionValue = actionValue[propType];
    }
    traverseSelector({
        key: makePointer(key, propType),
        pointer: makePointer(pointer, propType),
        selector: rest,
        value: value[propType],
        actionValue: traversedActionValue,
        store,
        details,
    });
}
/**
 * Selects an entity from the store and continues the selection
 * if the branch has not completed.
 */
function selectEntity({ key, pointer, iri, fragment, accept, filter, selector, store, details, handledIRIs, }) {
    key = makePointer(key, iri);
    pointer = makePointer(pointer, iri);
    const cache = store.entity(iri, accept);
    details.dependencies.push(iri);
    // if loading is required mark found as false
    if (cache == null || cache.loading) {
        if (!details.required.includes(iri)) {
            details.required.push(iri);
            details.accept = accept;
            details.fragment = fragment;
        }
        return;
    }
    if (!cache.ok) {
        details.hasErrors = true;
        if (selector == null || selector.length === 0) {
            return;
        }
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri: cache.iri,
            ok: false,
            status: cache.status,
            value: cache.value,
            reason: cache.reason,
        });
        return;
    }
    if (cache.type === 'alternative-success') {
        details.result.push({
            key,
            pointer,
            iri: cache.iri,
            fragment,
            ok: cache.ok,
            status: cache.status,
            type: 'alternative',
            contentType: cache.integration.contentType,
            integration: cache.integration,
            accept,
        });
        return;
    }
    const value = cache.value;
    if (isMetadataObject(value)) {
        // in theory serveral entities could be metadata objects
        // referencing each other and end up looping around...
        if (handledIRIs == null) {
            handledIRIs = new Set([value['@id']]);
        }
        else if (!handledIRIs.has(value['@id'])) {
            handledIRIs.add(value['@id']);
        }
        else {
            throw new CircularSelectionError(`Circular selection loop detected`);
        }
        // select the entity this entity is referencing
        return selectEntity({
            key,
            pointer,
            iri: value['@id'],
            filter,
            selector,
            details,
            store,
            handledIRIs,
        });
    }
    // if the entity does not match the filter it is not relevant to the final selection
    if (typeof filter === 'string' && !passesFilter({ filter, value })) {
        return;
    }
    if (typeof selector === 'undefined') {
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri: cache.iri,
            ok: true,
            value: cache.value,
        });
        return;
    }
    traverseSelector({
        key,
        pointer,
        value,
        selector,
        store,
        details,
    });
    return;
}

const ActionSelectionRenderer = (vnode) => {
    let currentAttrs = vnode.attrs;
    let details;
    const instances = {};
    function createInstances() {
        let hasChanges = false;
        const { parentArgs, selectionArgs } = currentAttrs;
        const nextKeys = [];
        for (let index = 0; index < details.result.length; index++) {
            const selectionResult = details.result[index];
            nextKeys.push(selectionResult.pointer);
            if (instances[selectionResult.pointer] != null) {
                const { rendererArgs, octiron } = instances[selectionResult.pointer];
                const update = (value) => {
                    return parentArgs.updatePointer(selectionResult.pointer, value, selectionArgs);
                };
                rendererArgs.value = octiron.value = selectionResult.value;
                rendererArgs.spec = selectionResult.spec;
                rendererArgs.update = update;
                continue;
            }
            hasChanges = true;
            const update = (value) => {
                return parentArgs.updatePointer(selectionResult.pointer, value, selectionArgs);
            };
            const actionValueRendererArgs = {
                index,
                value: selectionResult.actionValue,
                propType: selectionResult.propType,
            };
            const actionValue = selectionFactory(currentAttrs.args, parentArgs, actionValueRendererArgs);
            const rendererArgs = {
                index,
                update,
                actionValue,
                pointer: selectionResult.pointer,
                propType: selectionResult.propType,
                value: selectionResult.value,
                spec: selectionResult.spec,
            };
            const actionSelection = actionSelectionFactory(currentAttrs.args, parentArgs, rendererArgs);
            instances[selectionResult.pointer] = {
                rendererArgs,
                selection: actionValue,
                octiron: actionSelection,
                selectionResult,
            };
        }
        const prevKeys = Object.keys(instances);
        for (const key of prevKeys) {
            if (!nextKeys.includes(key)) {
                hasChanges = true;
                delete instances[key];
            }
        }
        if (hasChanges && typeof window !== 'undefined') {
            mithrilRedraw();
        }
    }
    function updateSelection() {
        const { selector, value, actionValue } = currentAttrs;
        const { store } = currentAttrs.parentArgs;
        if (!isJSONObject(value)) {
            return;
        }
        details = getSelection({
            selector,
            store,
            actionValue,
            value,
            defaultValue: currentAttrs.args.initialValue,
        });
        createInstances();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            updateSelection();
        },
        onbeforeupdate: ({ attrs }) => {
            currentAttrs = attrs;
            for (const instance of Object.values(instances)) {
                instance.octiron._updateArgs('args', attrs.args);
            }
            updateSelection();
        },
        view: ({ attrs: { view, args } }) => {
            if (details == null) {
                return null;
            }
            const { pre, sep, post, fallback, } = args;
            if (typeof view === 'undefined') {
                return;
            }
            const list = Object.values(instances);
            const children = [pre];
            for (let index = 0; index < list.length; index++) {
                const { octiron, selectionResult } = list[index];
                octiron.position = index + 1;
                if (index !== 0) {
                    children.push(sep);
                }
                if (selectionResult.value == null && typeof fallback === 'function') {
                    children.push(null);
                    // children.push(fallback(octiron));
                }
                else if (selectionResult.value == null && fallback != null) {
                    children.push(fallback);
                }
                else {
                    children.push(view(octiron));
                }
            }
            children.push(post);
            return children;
        },
    };
};

function actionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign(Object.create(null), args);
    let payload = Object.create(null);
    let submitResult;
    if (isJSONObject(args.initialValue)) {
        payload = expandValue(parentArgs.store, args.initialValue);
    }
    else if (args.initialValue != null) {
        console.warn('o.perform() only supports receiving JSON objects as initial values.');
    }
    async function submit() {
        const { url, method, body, contentType, encodingType } = getSubmitDetails({
            payload,
            action: rendererArgs.value,
        });
        self.submitting = true;
        self.url = new URL(url, self.store.rootIRI);
        mithrilRedraw();
        try {
            submitResult = await parentArgs.store.submit(url, {
                method,
                body,
                contentType,
                encodingType,
            });
        }
        catch (err) {
            console.error(err);
        }
        self.submitting = false;
        mithrilRedraw();
    }
    function update(value) {
        const prev = payload;
        const next = {
            ...prev,
            ...value,
        };
        if (typeof args.interceptor === 'function') {
            payload = args.interceptor(next, prev, parentArgs.parent.value);
        }
        else {
            payload = next;
        }
        childArgs.value = self.value = value;
        mithrilRedraw();
    }
    const updatePointer = (pointer, value, _args) => {
        const next = Object.assign({}, payload);
        const ptr = JsonPointer.create(pointer);
        if (value == null) {
            ptr.unset(next);
        }
        else {
            ptr.set(next, value, true);
        }
        update(next);
    };
    const childArgs = {
        value: payload,
        submitting: false,
        submit,
        updatePointer,
    };
    const self = octironFactory('action', factoryArgs, parentArgs, rendererArgs, childArgs);
    self.value = payload;
    self.action = parentArgs.parent;
    self.actionValue = rendererArgs.actionValue;
    childArgs.action = self;
    childArgs.submitting = self.submitting;
    self.select = (arg1, arg2, arg3) => {
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(ActionSelectionRenderer, {
            parentArgs: childArgs,
            selector,
            value: self.value,
            actionValue: parentArgs.parent.value,
            args,
            view,
        });
    };
    self.submit = async function (arg1) {
        if (typeof arg1 === 'function') {
            update(arg1(payload));
        }
        else if (arg1 != null) {
            update(arg1);
        }
        return await submit();
    };
    self.update = async function (arg1, args) {
        if (typeof arg1 === 'function') {
            update(arg1(payload));
        }
        else if (arg1 != null) {
            update(arg1);
        }
        if (args?.submit || args?.submitOnChange) {
            await submit();
        }
        else {
            mithrilRedraw();
        }
    };
    self.append = (termOrType, value = {}, args = {}) => {
        const type = parentArgs.store.expand(termOrType);
        if (!isJSONObject(self.value)) {
            return;
        }
        const prevValue = self.value[type];
        let nextValue = [];
        if (prevValue != null && !Array.isArray(prevValue)) {
            nextValue.push(prevValue);
        }
        else if (Array.isArray(prevValue)) {
            nextValue = [...prevValue.filter((value) => value != undefined)];
        }
        nextValue.push(value);
        return self.update({
            ...self.value,
            [type]: nextValue,
        }, args);
    };
    const makeInitialStateMethod = (not) => {
        return (children) => {
            return m(ActionStateRenderer, {
                not,
                type: 'initial',
                args: {},
                submitResult,
                parentArgs: childArgs,
            }, children);
        };
    };
    const makeActionStateMethod = (type, not) => {
        return (arg1, arg2, arg3) => {
            const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
            return m(ActionStateRenderer, {
                not,
                type,
                selector,
                args,
                view,
                submitResult,
                parentArgs: childArgs,
            });
        };
    };
    self.initial = makeInitialStateMethod();
    self.not.initial = makeInitialStateMethod(true);
    self.success = makeActionStateMethod('success');
    self.not.success = makeActionStateMethod('success', true);
    self.failure = makeActionStateMethod('failure');
    self.not.failure = makeActionStateMethod('failure', true);
    try {
        const submitDetails = getSubmitDetails({
            payload: self.value,
            action: rendererArgs.value,
        });
        self.url = new URL(submitDetails.url);
        self.method = submitDetails.method;
    }
    catch (err) {
        console.error(err);
    }
    if (self.url != null) {
        submitResult = parentArgs.store.entity(self.url.toString());
    }
    if (typeof window === 'undefined' && args.submitOnInit &&
        submitResult == null) {
        self.submit();
    }
    else if (typeof window !== 'undefined' && args.submitOnInit) {
        self.submit();
    }
    return self;
}

const PerformRenderer = ({ attrs }) => {
    const key = Symbol('PerformRenderer');
    let currentAttrs = attrs;
    let details;
    const instances = {};
    function createInstances() {
        let hasChanges = false;
        const { args, parentArgs } = currentAttrs;
        const nextKeys = [];
        for (let index = 0; index < details.result.length; index++) {
            const selectionResult = details.result[index];
            nextKeys.push(selectionResult.pointer);
            if (Object.hasOwn(instances, selectionResult.pointer)) {
                const next = selectionResult;
                const prev = instances[selectionResult.pointer].selectionResult;
                if (prev.type === 'value' &&
                    next.type === 'value' &&
                    next.value === prev.value) {
                    continue;
                }
                else if (prev.type === 'entity' &&
                    next.type === 'entity' &&
                    (next.ok !== prev.ok ||
                        next.status !== prev.status ||
                        next.value !== prev.value)) {
                    continue;
                }
                continue;
            }
            hasChanges = true;
            const actionValueRendererArgs = {
                index,
                value: selectionResult.value,
            };
            const actionValue = selectionFactory(args, parentArgs, actionValueRendererArgs);
            const rendererArgs = {
                index,
                value: selectionResult.value,
                actionValue,
            };
            const action = actionFactory(args, parentArgs, rendererArgs);
            instances[selectionResult.pointer] = {
                action,
                octiron: actionValue,
                selectionResult,
            };
        }
        const prevKeys = Object.keys(instances);
        for (const key of prevKeys) {
            if (!nextKeys.includes(key)) {
                hasChanges = true;
                delete instances[key];
            }
        }
        if (hasChanges) {
            mithrilRedraw();
        }
    }
    async function fetchRequired(required) {
        if (required.length === 0) {
            return;
        }
        // deno-lint-ignore no-explicit-any
        const promises = [];
        for (const iri of required) {
            promises.push(currentAttrs.parentArgs.store.fetch(iri));
        }
        await Promise.allSettled(promises);
    }
    function listener(next) {
        let required = [];
        if (typeof details === 'undefined') {
            required = next.required;
        }
        else {
            for (const iri of next.required) {
                if (!details.required.includes(iri)) {
                    required.push(iri);
                }
            }
        }
        details = next;
        if (required.length > 0) {
            fetchRequired(required);
        }
        createInstances();
    }
    function subscribe() {
        const { selector, parentArgs } = currentAttrs;
        if (selector == null) {
            // The value is the action
            let result;
            if (isIRIObject(parentArgs.parent.value)) {
                result = {
                    pointer: '/local',
                    key: '@local',
                    type: 'entity',
                    iri: parentArgs.parent.value['@id'],
                    ok: true,
                    value: parentArgs.parent.value,
                };
            }
            else {
                result = {
                    pointer: '/local',
                    key: '@local',
                    type: 'value',
                    value: parentArgs.parent.value,
                    readonly: true,
                };
            }
            details = {
                selector: '',
                complete: true,
                hasErrors: false,
                hasMissing: false,
                dependencies: [],
                required: [],
                result: [result],
            };
        }
        else {
            // Perform needs to select the action value
            details = parentArgs.store.subscribe({
                key,
                selector: selector,
                value: parentArgs.parent.value,
                listener,
            });
            fetchRequired(details.required);
        }
        createInstances();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            subscribe();
        },
        onbeforeupdate: ({ attrs }) => {
            if (attrs.selector !== currentAttrs.selector) {
                attrs.parentArgs.store.unsubscribe(key);
                subscribe();
            }
            currentAttrs = attrs;
            for (const instance of Object.values(instances)) {
                instance.action._updateArgs('args', attrs.args);
            }
        },
        onbeforeremove: ({ attrs }) => {
            currentAttrs = attrs;
            attrs.parentArgs.store.unsubscribe(key);
        },
        view: ({ attrs: { view, args } }) => {
            if (details == null || !details.complete) {
                return args.loading;
            }
            const { pre, sep, post, fallback, } = args;
            if (typeof view === 'undefined') {
                return;
            }
            const list = Object.values(instances);
            const children = [pre];
            for (let index = 0; index < list.length; index++) {
                const { selectionResult, action, octiron } = list[index];
                action.position = index + 1;
                if (index !== 0) {
                    children.push(sep);
                }
                if (selectionResult.type === 'value') {
                    children.push(view(action));
                }
                else if (!selectionResult.ok && typeof fallback === 'function') {
                    children.push(fallback(octiron, selectionResult.reason));
                }
                else if (!selectionResult.ok) {
                    children.push(fallback);
                }
                else {
                    children.push(view(action));
                }
            }
            children.push(post);
            return children;
        },
    };
};

const PresentRenderer = ({ attrs: { args, factoryArgs, parentArgs, rendererArgs, }, }) => {
    let [attrs, component] = selectComponentFromArgs('present', parentArgs, rendererArgs, args, factoryArgs);
    return {
        //onbeforeupdate({ attrs: { args, factoryArgs, parentArgs, rendererArgs }}) {
        // [attrs, component] = selectComponentFromArgs(
        //   'present',
        //   parentArgs,
        //   rendererArgs,
        //   args,
        //   factoryArgs,
        // );
        //},
        view({ attrs: { o, rendererArgs }, children }) {
            if (component == null) {
                return null;
            }
            // deno-lint-ignore no-explicit-any
            return m(component, {
                o,
                renderType: "present",
                value: rendererArgs.value,
                attrs,
            }, children);
        },
    };
};

function shouldReselect(next, prev) {
    return next.parentArgs.store !== prev.parentArgs.store ||
        next.selector !== prev.selector ||
        next.parentArgs.value !== prev.parentArgs.value;
}
/**
 * @description
 * Subscribes to a selection's result using the Octiron store. Each selection
 * result is feed to an Octiron instance and is only removed if a later
 * selection update does not include the same result. Selection results are
 * given a unique key in the form of a json-path.
 *
 * Once an Octiron instance is created using a selection, further changes via
 * the upstream parentArgs object or user given args applied to the downstream
 * Octiron instances using their internal update hooks.
 */
const SelectionRenderer = (vnode) => {
    const key = Symbol(`SelectionRenderer`);
    let deferring = false;
    let currentAttrs = vnode.attrs;
    let details;
    const instances = {};
    function createInstances() {
        let hasChanges = false;
        let initialDetails = details == null;
        const nextKeys = [];
        if (details == null) {
            const prevKeys = Reflect.ownKeys(instances);
            for (const key of prevKeys) {
                if (!nextKeys.includes(key)) {
                    hasChanges = true;
                    delete instances[key];
                }
            }
            if (hasChanges) {
                mithrilRedraw();
            }
            return;
        }
        for (let index = 0; index < details.result.length; index++) {
            const selectionResult = details.result[index];
            const key = Symbol.for(selectionResult.pointer);
            nextKeys.push(key);
            if (Object.hasOwn(instances, key)) {
                const next = selectionResult;
                const prev = instances[key].selectionResult;
                if (prev.type === 'value' &&
                    next.type === 'value' &&
                    next.value === prev.value) {
                    continue;
                }
                else if (prev.type === 'entity' &&
                    next.type === 'entity' &&
                    next.ok === prev.ok &&
                    next.status === prev.status &&
                    next.value === prev.value) {
                    continue;
                }
            }
            hasChanges = true;
            const rendererArgs = {
                index,
                value: selectionResult.value,
                propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
            };
            const octiron = selectionFactory(currentAttrs.args, currentAttrs.parentArgs, rendererArgs);
            instances[key] = {
                octiron,
                selectionResult,
            };
        }
        const prevKeys = Reflect.ownKeys(instances);
        for (const key of prevKeys) {
            if (!nextKeys.includes(key)) {
                hasChanges = true;
                delete instances[key];
            }
        }
        if (!initialDetails && hasChanges) {
            mithrilRedraw();
        }
    }
    async function fetchRequired(required) {
        if (required.length === 0) {
            return;
        }
        else if (!isBrowserRender &&
            !currentAttrs.args.mainEntity &&
            currentAttrs.args.defer) {
            deferring = true;
            return;
        }
        // deno-lint-ignore no-explicit-any
        const promises = [];
        for (const iri of required) {
            promises.push(currentAttrs.parentArgs.store.fetch(iri, currentAttrs.args.accept, {
                mainEntity: currentAttrs.args.mainEntity,
            }));
        }
        await Promise.allSettled(promises);
    }
    function listener(next) {
        let required = [];
        if (typeof details === 'undefined') {
            required = next.required;
        }
        else {
            for (const iri of next.required) {
                if (!details.required.includes(iri)) {
                    required.push(iri);
                }
            }
        }
        details = next;
        if (required.length > 0) {
            fetchRequired(required);
        }
        createInstances();
    }
    function subscribe() {
        const { entity, selector, parentArgs: { value, store } } = currentAttrs;
        if (!entity &&
            !isJSONObject(value)) {
            store.unsubscribe(key);
            createInstances();
            return;
        }
        details = store.subscribe({
            key,
            selector,
            fragment: currentAttrs.args.fragment,
            accept: currentAttrs.args.accept,
            value: entity ? undefined : value,
            listener,
            mainEntity: currentAttrs.args.mainEntity,
        });
        fetchRequired(details.required);
        createInstances();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            subscribe();
        },
        onbeforeupdate: ({ attrs }) => {
            const reselect = shouldReselect(attrs, currentAttrs);
            currentAttrs = attrs;
            if (reselect) {
                attrs.parentArgs.store.unsubscribe(key);
                subscribe();
            }
        },
        onbeforeremove: ({ attrs }) => {
            currentAttrs = attrs;
            attrs.parentArgs.store.unsubscribe(key);
        },
        view: ({ attrs }) => {
            if (deferring) {
                return currentAttrs.args.loading;
            }
            if (details == null || !details.complete) {
                return attrs.args.loading;
            }
            else if ((details.hasErrors || details.hasMissing) && typeof attrs.args.fallback !== 'function') {
                return attrs.args.fallback;
            }
            else if (details.result[0] != null && details.result[0].type === 'alternative') {
                if (details.result[0].integration.render != null) {
                    return details.result[0].integration.render(attrs.parentArgs.parent, attrs.args.fragment);
                }
                else if (details.result[0].integration.error != null) ;
                return null;
            }
            const view = attrs.view;
            const { pre, sep, post, start, end, predicate, fallback, } = currentAttrs.args;
            const children = [];
            let list = Reflect.ownKeys(instances).map(((key) => {
                const instance = instances[key];
                instance.octiron.position = -1;
                return instance;
            }));
            if (start != null || end != null) {
                list = list.slice(start ?? 0, end);
            }
            if (predicate != null) {
                list = list.filter(({ octiron }) => predicate(octiron));
            }
            if (pre != null) {
                children.push(m.fragment({}, [pre]));
            }
            for (let index = 0; index < list.length; index++) {
                const { selectionResult, octiron } = list[index];
                octiron.position = index + 1;
                if (index !== 0) {
                    children.push(m.fragment({}, [sep]));
                }
                if (selectionResult.type === 'value') {
                    children.push(m.fragment({}, [view(octiron)]));
                }
                else if (!selectionResult.ok && typeof fallback === 'function') ;
                else if (!selectionResult.ok) {
                    children.push(m.fragment({}, [fallback]));
                }
                else {
                    children.push(m.fragment({}, [view(octiron)]));
                }
            }
            if (post != null) {
                children.push(m.fragment({}, [post]));
            }
            return children;
        },
    };
};

const TypeKeys = {
    'root': 0,
    'selection': 1,
    'action': 2,
    'action-selection': 3,
};
/**
 * Creates the base Octiron instance.
 *
 * @param octironType - The Octiron instance type to create.
 * @param factoryArgs - User specified args passed to the Octiron method creating the factory.
 * @param parentArgs - Args passed from the Octiron parent instance of this instance.
 * @param rendererArgs - Args passed from the Mithril renderer component.
 * @param childArgs - Args to pass through to any child renderers, to be their parent args.
 */
function octironFactory(octironType, factoryArgs, parentArgs, rendererArgs = {}, childArgs = {}) {
    const typeKey = TypeKeys[octironType];
    const name = isIRIObject(rendererArgs.value) ? rendererArgs.value['@id'] : rendererArgs.propType ?? 'octiron';
    // hack to give the function a dynamically set name...
    const self = ({ [name]: (predicate, children) => {
            const passes = predicate(self);
            if (passes) {
                return children;
            }
            return null;
        } })[name];
    self.id = parentArgs.store.key();
    self.isOctiron = true;
    self.octironType = octironType;
    self.readonly = true;
    self.value = rendererArgs.value ?? null;
    self.store = parentArgs.store;
    self.index = rendererArgs.index ?? 0;
    self.position = -1;
    self.expand = (typeOrTerm) => parentArgs.store.expand(typeOrTerm);
    // easiest to define the common child args here
    // but the object is passed in from the parent factory
    // so it has references and control over the values.
    childArgs.parent = self;
    childArgs.store = factoryArgs.store ?? parentArgs.store;
    childArgs.typeDefs = factoryArgs.typeDefs ?? parentArgs.typeDefs;
    if (typeKey !== TypeKeys['root']) {
        self.propType = rendererArgs.propType;
        self.dataType = getDataType(rendererArgs.value);
    }
    self.not = (predicate, children) => {
        if (self == null) {
            return null;
        }
        const passes = predicate(self);
        if (!passes) {
            return children;
        }
        return null;
    };
    self.get = (termOrType) => {
        if (!isJSONObject(self.value)) {
            return null;
        }
        if (termOrType.startsWith('@')) {
            return self.value[termOrType];
        }
        const type = self.store.expand(termOrType);
        const value = self.value[type] ?? null;
        if (isIterable(value)) {
            return getIterableValue(value);
        }
        return self.value[type] ?? null;
    };
    self.enter = (arg1, arg2, arg3) => {
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(SelectionRenderer, {
            entity: true,
            selector,
            args,
            view,
            parentArgs: childArgs,
        });
    };
    const rootChildArgs = {
        ...childArgs,
        value: parentArgs.store.entity(parentArgs.store.rootIRI)?.value,
    };
    self.root = (arg1, arg2, arg3) => {
        let selector;
        const [childSelector, args, view] = unravelArgs(arg1, arg2, arg3);
        if (childSelector == null) {
            selector = parentArgs.store.rootIRI;
        }
        else {
            selector = `${parentArgs.store.rootIRI} ${childSelector}`;
        }
        return m(SelectionRenderer, {
            entity: true,
            selector,
            args,
            view,
            parentArgs: rootChildArgs,
        });
        // return self.enter(selector, args, view);
    };
    // action and action selection define their own select method
    switch (typeKey) {
        case TypeKeys['root']:
            self.select = self.root;
            break;
        case TypeKeys['selection']:
            self.select = ((arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                if (!isJSONObject(rendererArgs.value)) {
                    return null;
                }
                return m(SelectionRenderer, {
                    selector,
                    args,
                    view,
                    parentArgs: childArgs,
                });
            });
    }
    switch (typeKey) {
        case TypeKeys['root']:
            self.present = self.root;
            break;
        default:
            self.present = (args) => {
                return m(PresentRenderer, {
                    o: self,
                    args: args,
                    factoryArgs: factoryArgs,
                    parentArgs,
                    rendererArgs,
                });
            };
    }
    self.default = (args) => {
        return self.present(Object.assign({ component: null }, args));
    };
    switch (typeKey) {
        case TypeKeys['root']:
            self.perform = (arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                return self.root(selector, args, (o) => o.perform(args, view));
            };
            break;
        default: {
            self.perform = (arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                if (typeof selector === 'string') {
                    return self.select(selector, args, (o) => o.perform(args, view));
                }
                return m(PerformRenderer, {
                    selector,
                    args,
                    view,
                    parentArgs: childArgs,
                });
            };
            break;
        }
    }
    if (typeKey !== TypeKeys['root']) {
        const updateArgs = (type, args) => {
            const currentArgs = type === 'args'
                ? factoryArgs
                : type === 'parent'
                    ? parentArgs
                    : rendererArgs;
            // Hack, still don't know if it will work...
            for (const key of Object.keys(currentArgs)) {
                // deno-lint-ignore no-explicit-any
                delete currentArgs[key];
            }
            for (const [key, value] of Object.entries(args)) {
                // deno-lint-ignore no-explicit-any
                currentArgs[key] = value;
            }
        };
        // deno-lint-ignore no-explicit-any
        self._updateArgs = updateArgs;
    }
    return self;
}

function rootFactory(parentArgs) {
    const factoryArgs = {};
    const self = octironFactory('root', factoryArgs, parentArgs);
    return self;
}

function fragmentToHTML(fragment) {
    let html = '';
    for (let i = 0; i < fragment.length; i++) {
        html += fragment[i].outerHTML;
    }
    return html;
}
const HTMLFragmentsIntegrationComponent = () => {
    let fragment;
    let html;
    function setDomServer(attrs) {
        if (fragment === attrs.fragment) {
            return;
        }
        fragment = attrs.fragment;
        if (attrs.fragment == null) {
            html = attrs.output.root;
            return;
        }
        const [id, rest] = attrs.fragment.split('?');
        if (rest == null) {
            html = attrs.output.fragments[id]?.html;
            return;
        }
        const template = attrs.output.templates[id];
        if (template == null) {
            return;
        }
        try {
            const args = Object.fromEntries(new URLSearchParams(rest));
            html = processTemplate(template, args, (fragment) => {
                return attrs.output.fragments[fragment]?.html;
            });
        }
        catch (err) {
            console.error(err);
        }
    }
    function setDomClient(attrs) {
        if (attrs.fragment == null) {
            if (attrs.output.root != null && attrs.output.dom == null) {
                const template = document.createElement('template');
                template.innerHTML = attrs.output.root;
                attrs.output.dom = Array.from(template.content.children);
            }
            html = attrs.output.dom;
            return;
        }
        const [id, rest] = attrs.fragment.split('?');
        const isTemplate = rest != null || attrs.output.templates[id] != null;
        if (!isTemplate) {
            const fragment = attrs.output.fragments[id];
            if (fragment == null) {
                return;
            }
            else if (fragment.type === 'text') {
                html = fragment.html;
                return;
            }
            else if (fragment.dom == null && fragment.html != null) {
                const template = document.createElement('template');
                template.innerHTML = fragment.html;
                fragment.dom = Array.from(template.content.children);
            }
            else if (fragment.dom == null) {
                return;
            }
            html = fragment.dom;
            return;
        }
        const template = attrs.output.templates[id];
        if (template == null) {
            return;
        }
        try {
            const args = Object.fromEntries(new URLSearchParams(rest));
            html = processTemplate(template, args, (ref) => {
                if (attrs.output.fragments[ref] != null &&
                    attrs.output.fragments[ref].html == null &&
                    attrs.output.fragments[ref].dom != null) {
                    attrs.output.fragments[ref].html = fragmentToHTML(attrs.output.fragments[ref].dom);
                }
                return attrs.output.fragments[ref]?.html;
            });
        }
        catch (err) {
            console.error(err);
        }
    }
    return {
        oninit({ attrs }) {
            if (isBrowserRender) {
                setDomClient(attrs);
            }
            else {
                setDomServer(attrs);
            }
        },
        view() {
            if (isBrowserRender && Array.isArray(html)) {
                return m.dom(html);
            }
            else if (typeof html === 'string') {
                return m.trust(html);
            }
            return null;
        },
    };
};
class HTMLFragmentsIntegration {
    static type = 'html-fragments';
    integrationType = 'html-fragments';
    #rootRendered = false;
    #rendered = new Set();
    #iri;
    #contentType;
    #handler;
    #output;
    constructor(handler, { iri, contentType, output, }) {
        this.#handler = handler;
        this.#iri = iri;
        this.#contentType = contentType;
        this.#output = output;
    }
    get iri() {
        return this.#iri;
    }
    get contentType() {
        return this.#contentType;
    }
    get output() {
        return this.#output;
    }
    getFragment(fragment) {
        return fragment != null
            ? this.#output.fragments[fragment]?.html ?? null
            : this.#output.root ?? null;
    }
    #fragmentHTML(fragment) {
        let html = '';
        for (let i = 0; i < fragment.length; i++) {
            html += fragment[i].outerHTML;
        }
        return html;
    }
    /**
     * Returns a text representaion of a fragment.
     */
    text(fragment) {
        if (fragment == null) {
            if (this.output.root == null && this.#output.dom) {
                this.output.root = this.#fragmentHTML(this.#output.dom);
            }
            return this.output.root;
        }
        const [id, rest] = fragment.split('?');
        if (rest == null) {
            const fragment = this.#output.fragments[id];
            if (fragment == null) {
                return;
            }
            if (fragment.html == null && fragment.dom) {
                fragment.html = this.#fragmentHTML(fragment.dom);
            }
            return fragment.html;
        }
        const template = this.#output.templates[id];
        if (template == null) {
            return;
        }
        try {
            const args = Object.fromEntries(new URLSearchParams(rest));
            return processTemplate(template, args, (ref) => {
                const fragment = this.#output.fragments[ref];
                if (fragment == null)
                    return;
                if (fragment.html == null && fragment.dom != null) {
                    fragment.html = this.#fragmentHTML(fragment.dom);
                }
                return fragment.html;
            });
        }
        catch (err) {
            console.error(err);
        }
    }
    /**
     * Renders a HTML fragment.
     *
     * @param o         The octiron instance.
     * @param fragment  A fragment identifier to use when selecting the fragment
     *                  to render and for providing template args. If no fragment
     *                  identifier is provided the root fragment will be rendered.
     */
    render(o, fragment) {
        if (!isBrowserRender) {
            if (fragment == null) {
                this.#rootRendered = true;
            }
            else {
                this.#rendered.add(fragment);
            }
        }
        return m(HTMLFragmentsIntegrationComponent, {
            o,
            integration: this,
            fragment,
            output: this.#output,
        });
    }
    getStateInfo() {
        const texts = {};
        const fragments = [];
        const entries = Object.values(this.#output.fragments);
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].type === 'text') {
                texts[entries[i].id] = entries[i].html;
            }
            else {
                fragments.push({
                    id: entries[i].id,
                    type: entries[i].type,
                    selector: entries[i].selector,
                    rendered: this.#rendered.has(entries[i].id),
                });
            }
        }
        return {
            iri: this.#iri,
            contentType: this.#contentType,
            rendered: this.#rootRendered,
            selector: this.#output.selector,
            templates: this.#output.templates,
            texts,
            fragments,
        };
    }
    toInitialState() {
        let html = '';
        const entries = Object.values(this.#output.fragments);
        if (this.#output.root != null && !this.#rootRendered) {
            html += `<template id="htmlfrag:${this.#iri}|${this.#contentType}">${this.#output.root}</template>\n`;
        }
        for (let i = 0; i < entries.length; i++) {
            if (entries[i].type === 'text') {
                continue;
            }
            if (!this.#rendered.has(entries[i].id)) {
                html += `<template data-htmlfrag="${entries[i].id}">${entries[i].html}</template>\n`;
            }
        }
        return html;
    }
    static fromInitialState({ iri, contentType, rendered, selector, texts, fragments, templates, }, handler) {
        const output = Object.create(null);
        output.fragments = Object.create(null);
        output.templates = templates;
        if (selector != null && rendered) {
            const element = document.querySelector(selector);
            if (element != null) {
                output.root = element.outerHTML;
            }
        }
        else if (selector != null) {
            const template = document.getElementById(`htmlfrag:${iri}|${contentType}`);
            output.root = template?.textContent;
        }
        const textEntries = Object.entries(texts);
        for (let i = 0; i < textEntries.length; i++) {
            output.fragments[textEntries[i][0]] = {
                id: textEntries[i][0],
                type: 'text',
                html: textEntries[i][1],
                selector: '',
            };
        }
        for (let i = 0; i < fragments.length; i++) {
            const fragment = fragments[i];
            document.createDocumentFragment();
            if (fragment.rendered) {
                let element;
                switch (fragment.type) {
                    case 'embed': {
                        element = document.getElementById(fragment.id);
                        if (element == null) {
                            break;
                        }
                        output.fragments[fragment.id] = {
                            id: fragment.id,
                            type: fragment.type,
                            dom: [element],
                            selector: fragment.selector,
                        };
                        break;
                    }
                    case 'bare': {
                        element = document.querySelector(fragment.selector);
                        if (element == null) {
                            break;
                        }
                        output.fragments[fragment.id] = {
                            id: fragment.id,
                            type: fragment.type,
                            dom: [element],
                            selector: fragment.selector,
                        };
                        break;
                    }
                    case 'range': {
                        const elements = document.querySelectorAll(fragment.selector);
                        output.fragments[fragment.id] = {
                            id: fragment.id,
                            type: fragment.type,
                            selector: fragment.selector,
                            dom: Array.from(elements),
                        };
                    }
                }
            }
            else {
                const template = document.querySelector(`[data-htmlfrag="${fragment.id}"]`);
                if (template == null) {
                    continue;
                }
                output.fragments[fragment.id] = {
                    id: fragment.id,
                    type: fragment.type,
                    dom: Array.from(template.content.children),
                    selector: fragment.selector,
                };
            }
        }
        return new HTMLFragmentsIntegration(handler, {
            contentType,
            iri,
            output,
        });
    }
}

class HTTPFailure {
    #status;
    #res;
    constructor(status, res) {
        this.#status = status;
        this.#res = res;
    }
    get status() {
        return this.#status;
    }
    get res() {
        return this.#res;
    }
    undefined() {
        return null;
    }
    http(arg) {
        if (typeof arg === 'function') {
            return arg(this.#status);
        }
        return arg;
    }
    unparserable() {
        return null;
    }
}

/**
 * @description
 * Locates all IRI objects in a potentially deeply nested JSON-ld structure and
 * returns an array of the located IRI objects.
 *
 * Objects identified as IRI objects are not modified beyond being placed in
 * an array together.
 *
 * @param value - The value to flatten.
 * @param agg - An array to fill with the flattened IRI objects.
 *              This is required for the internal recursing performed by this
 *              function and isn't required by upstream callers.
 */
function flattenIRIObjects(value, agg = []) {
    if (Array.isArray(value)) {
        for (const item of value) {
            flattenIRIObjects(item, agg);
        }
    }
    else if (isJSONObject(value)) {
        if (isMetadataObject(value)) {
            return agg;
        }
        if (isIRIObject(value)) {
            agg.push(value);
        }
        if (isValueObject(value)) {
            flattenIRIObjects(value['@value'], agg);
        }
        else if (isIterable(value)) {
            flattenIRIObjects(getIterableValue(value), agg);
        }
        else {
            for (const [term, item] of Object.entries(value)) {
                if (term.startsWith('@')) {
                    continue;
                }
                flattenIRIObjects(item, agg);
            }
        }
    }
    return agg;
}

/**
 * Handles all responses where the content type is not
 * configured.
 */
class UnrecognizedIntegration {
    static type = 'unrecognized-integration';
    integrationType = 'unrecognized';
    #iri;
    #contentType;
    constructor(args) {
        this.#iri = args.iri;
        this.#contentType = args.contentType;
    }
    error(view) {
        if (typeof view === 'function') {
            return view({ type: 'unrecognized-content-type' });
        }
        return view;
    }
    get iri() {
        return this.#iri;
    }
    get contentType() {
        return this.#contentType;
    }
    getStateInfo() {
        return {
            iri: this.#iri,
            contentType: this.#contentType,
        };
    }
    static fromInitialState({ iri, contentType, }) {
        return new UnrecognizedIntegration({ iri, contentType });
    }
}

const defaultAccept = 'application/problem+json, application/ld+json';
const integrationClasses = {
    [HTMLFragmentsIntegration.type]: HTMLFragmentsIntegration,
    [UnrecognizedIntegration.type]: UnrecognizedIntegration,
};
function getJSONLdValues(vocab, aliases) {
    const aliasMap = new Map();
    const context = {};
    if (vocab != null) {
        context['@vocab'] = vocab;
    }
    if (aliases == null) {
        return [aliasMap, context];
    }
    for (const [key, value] of Object.entries(aliases)) {
        context[key] = value;
        aliasMap.set(key, value);
    }
    return [aliasMap, context];
}
function getInternalHeaderValues(headers, origins) {
    const internalHeaders = new Headers([['accept', defaultAccept]]);
    const internalOrigins = new Map();
    if (headers != null) {
        for (const [key, value] of Object.entries(headers)) {
            internalHeaders.set(key, value);
        }
    }
    if (origins != null) {
        for (const [origin, headers] of Object.entries(origins)) {
            const internalHeaders = new Headers([['accept', defaultAccept]]);
            for (const [key, value] of Object.entries(headers)) {
                internalHeaders.set(key, value);
            }
            internalOrigins.set(origin, internalHeaders);
        }
    }
    return [internalHeaders, internalOrigins];
}
class Store {
    #httpStatus;
    #rootIRI;
    #rootOrigin;
    #headers;
    #origins;
    #vocab;
    #aliases;
    #primary = new Map();
    #loading = new Set();
    #integrations = new Map();
    #handlers;
    #keys = new Set();
    #context;
    #termExpansions = new Map();
    #fetcher;
    #responseHook;
    #dependencies = new Map();
    #listeners = new Map();
    // iri => accept => [loading, contentType]
    #acceptMap = new Map();
    constructor(args) {
        this.#rootIRI = args.rootIRI;
        this.#rootOrigin = new URL(args.rootIRI).origin;
        this.#vocab = args.vocab;
        this.#fetcher = args.fetcher;
        this.#responseHook = args.responseHook;
        [this.#headers, this.#origins] = getInternalHeaderValues(args.headers, args.origins);
        [this.#aliases, this.#context] = getJSONLdValues(args.vocab, args.aliases);
        this.#handlers = new Map(args.handlers?.map?.((handler) => [handler.contentType, handler]));
        if (args.primary != null) {
            this.#primary = new Map(Object.entries(args.primary));
        }
        if (!this.#headers.has('accept')) {
            this.#headers.set('accept', defaultAccept);
        }
        for (const origin of Object.values(this.#origins)) {
            if (!origin.has('accept')) {
                origin.set('accept', defaultAccept);
            }
        }
        if (args.acceptMap != null) {
            for (const [accept, entries] of Object.entries(args.acceptMap)) {
                this.#acceptMap.set(accept, new Map(entries));
            }
        }
        if (args.alternatives != null) {
            this.#integrations = args.alternatives;
        }
    }
    /**
     * Used only in SSR for reporting the HTTP status of the
     * main entity of the page.
     */
    get httpStatus() {
        return this.#httpStatus;
    }
    /**
     * The root IRI this store is configured to work with.
     */
    get rootIRI() {
        return this.#rootIRI;
    }
    /**
     * Retrieves an entity state object relating to an IRI.
     */
    entity(iri, accept) {
        if (accept == null) {
            return this.#primary.get(iri) ?? null;
        }
        //const key = this.#getLoadingKey(iri, 'get', accept);
        //const loading = this.#loading.has(key);
        //if (loading) {
        //  return {
        //    type: 'entity-loading',
        //    iri,
        //    loading: true,
        //  };
        //}
        const contentType = this.#acceptMap.get(iri)?.get?.(accept);
        if (contentType == null) {
            return null;
        }
        const integration = this.#integrations.get(contentType)?.get(iri);
        if (integration == null) {
            return null;
        }
        return {
            type: 'alternative-success',
            iri,
            loading: false,
            ok: true,
            integration,
        };
    }
    /**
     * Retrieves a text representation of a value in the store
     * if it is supported by the int4egration.
     */
    text(iri, accept) {
        const [key, fragment] = iri.split('#');
        const entity = this.entity(key, accept);
        if (entity == null) {
            return;
        }
        if (entity?.type === 'alternative-success' &&
            entity.integration.text != null) {
            return entity.integration.text(fragment);
        }
    }
    get vocab() {
        return this.#vocab;
    }
    get aliases() {
        return Object.fromEntries(this.#aliases.entries()
            .map(([key, value]) => [key.replace(/^/, ''), value]));
    }
    get context() {
        return this.#context;
    }
    /**
     * Expands a term to a type.
     *
     * If an already expanded JSON-ld type is given it will
     * return the input value.
     */
    expand(termOrType) {
        const sym = Symbol.for(termOrType);
        const cached = this.#termExpansions.get(sym);
        if (cached != null) {
            return cached;
        }
        let expanded;
        if (this.#vocab != null && !/^[\w\d]+\:/.test(termOrType)) {
            expanded = this.#vocab + termOrType;
        }
        else if (/https?:\/\//.test(termOrType)) {
            // is a type
            expanded = termOrType;
        }
        else {
            for (const [key, value] of this.#aliases) {
                const reg = new RegExp(`^${key}:`);
                if (reg.test(termOrType)) {
                    expanded = termOrType.replace(reg, value);
                    break;
                }
            }
        }
        this.#termExpansions.set(sym, expanded ?? termOrType);
        return expanded ?? termOrType;
    }
    select(selector, value, { accept, } = {}) {
        return getSelection({
            selector,
            value,
            accept,
            store: this,
        });
    }
    /**
     * Generates a unique key for server rendering only.
     */
    key() {
        while (true) {
            const key = `oct-${Math.random().toString(36).slice(2, 7)}`;
            if (!this.#keys.has(key)) {
                this.#keys.add(key);
                return key;
            }
        }
    }
    /**
     * Creates a cleanup function which should be called
     * when a subscriber unlistens.
     */
    #makeCleanupFn(key, details) {
        return () => {
            this.#listeners.delete(key);
            for (const dependency of details.dependencies) {
                this.#dependencies.delete(dependency);
                if (isBrowserRender) {
                    setTimeout(() => {
                        if (this.#dependencies.get(dependency)?.size === 0) {
                            this.#primary.delete(dependency);
                        }
                    }, 5000);
                }
            }
        };
    }
    /**
     * Creates a unique key for the ir, method and accept headers
     * to be used to mark the request's loading status.
     */
    #getLoadingKey(iri, method, accept) {
        accept = accept ?? this.#headers.get('accept') ?? defaultAccept;
        return `${method?.toLowerCase()}|${iri}|${accept.toLowerCase()}`;
    }
    isLoading(iri) {
        const loadingKey = this.#getLoadingKey(iri, 'get');
        return this.#loading.has(loadingKey);
    }
    /**
     * Called on change to an entity. All listeners with dependencies in their
     * selection for this entity have the latest selection result pushed to
     * their listener functions.
     */
    #publish(iri, _contentType) {
        const keys = this.#dependencies.get(iri);
        if (keys == null) {
            return;
        }
        for (const key of keys) {
            const listenerDetails = this.#listeners.get(key);
            if (listenerDetails == null) {
                continue;
            }
            const details = getSelection({
                selector: listenerDetails.selector,
                value: listenerDetails.value,
                fragment: listenerDetails.fragment,
                accept: listenerDetails.accept,
                store: this,
            });
            const cleanup = this.#makeCleanupFn(key, details);
            for (const dependency of details.dependencies) {
                let depSet = this.#dependencies.get(dependency);
                if (depSet == null) {
                    depSet = new Set([key]);
                    this.#dependencies.set(dependency, depSet);
                }
                else {
                    depSet.add(key);
                }
            }
            listenerDetails.cleanup = cleanup;
            listenerDetails.listener(details);
        }
    }
    #handleJSONLD({ iri, res, output, }) {
        const iris = [iri];
        if (res.ok) {
            this.#primary.set(iri, {
                type: 'entity-success',
                iri,
                loading: false,
                ok: true,
                value: output.jsonld,
                headers: res.headers,
            });
        }
        else {
            const reason = new HTTPFailure(res.status, res);
            this.#primary.set(iri, {
                type: 'entity-failure',
                iri,
                loading: false,
                ok: false,
                value: output.jsonld,
                status: res.status,
                headers: res.headers,
                reason,
            });
        }
        for (const entity of flattenIRIObjects(output.jsonld)) {
            if (iris.includes(entity['@id'])) {
                continue;
            }
            this.#primary.set(entity['@id'], {
                type: 'entity-success',
                iri: entity['@id'],
                loading: false,
                ok: true,
                value: entity,
            });
        }
        for (const iri of iris) {
            this.#publish(iri);
        }
    }
    async handleResponse(res, iri = res.url.toString()) {
        const contentType = res.headers.get('content-type')?.split?.(';')?.[0];
        if (contentType == null) {
            throw new Error('Content type not specified in response');
        }
        const handler = this.#handlers.get(contentType);
        if (handler == null) {
            console.log('UNRECOGNIZED', iri, contentType);
            const integration = new UnrecognizedIntegration({
                iri,
                contentType,
            });
            let integrations = this.#integrations.get(contentType);
            if (integrations == null) {
                integrations = new Map();
                this.#integrations.set(contentType, integrations);
            }
            integrations.set(iri, integration);
        }
        else if (handler.integrationType === 'jsonld') {
            const output = await handler.handler({
                res,
                store: this,
            });
            this.#handleJSONLD({
                iri,
                res,
                output,
            });
        }
        else if (handler.integrationType === 'problem-details') {
            throw new Error('Problem details response types not supported yet');
            //} else if (handler.integrationType === 'html') {
            //  const output = await handler.handler({
            //    res,
            //    store: this,
            //  });
            //  let integrations = this.#integrations.get(contentType);
            //  if (integrations == null) {
            //    integrations = new Map();
            //    this.#integrations.set(contentType, integrations);
            //  }
            //  integrations.set(iri, new HTMLIntegration(handler, {
            //    iri,
            //    contentType,
            //    html: output.html,
            //    id: output.id,
            //  }));
        }
        else if (handler.integrationType === 'html-fragments') {
            const output = await handler.handler({
                res,
                store: this,
            });
            let integrations = this.#integrations.get(contentType);
            if (integrations == null) {
                integrations = new Map();
                this.#integrations.set(contentType, integrations);
            }
            integrations.set(iri, new HTMLFragmentsIntegration(handler, {
                iri,
                contentType,
                output,
            }));
        }
        if (handler?.integrationType !== 'jsonld') {
            this.#publish(iri, contentType);
        }
    }
    async #callFetcher(iri, args = {}) {
        let headers;
        const url = new URL(iri);
        url.hash = '';
        const method = args.method || 'get';
        const accept = args.accept ?? this.#headers.get('accept') ?? defaultAccept;
        const entity = this.entity(iri, accept);
        const etag = entity?.headers?.get('Etag');
        const dispatchURL = url.toString();
        const loadingKey = this.#getLoadingKey(dispatchURL, method, args.accept);
        if (url.origin === this.#rootOrigin) {
            headers = new Headers(this.#headers);
        }
        else if (this.#origins.has(url.origin)) {
            headers = new Headers(this.#origins.get(url.origin));
        }
        else {
            throw new Error('Unconfigured origin');
        }
        headers.set('accept', accept);
        if (args.body != null && args.contentType != null) {
            headers.set('content-type', args.contentType);
        }
        if (method === 'GET' && etag != null) {
            headers.set('If-None-Match', etag);
        }
        else if (method === 'HEAD' && etag != null) {
            headers.set('If-None-Match', etag);
        }
        this.#loading.add(loadingKey);
        mithrilRedraw();
        // This promise wrapping is so SSR can hook in and await the promise.
        const promise = new Promise((resolve) => {
            (async () => {
                let res;
                if (this.#fetcher != null) {
                    res = await this.#fetcher(dispatchURL, {
                        method,
                        headers,
                        body: args.body,
                    });
                }
                else {
                    res = await fetch(dispatchURL, {
                        method,
                        headers,
                        body: args.body,
                    });
                }
                if (!isBrowserRender &&
                    (this.#httpStatus == null || this.#httpStatus < 400) &&
                    !res.status.toString().startsWith('3')) {
                    // if SSR store the first 400+ status for the final HTTP response
                    this.#httpStatus = res.status;
                }
                if (args.accept != null && this.#acceptMap.has(dispatchURL)) {
                    this.#acceptMap
                        .get(dispatchURL)?.set(args.accept, res.headers.get('content-type'));
                }
                else if (args.accept != null) {
                    this.#acceptMap.set(dispatchURL, new Map([[args.accept, res.headers.get('content-type')]]));
                }
                await this.handleResponse(res, iri);
                this.#loading.delete(loadingKey);
                mithrilRedraw();
                resolve(res);
            })();
        });
        if (this.#responseHook != null) {
            this.#responseHook(promise);
        }
        await promise;
    }
    subscribe({ key, selector, fragment, accept, value, listener, mainEntity, }) {
        const details = getSelection({
            selector,
            fragment,
            accept,
            value,
            store: this,
        });
        const cleanup = this.#makeCleanupFn(key, details);
        for (const dependency of details.dependencies) {
            const depSet = this.#dependencies.get(dependency);
            if (depSet == null) {
                this.#dependencies.set(dependency, new Set([key]));
            }
            else {
                depSet.add(key);
            }
        }
        this.#listeners.set(key, {
            key,
            selector,
            value,
            fragment,
            accept,
            required: details.required,
            dependencies: details.dependencies,
            listener,
            cleanup,
        });
        // If this is the main entity and the details has
        // missing deps simulate a 404 if no other bad
        // status code has been set
        if (!isBrowserRender &&
            mainEntity &&
            details.hasMissing &&
            this.#httpStatus < 400) {
            this.#httpStatus = 404;
        }
        return details;
    }
    unsubscribe(key) {
        this.#listeners.get(key)?.cleanup();
    }
    async fetch(iri, accept, { mainEntity, } = {}) {
        await this.#callFetcher(iri, { accept, mainEntity });
        return this.#primary.get(iri);
    }
    /**
     * Submits an action. Like fetch this will overwrite
     * entities in the store with any entities returned
     * in the response.
     *
     * @param {string} iri                The iri of the request.
     * @param {SubmitArgs} [args]         Arguments to pass to the fetch call.
     * @param {string} [args.method]      The http submit method.
     * @param {string} [args.contentType] The content type header value.
     * @param {string} [args.body]        The body of the request.
     */
    async submit(iri, args) {
        await this.#callFetcher(iri, {
            ...args,
            contentType: 'application/ld+json',
        });
        return this.entity(iri);
    }
    /**
     * Creates an Octiron store from initial state written to the page's HTML.
     *
     * @param rootIRI       The root endpoint of the API.
     * @param [disableLogs] Disables warning and error logs if the initial state
     *                      is not present or corrupt.
     * @param [vocab]       The JSON-ld @vocab to use for Octiron selectors.
     * @param [aliases]     The JSON-ld aliases to use for Octiron selectors.
     * @param [headers]     Headers to send when making requests to endpoints sharing
     *                      origins with the `rootIRI`.
     * @param [origins]     A map of origins and the headers to use when sending
     *                      requests to them. Octiron will only send requests
     *                      to endpoints which share origins with the `rootIRI`
     *                      or are configured in the origins object. Aside
     *                      from the accept header, which has a common default
     *                      value, headers are not shared between origins.
     */
    static fromInitialState({ disableLogs, rootIRI, vocab, aliases, headers, origins, handlers = [], }) {
        performance.mark('octiron:from-initial-state:start');
        const storeArgs = {
            rootIRI,
            vocab,
            aliases,
            handlers,
            headers,
            origins,
        };
        try {
            const el = document.getElementById('oct-state');
            if (el == null) {
                if (!disableLogs) {
                    console.warn('Failed to construct Octiron state from initial state');
                }
                return new Store(storeArgs);
            }
            const stateInfo = JSON.parse(el.innerText);
            const alternatives = new Map();
            const handlersMap = handlers.reduce((acc, handler) => ({
                ...acc,
                [handler.contentType]: handler,
            }), {});
            for (const [integrationType, entities] of Object.entries(stateInfo.alternatives)) {
                for (const stateInfo of entities) {
                    const handler = handlersMap[stateInfo.contentType];
                    const cls = integrationClasses[integrationType];
                    if (cls.type !== handler.integrationType) {
                        continue;
                    }
                    const state = cls.fromInitialState(stateInfo, handler);
                    if (state == null) {
                        continue;
                    }
                    let integrations = alternatives.get(state.contentType);
                    if (integrations == null) {
                        integrations = new Map();
                        alternatives.set(state.contentType, integrations);
                    }
                    integrations.set(state.iri, state);
                }
            }
            const store = new Store({
                ...storeArgs,
                alternatives,
                primary: stateInfo.primary,
                acceptMap: stateInfo.acceptMap,
            });
            performance.mark('octiron:from-initial-state:end');
            performance.measure('octiron:from-initial-state:duration', 'octiron:from-initial-state:start', 'octiron:from-initial-state:end');
            return store;
        }
        catch (err) {
            if (!disableLogs) {
                console.warn('Failed to construct Octiron state from initial state');
                console.error(err);
            }
            const store = new Store(storeArgs);
            performance.mark('octiron:from-initial-state:end');
            performance.measure('octiron:from-initial-state:duration', 'octiron:from-initial-state:start', 'octiron:from-initial-state:end');
            return store;
        }
    }
    /**
     * Writes the Octiron store's state to a string to be embedded
     * near the end of a HTML document. Ideally this is placed before
     * the closing of the document's body tag. Octiron uses ids prefixed
     * with `oct-`, avoid using these ids to prevent id collision.
     */
    toInitialState() {
        let html = '';
        const stateInfo = {
            primary: Object.fromEntries(this.#primary),
            alternatives: {},
            acceptMap: {},
        };
        for (const [accept, map] of this.#acceptMap.entries()) {
            stateInfo.acceptMap[accept] = Array.from(map.entries());
        }
        for (const alternative of this.#integrations.values()) {
            for (const integration of alternative.values()) {
                if (stateInfo.alternatives[integration.integrationType] == null) {
                    stateInfo.alternatives[integration.integrationType] = [
                        integration.getStateInfo(),
                    ];
                }
                else {
                    stateInfo.alternatives[integration.integrationType].push(integration.getStateInfo());
                }
                if (integration.toInitialState != null)
                    html += integration.toInitialState();
            }
        }
        html += `<script id="oct-state" type="application/json">${JSON.stringify(stateInfo)}</script>`;
        return html;
    }
}

/**
 * @description
 * Aggregates a list of type defs into an easier to access
 * type def config object.
 *
 * @param typeDefs The type defs to aggregate.
 */
function makeTypeDefs(
// deno-lint-ignore no-explicit-any
storeOrTypeDef, ...typeDefs) {
    const config = {};
    if (storeOrTypeDef instanceof Store) {
        for (const typeDef of typeDefs) {
            // deno-lint-ignore no-explicit-any
            config[storeOrTypeDef.expand(typeDef.type)] = typeDef;
        }
    }
    else {
        // deno-lint-ignore no-explicit-any
        config[storeOrTypeDef.type] = storeOrTypeDef;
        for (const typeDef of typeDefs) {
            // deno-lint-ignore no-explicit-any
            config[typeDef.type] = typeDef;
        }
    }
    return config;
}

/**
 * Merges arguments into a single css class string
 */
function classes(...classArgs) {
    const cls = [];
    for (const classArg of classArgs) {
        if (typeof classArg === 'undefined' || classArg === null) {
            continue;
        }
        else if (typeof classArg === 'string') {
            cls.push(classArg);
        }
        else if (Array.isArray(classArg)) {
            for (const name of classArg) {
                cls.push(name);
            }
        }
        else {
            for (const [name, active] of Object.entries(classArg)) {
                if (active) {
                    cls.push(name);
                }
            }
        }
    }
    return cls.join(' ');
}

/**
 * @description
 * Utility for creating a well typed typeDef.
 *
 * @param typeDef An object to property define the types for.
 */
function makeTypeDef(typeDef) {
    return typeDef;
}

const jsonLDHandler = {
    integrationType: 'jsonld',
    contentType: 'application/ld+json',
    handler: async ({ res }) => {
        const json = await res.json();
        // cannot use json-ld ops on scalar types
        if (!isJSONObject(json) && !Array.isArray(json)) {
            throw new Error('JSON-LD Document should be an object');
        }
        const expanded = await jsonld.expand(json, {
            documentLoader: async (url) => {
                const res = await fetch(url, {
                    headers: {
                        'accept': 'application/ld+json',
                    }
                });
                const document = await res.json();
                return {
                    documentUrl: url,
                    document,
                };
            }
        });
        const compacted = await jsonld.compact(expanded, {});
        return {
            jsonld: compacted,
        };
    },
};

const longformHandler = {
    integrationType: 'html-fragments',
    contentType: 'text/longform',
    handler: async ({ res }) => {
        return longform(await res.text());
    },
};

const OctironJSON = () => {
    function renderIRI(iri) {
        return m('code', [
            m('span.oct-json-quote', '"'),
            m('a.oct-json-iri', {
                href: iri,
            }, iri),
            m('span.oct-json-quote', '"'),
        ]);
    }
    function renderPrimitive(value) {
        const className = typeof value === 'boolean'
            ? 'oct-json-boolean'
            : typeof value === 'number'
                ? 'oct-json-number'
                : 'oct-json-string';
        let presentValue;
        if (typeof value === 'boolean' && value) {
            presentValue = 'true';
        }
        else if (typeof value === 'boolean') ;
        else if (typeof value === 'string') {
            presentValue = [
                m('span.oct-json-quote', '"'),
                value,
                m('span.oct-json-quote', '"'),
            ];
        }
        else {
            presentValue = value;
        }
        return m('code', { className }, presentValue);
    }
    function renderArray(list, url, selector = '') {
        const children = [];
        for (let index = 0; index < list.length; index++) {
            const value = list[index];
            children.push(m('li.oct-json-arr-item', maybeRenderDetails(null, value, url, selector)));
        }
        return m('ul.oct-json-arr', children);
    }
    const terminalTypes = ['@id', '@type', '@context'];
    function renderObject(value, url, selector = '') {
        const items = [];
        const list = Object.entries(value);
        list.sort();
        for (let index = 0; index < list.length; index++) {
            const [term, value] = list[index];
            let children;
            const summary = [
                m('span.oct-json-quote', '"'),
                m('span.oct-json-obj-key', term),
                m('span.oct-json-quote', '"'),
                m('span.oct-json-obj-colon', ': '),
            ];
            if (term === '@id') {
                children = [m('code', summary), renderIRI(value)];
            }
            else if (url == null || terminalTypes.includes(term)) {
                children = maybeRenderDetails(summary, value);
            }
            else if (term.startsWith('@')) {
                children = maybeRenderDetails(summary, value, url, selector);
            }
            else {
                const currentSelector = `${selector} ${term}`;
                const currentURL = new URL(url);
                currentURL.searchParams.set('selector', currentSelector);
                const summary = [
                    m('span.oct-json-quote', '"'),
                    m('span.oct-json-obj-key', m('a', { href: currentURL }, term)),
                    m('span.oct-json-quote', '"'),
                    m('span.oct-json-obj-colon', ': '),
                ];
                children = maybeRenderDetails(summary, value, url, currentSelector);
            }
            items.push(m('li.oct-json-obj-item', children));
        }
        return m('ul.oct-json-obj', items);
    }
    function maybeRenderDetails(summary, value, url, selector = '') {
        if (isJSONObject(value)) {
            return [
                m('details.oct-json-details', { open: true }, m('summary.oct-json-details-sum', m('code', summary, m('span.oct-json-obj-open', '{'))), renderValue(value, url, selector)),
                m('code.oct-json-obj-close', '}'),
            ];
        }
        else if (Array.isArray(value)) {
            return [
                m('details.oct-json-details', { open: true }, m('summary.oct-json-details-sum', m('code', summary, m('span.oct-json-obj-open', '['))), renderValue(value, url, selector)),
                m('code.oct-json-obj-close', ']'),
            ];
        }
        return [m('code', summary), renderValue(value, url, selector)];
    }
    function renderValue(value, url, selector = '') {
        if (isJSONObject(value)) {
            return renderObject(value, url, selector);
        }
        else if (Array.isArray(value)) {
            return renderArray(value, url, selector);
        }
        return renderPrimitive(value);
    }
    return {
        view: ({ attrs: { value, selector, location } }) => {
            const url = location != null ? new URL(location) : undefined;
            return m('.oct-json', [
                maybeRenderDetails(null, value, url, typeof selector === 'string' ? selector.trim() : undefined),
            ]);
        },
    };
};

const OctironDebug = ({ attrs, }) => {
    let currentAttrs = attrs;
    let value = attrs.o.value;
    let rendered;
    let presentationStyle = attrs.initialPresentationStyle ?? 'value';
    function onRender(redraw = true) {
        const { o } = currentAttrs;
        if (presentationStyle === 'value') {
            rendered = m(OctironJSON, {
                value,
                selector: currentAttrs.selector,
                location: currentAttrs.location,
            });
        }
        else if (presentationStyle === 'action-value' && (o.octironType === 'action' ||
            o.octironType === 'action-selection')) {
            rendered = m(OctironJSON, { value: o.actionValue.value, selector: currentAttrs.selector, location: currentAttrs.location });
        }
        if (redraw) {
            mithrilRedraw();
        }
    }
    function onSetValue(e) {
        e.redraw = false;
        presentationStyle = 'value';
        onRender();
    }
    function onSetActionValue(e) {
        e.redraw = false;
        presentationStyle = 'action-value';
        onRender();
    }
    function onSetComponent(e) {
        e.redraw = false;
        presentationStyle = 'component';
        onRender();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            onRender(false);
        },
        onbeforeupdate: ({ attrs }) => {
            if (attrs.o.value !== value) {
                value = attrs.o.value;
                onRender(true);
            }
        },
        view: ({ attrs: { o, availableControls } }) => {
            let children;
            let actionValueAction;
            const controls = [];
            if (presentationStyle === 'component') {
                children = m('.oct-debug-body', o.default());
            }
            else {
                children = m('.oct-debug-body', rendered);
            }
            if (o.octironType === 'action' || o.octironType === 'action-selection') {
                actionValueAction = m('button.oct-button', { type: 'button', onclick: onSetActionValue }, 'Action value');
            }
            if (availableControls == null || availableControls.includes('value')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: onSetValue }, 'Value'));
            }
            else if (actionValueAction != null && (availableControls == null ||
                availableControls.includes('action-value'))) {
                controls.push(actionValueAction);
            }
            else if (availableControls == null || availableControls.includes('component')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: onSetComponent }, 'Component'));
            }
            else if (availableControls == null || availableControls.includes('log')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: () => console.debug(o) }, 'Log'));
            }
            return m('aside.oct-debug', m('.oct-debug-controls', m('.oct-button-group', ...controls)), children);
        },
    };
};

const OctironExplorer = ({ attrs, }) => {
    let value = attrs.selector || '';
    let previousSelector = value;
    let selector = value;
    let presentationStyle = 'value';
    let onChange = attrs.onChange;
    const fallbackComponent = {
        view: ({ attrs: { o } }) => {
            return m(OctironDebug, { o, location: attrs.location });
        },
    };
    function onSearch(evt) {
        value = evt.target.value;
    }
    function onEnter(evt) {
        if (evt.key === 'Enter') {
            onApply();
        }
    }
    function onApply() {
        selector = value;
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    function onSetValue(evt) {
        evt.preventDefault();
        presentationStyle = 'value';
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    function onSetActionValue(evt) {
        evt.preventDefault();
        presentationStyle = 'action-value';
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    return {
        oninit: ({ attrs }) => {
            onChange = attrs.onChange;
        },
        onbeforeupdate: ({ attrs }) => {
            selector = attrs.selector ?? '';
            if (selector !== previousSelector) {
                value = previousSelector = selector;
            }
            onChange = attrs.onChange;
        },
        view: ({ attrs: { autofocus, o } }) => {
            let children;
            let upURL;
            let valueURL;
            let actionValueURL;
            if (selector.length !== 0 && presentationStyle === 'value') {
                children = o.root(selector, (o) => m(OctironDebug, {
                    o,
                    selector,
                    location: attrs.location,
                    initialPresentationStyle: attrs.presentationStyle,
                    availableControls: !!attrs.childControls == false ? undefined : [],
                }));
            }
            else if (selector.length !== 0) {
                children = o.root(selector, (o) => m('div', o.default({ fallbackComponent, attrs: { selector } })));
            }
            else if (presentationStyle === 'value') {
                children = o.root((o) => m(OctironDebug, {
                    o,
                    selector,
                    location: attrs.location,
                    initialPresentationStyle: attrs.presentationStyle,
                    availableControls: !!attrs.childControls ? undefined : [],
                }));
            }
            else {
                children = o.root((o) => m('div', o.default({ fallbackComponent, attrs: { selector } })));
            }
            if (attrs.location != null && selector.length !== 0) {
                const upSelector = attrs.selector.trim().includes(' ')
                    ? attrs.selector.replace(/\s+([^\s]+)$/, '')
                    : '';
                upURL = new URL(attrs.location);
                if (upSelector != null) {
                    upURL.searchParams.set('selector', upSelector);
                }
                else {
                    upURL.searchParams.delete('selector');
                }
            }
            if (attrs.location != null) {
                valueURL = new URL(attrs.location);
                actionValueURL = new URL(attrs.location);
                valueURL.searchParams.set('presentationStyle', 'value');
                actionValueURL.searchParams.set('presentationStyle', 'action-value');
            }
            return m('.oct-explorer', m('.oct-explorer-controls', m('form.oct-form-group', {
                action: attrs.location?.toString?.(),
                onsubmit: (evt) => {
                    evt.preventDefault();
                    onApply();
                },
            }, [
                upURL != null
                    ? m('a.oct-button', { href: upURL.toString() }, 'Up')
                    : m('button.oct-button', { type: 'button', disabled: true }, 'Up'),
                m('input', {
                    name: 'selector',
                    value,
                    autofocus,
                    oninput: onSearch,
                    onkeypress: onEnter,
                }),
                m('button.oct-button', {
                    type: 'submit',
                    disabled: selector === value && typeof window !== 'undefined',
                }, 'Apply'),
            ]), m('.oct-button-group', presentationStyle === 'value' || valueURL == null
                ? m('button.oct-button', {
                    type: 'button',
                    disabled: typeof window === 'undefined',
                    onclick: onSetValue,
                }, 'Value')
                : m('a.oct-button', {
                    href: valueURL.toString(),
                    onclick: onSetValue,
                }, 'Value'), presentationStyle === 'action-value' || actionValueURL == null
                ? m('button.oct-button', {
                    type: 'button',
                    disabled: typeof window === 'undefined',
                    onclick: onSetActionValue,
                }, 'Action value')
                : m('a.oct-button', {
                    href: actionValueURL.toString(),
                    onclick: onSetActionValue,
                }, 'Action value'))), m('pre.oct-explorer-body', children));
        },
    };
};

const OctironForm = (vnode) => {
    const o = vnode.attrs.o;
    const method = o.method?.toUpperCase() || 'POST';
    const enctypes = {
        GET: 'application/x-www-form-urlencoded',
        POST: 'multipart/form-data',
    };
    return {
        view: ({ attrs: { o, ...attrs }, children }) => {
            return m('form.oct-form', {
                ...attrs,
                method,
                enctype: enctypes[method],
                action: o.url,
                onsubmit: (evt) => {
                    evt.preventDefault();
                    o.submit();
                },
            }, children);
        },
    };
};

const OctironSubmitButton = () => {
    return {
        view: ({ attrs, children }) => {
            return m('button.oct-button.oct-submit-button', {
                id: attrs.id,
                type: 'submit',
                class: classes(attrs.class),
            }, children);
        },
    };
};

/**
 * Creates a root octiron instance.
 */
function octiron({ typeDefs, ...storeArgs }) {
    const store = new Store(storeArgs);
    const config = typeDefs != null
        ? makeTypeDefs(store, ...typeDefs)
        : {};
    return rootFactory({
        store,
        typeDefs: config,
    });
}
octiron.fromInitialState = ({ typeDefs, ...storeArgs }) => {
    const store = Store.fromInitialState({
        ...storeArgs,
    });
    const config = typeDefs != null
        ? makeTypeDefs(store, ...typeDefs)
        : {};
    return rootFactory({
        store,
        typeDefs: config,
    });
};

export { OctironDebug, OctironExplorer, OctironForm, OctironJSON, OctironSubmitButton, Store, classes, jsonLDHandler, longformHandler, makeTypeDef, makeTypeDefs, octiron };
//# sourceMappingURL=octiron.js.map
