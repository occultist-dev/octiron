import m from 'mithril';
import { isJSONObject as isJSONObject$1 } from '@occultist/mini-jsonld';
import { JsonPointer } from 'json-ptr';
import uriTemplates from 'uri-templates';

/**
  * Creates an Octiron selection instance.
  *
  * @param args - User specified args passed to the Octiron method creating the factory.
  * @param parentArgs - Args passed from the Octiron parent instance of this instance.
  * @param rendererArgs - Args passed from the Mithril renderer component.
  */
function selectionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign(Object.create(null), args);
    const childArgs = {
        // value: parentArgs.value,
        value: rendererArgs.value,
    };
    const res = octironFactory('selection', {
        factoryArgs,
        parentArgs,
        rendererArgs,
        childArgs,
    });
    Object.seal(res[0]);
    return res;
}

/**
 * @description
 * Returns a component based of Octiron's selection rules:
 *
 * 1. If the first pick component is given, return it.
 * 2. If a typedef is defined for the propType (jsonld term or type)
 *    for the given style, return it.
 * 3. If a typedef is defined for the (or one of the) types (jsonld '@type')
 *    value for the given style, return it.
 * 4. If a fallback component is given, return it.
 *
 * @param args.style - The style of presentation.
 * @param args.propType - The propType the component should be configured to
 *                        handle.
 * @param args.type - The type the component should be configured to handle.
 * @param args.firstPickComponent - The component to use if passed by upstream.
 * @param args.fallbackComponent - The component to use if no other component
 *                                 is picked.
 */
function getComponent({ style, propType, type, firstPickComponent, typeHandlers, fallbackComponent, }) {
    if (firstPickComponent != null) {
        return firstPickComponent;
    }
    if (propType != null &&
        typeHandlers[propType]?.[style] != null) {
        return typeHandlers[propType][style];
    }
    if (!Array.isArray(type) &&
        type != null &&
        typeHandlers[type]?.[style] != null) {
        return typeHandlers[type][style];
    }
    if (Array.isArray(type)) {
        for (const item of type) {
            if (typeHandlers[item]?.[style] != null) {
                return typeHandlers[item][style];
            }
        }
    }
    if (fallbackComponent != null) {
        return fallbackComponent;
    }
}

/**
 * @description
 * Returns true if the input value is an object.
 *
 * @param value Any value which should come from a JSON source.
 */
function isJSONObject(value) {
    return typeof value === 'object' && !Array.isArray(value) && value !== null;
}

/**
 * @description
 * Returns true if the given value is a JSON object with a JSON-ld @type value.
 *
 * @param value Any value which should come from a JSON source.
 */
function isTypeObject(value) {
    if (!isJSONObject(value)) {
        return false;
    }
    else if (typeof value['@type'] === 'string') {
        return true;
    }
    else if (!Array.isArray(value['@type'])) {
        return false;
    }
    for (const item of value['@type']) {
        if (typeof item !== 'string') {
            return false;
        }
    }
    return true;
}

/**
 * @description
 * Returns the type value of the input if it is a type object.
 *
 * @param value A JSON value which might be a typed JSON-ld object.
 */
function getDataType(value) {
    if (isTypeObject(value)) {
        return value['@type'];
    }
}

/**
 * Selects the component and attrs to render with from args provided to an Octiron
 * factory instance or the render method.
 */
const selectComponentFromArgs = (style, parentArgs, rendererArgs, args, factoryArgs) => {
    const attrs = Object.assign({}, args?.attrs ?? factoryArgs?.attrs);
    // null for a component arg indicates this is being called by a `o.default()` method
    // which will cause infinite recursion if it ends up re-selecting itself via factory args.
    const firstPickComponent = (args?.component ?? (args?.component !== null ? factoryArgs?.component : null));
    const fallbackComponent = (args?.fallbackComponent ?? (args?.component !== null ? factoryArgs?.fallbackComponent : null));
    const component = getComponent({
        style,
        propType: rendererArgs?.propType,
        type: getDataType(rendererArgs.value),
        firstPickComponent,
        fallbackComponent,
        typeHandlers: args?.typeHandlers ?? parentArgs.typeHandlers,
    });
    return [attrs, component];
};

const EditRenderer = ({ attrs: { args, factoryArgs, parentArgs, rendererArgs, }, }) => {
    const [attrs, component] = selectComponentFromArgs('edit', parentArgs, rendererArgs, args, factoryArgs);
    return {
        view({ attrs: { o, rendererArgs }, children }) {
            if (component == null) {
                return null;
            }
            // deno-lint-ignore no-explicit-any
            return m(component, {
                o,
                attrs,
                renderType: "edit",
                name: o.inputName,
                value: rendererArgs.value,
                spec: rendererArgs.spec,
                onchange: rendererArgs.update,
                onChange: rendererArgs.update,
            }, children);
        },
    };
};

/**
 * Expands a object's keys to be their RDF type equivlent.
 *
 * @param store   - An Octiron store with expansion context.
 * @param value   - A JSON object to expand.
 */
function expandValue(store, value) {
    let expanded = Object.create(null);
    for (let [key, item] of Object.entries(value)) {
        if (item != null) {
            expanded[store.expand(key)] = item;
        }
    }
    return expanded;
}

/**
 * @description
 * Returns true if a json-ld value is an array or has an iterable value,
 * i.e.: an object with an `@list` or `@set` array value.
 *
 * This function returns an empty array in the cases where a non-iterable value
 * is given.
 *
 * @param {JSONValue} value - A json-ld value
 */
function getIterableValue(value) {
    if (Array.isArray(value)) {
        return value;
    }
    else if (Array.isArray(value['@list'])) {
        return value['@list'];
    }
    else if (Array.isArray(value['@set'])) {
        return value['@set'];
    }
    return [];
}

/**
 * @description
 * Returns true if a json-ld value is an array or has an iterable value,
 * i.e.: an object with an `@list` or `@set` array value.
 *
 * @param {JSONValue} value - A json-ld value
 */
function isIterable(value) {
    if (Array.isArray(value)) {
        return true;
    }
    else if (isJSONObject(value)) {
        if (Array.isArray(value["@list"])) {
            return true;
        }
        else if (Array.isArray(value["@set"])) {
            return true;
        }
    }
    return false;
}

let isBrowserRender = typeof window !== 'undefined';

/**
 * @description
 * Calls Mithril's redraw function if the window object exists.
 */
function mithrilRedraw() {
    if (isBrowserRender) {
        m.redraw();
    }
}

/**
 * @description
 * Numerous Octiron view functions take a combination of string selector,
 * object args and function view arguments.
 *
 * This `unravelArgs` identifies which arguments are present and returns
 * defaults for the missing arguments.
 *
 * @param arg1 - A selector string, args object or view function if present.
 * @param arg2 - An args object or view function if present.
 * @param arg3 - A view function if present.
 */
function unravelArgs(arg1, arg2, arg3) {
    let selector;
    let args = {};
    let view;
    if (typeof arg1 === "string") {
        selector = arg1;
    }
    else if (typeof arg1 === "function") {
        view = arg1;
    }
    else if (arg1 != null) {
        args = arg1;
    }
    if (typeof arg2 === 'function') {
        view = arg2;
    }
    else if (arg2 != null) {
        args = arg2;
    }
    if (typeof arg3 === 'function') {
        view = arg3;
    }
    if (typeof view === "undefined") {
        view = ((o) => o.default(args));
    }
    return [
        selector,
        args,
        view,
    ];
}

function actionSelectionFactory(args, parentArgs, rendererArgs) {
    const factoryArgs = Object.assign({}, args);
    const childArgs = {
        action: parentArgs.action,
        submitting: parentArgs.submitting,
        value: rendererArgs.value,
    };
    const refs = {
        factoryArgs,
        parentArgs,
        rendererArgs,
        childArgs,
    };
    const [self, hooks] = octironFactory('action-selection', refs);
    self.readonly = rendererArgs.spec == null ? true : (rendererArgs.spec.readonly ?? false);
    self.inputName = rendererArgs.spec?.name != null ? rendererArgs.spec?.name : rendererArgs.propType;
    self.submitting = parentArgs.submitting;
    self.action = parentArgs.action;
    childArgs.updatePointer = (pointer, value, args, interceptor = factoryArgs.interceptor) => {
        const prev = refs.rendererArgs.value;
        if (!isJSONObject(prev)) {
            console.warn(`Non object action change intercepted.`);
            return;
        }
        let next = Object.assign({}, prev);
        const ptr = JsonPointer.create(pointer);
        if (value == null) {
            ptr.unset(next);
        }
        else {
            ptr.set(next, value, true);
        }
        if (typeof interceptor === 'function') {
            next = interceptor({
                next,
                prev,
                o: self,
                actionValue: self.actionValue.value,
            });
            if (next === false)
                return;
        }
        refs.parentArgs.updatePointer(refs.rendererArgs.pointer, next, args);
    };
    self.update = async (arg1, args) => {
        const value = refs.rendererArgs.value;
        if (!isJSONObject(value)) {
            throw new Error(`Cannot call update on a non object selection instance`);
        }
        if (typeof arg1 === 'function') {
            refs.rendererArgs.update(arg1(value));
        }
        else if (arg1 != null) {
            refs.rendererArgs.update(arg1);
        }
        if (args?.submit || args?.submitOnChange) {
            await refs.parentArgs.submit();
        }
        else {
            mithrilRedraw();
        }
    };
    self.submit = () => {
        return refs.parentArgs.submit();
    };
    self.select = (arg1, arg2, arg3) => {
        if (!isJSONObject(refs.rendererArgs.value)) {
            return null;
        }
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(ActionSelectionRenderer, {
            parentArgs: childArgs,
            selector,
            value: refs.rendererArgs.value,
            actionValue: refs.rendererArgs.actionValue.value,
            args,
            view,
        });
    };
    self.edit = (args) => {
        if (self.readonly) {
            return self.present(args);
        }
        return m(EditRenderer, {
            o: self,
            args,
            factoryArgs,
            parentArgs: refs.parentArgs,
            rendererArgs: refs.rendererArgs,
        });
    };
    self.default = (args) => {
        return self.edit(Object.assign({ component: null }, args));
    };
    self.initial = parentArgs.action.initial;
    self.success = parentArgs.action.success;
    self.failure = parentArgs.action.failure;
    self.remove = (_args = {}) => {
        if (refs.rendererArgs.propType == null) {
            return;
        }
        const parentValue = refs.parentArgs.parent.value;
        const value = parentValue[refs.rendererArgs.propType];
        if (isIterable(value)) {
            const arrValue = getIterableValue(value);
            arrValue.splice(self.index, 1);
            if (arrValue.length === 0) {
                delete parentValue[refs.rendererArgs.propType];
            }
        }
        else if (isJSONObject(value)) {
            delete parentValue[refs.rendererArgs.propType];
        }
        mithrilRedraw();
    };
    self.append = (termOrType, value = {}, args = {}) => {
        if (!isJSONObject(refs.rendererArgs.value)) {
            console.warn(`Attempt to append to non object octiron selection ${termOrType}`);
            return;
        }
        let nextValue;
        const type = refs.parentArgs.store.expand(termOrType);
        const lastValue = refs.rendererArgs.value[type];
        if (isJSONObject(value)) {
            value = expandValue(self.store, value);
        }
        if (lastValue == null) {
            nextValue = value;
        }
        else if (Array.isArray(lastValue)) {
            nextValue = [...lastValue, value];
        }
        else {
            nextValue = [lastValue, value];
        }
        return refs.parentArgs.updatePointer(refs.rendererArgs.pointer, Object.assign({}, refs.rendererArgs.value, { [type]: nextValue }), args);
    };
    const wrappedHooks = {
        argsChanged: () => {
            hooks.argsChanged();
        },
        parentArgsChanged: () => {
            hooks.parentArgsChanged();
            self.submitting = parentArgs.submitting;
            self.action = parentArgs.action;
        },
        rendererArgsChanged: () => {
            self.index = refs.rendererArgs.index;
            self.readonly = rendererArgs.spec == null ? true : (rendererArgs.spec.readonly ?? false);
            self.inputName = rendererArgs.spec?.name != null ? rendererArgs.spec?.name : rendererArgs.propType;
        },
    };
    return [self, wrappedHooks];
}

/**
 * @description
 * Espects a list of json pointer parts and returns a json pointer.
 */
function escapeJSONPointerParts(...parts) {
    const escaped = parts
        .map((part) => part.replace(/~/g, '~0').replace(/\//g, '~1'))
        .join('/');
    return `${escaped}`;
}

/**
 * @description
 * Returns true if the given value is a JSON object with a JSON-ld @id value.
 *
 * @param value Any value which should come from a JSON source.
 */
function isIRIObject(value) {
    return isJSONObject(value)
        && typeof value['@id'] === 'string'
        && value['@id'] !== '';
}

/**
 * @description
 * Some JSON-ld objects contain special JSON-ld values, such as @type which
 * can inform the software on what to expect when retrieving the object but
 * otherwise require fetching an entity from an endpoint to get the values
 * they relate to. For Octiron's purposes these are considered metadata objects.
 *
 * Objects containing `@value`, `@list`, `@set` are not considered metadata
 * objects as these properties references concrete values.
 *
 * @param value - The JSON object to check for non special properties in.
 */
function isMetadataObject(value) {
    const keys = Object.keys(value);
    if (keys.length === 0) {
        return false;
    }
    for (const term of keys) {
        if (!term.startsWith("@") ||
            term === '@value' ||
            term === '@list' ||
            term === '@set') {
            return false;
        }
    }
    return true;
}

/**
 * @description
 * A value object contains a `@value` value. Often this is used to provide
 * further information about the value like what `@type` it holds, allowing
 * filters to be applied to the referenced value.
 *
 * @param value - A JSON value.
 */
function isValueObject(value) {
    return typeof value['@value'] !== 'undefined';
}

const selectorRe = /\s*(?<subject>([^\[\s]+))(\[(?<filter>([^\]])+)\])?\s*/g;
/**
 * @description
 * Parses a selector string producing a selector list
 * The subject value of a selector could be an iri or a type depending on the
 * outer context.
 *
 * @param selector - The selector string to parse.
 */
function parseSelectorString(selector, store) {
    let match;
    const selectors = [];
    while ((match = selectorRe.exec(selector))) {
        const subject = match.groups?.subject;
        const filter = match.groups?.filter;
        if (typeof filter === 'string' && typeof subject === 'string') {
            selectors.push({
                subject: subject === '@id' ? '@id' : store.expand(subject),
                filter,
            });
        }
        else if (typeof subject === 'string') {
            selectors.push({
                subject: subject === '@id' ? '@id' : store.expand(subject),
            });
        }
        else {
            throw new Error(`Invalid selector: ${selector}`);
        }
    }
    return selectors;
}

const httpRe = /^https?\:\/\//;
const scmCtxRe = /^https?\:\/\/schema\.org/;
const scmTypeRe = /^https?\:\/\/schema\.org\/(?<term>(readonlyValue|valueName|valueRequired|defaultValue|minValue|maxValue|stepValue|valuePattern|multipleValues|valueMinLength|valueMaxLength))/;
function resolvePropertyValueSpecification({ spec, store, }) {
    const pvs = {
        readonlyValue: false,
        valueRequired: false,
    };
    let scmAlias;
    const scmVocab = store.vocab == null ? false : scmCtxRe.test(store.vocab);
    for (const [key, value] of Object.entries(store.aliases)) {
        if (scmCtxRe.test(value)) {
            scmAlias = [key, value];
            break;
        }
    }
    for (const [term, value] of Object.entries(spec)) {
        let type;
        if (!httpRe.test(term)) {
            if (scmVocab && !term.includes(':')) {
                type = `${store.vocab}${term}`;
            }
            else if (scmAlias && term.startsWith(`${scmAlias[0]}:`)) {
                type = term.replace(`${scmAlias[0]}:`, scmAlias[1]);
            }
        }
        else {
            type = term;
        }
        if (!type) {
            continue;
        }
        const result = scmTypeRe.exec(type);
        if (result?.groups?.term) {
            pvs[result.groups.term] = value;
        }
    }
    return {
        readonly: pvs.readonlyValue,
        required: pvs.valueRequired,
        name: pvs.valueName,
        min: pvs.minValue,
        max: pvs.maxValue,
        step: pvs.stepValue,
        pattern: pvs.valuePattern,
        multiple: pvs.multipleValues,
        minLength: pvs.valueMinLength,
        maxLength: pvs.valueMaxLength,
    };
}

/**
 * A circular selection error occurs when two or more
 * entities contain no concrete values and their '@id'
 * values point to each other in a way that creates a
 * loop. The `getSelection` function will throw when
 * this scenario is detected to prevent an infinite
 * loop.
 */
class CircularSelectionError extends Error {
}
/**
 * @description
 * Selects from the given context value and store state.
 *
 * If no `value` is provided the `selector` is assumed to begin with an iri
 * instead of a type. An entity will be selected from the store using the iri,
 * if it exists, to begin the selection.
 *
 * A type selector selects values from the context of a provided value
 * and will pull from the store if any iri objects are selected in the process.
 *
 * @param {string} args.selector            Selector string beginning with a type.
 * @param {string} [args.fragment]          A fragment if passed in as select args.
 * @param {JSONObject} [args.value]         Context object to begin the selection from.
 * @param {JSONObject} [args.actionValue]   The action, or point in the action definition which describes this value.
 * @param {JSONValue} [args.defaultValue]   A default value when used to select action values.
 * @param {StoreType} args.store                Octiron store to search using.
 * @returns {SelectionDetails}              Selection contained in a details object.
 */
function getSelection({ selector: selectorStr, value, fragment, accept, actionValue, defaultValue, store, }) {
    const details = {
        selector: selectorStr,
        complete: false,
        isProblem: false,
        hasErrors: false,
        hasMissing: false,
        required: [],
        dependencies: [],
        result: [],
    };
    if (value == null) {
        const [{ subject, filter }, ...selector] = parseSelectorString(selectorStr, store);
        const [iri, iriFragment] = subject.split('#');
        selectEntity({
            pointer: '',
            iri,
            fragment: fragment ?? iriFragment,
            accept,
            filter,
            selector: selector.length > 0 ? selector : undefined,
            store,
            details,
        });
        details.complete = details.required.length === 0;
        return details;
    }
    const selector = parseSelectorString(selectorStr, store);
    traverseSelector({
        key: '',
        pointer: '',
        fragment,
        accept,
        value,
        actionValue,
        selector,
        store,
        details,
        defaultValue,
    });
    details.complete = details.required.length === 0;
    return details;
}
function makePointer(pointer, addition) {
    return `${pointer}/${escapeJSONPointerParts(addition.toString())}`;
}
function updateKey(key, addition) {
    return `${key}[${addition}]`;
}
/**
 * Filters apply to objects with `@type` properties. These can be strings or
 * arrays of strings and are considered a pass if any of the values match the
 * filter.
 *
 * If an object is provided which does not contain an `@type` property it is
 * considered a fail.
 */
function passesFilter({ value, filter, }) {
    if (typeof filter !== 'string') {
        return true;
    }
    if (Array.isArray(value['@type'])) {
        return value['@type'].includes(filter);
    }
    return value['@type'] === filter;
}
/**
 * If a scala value is pulled before a selection is complete the branch
 * can exit early.
 */
function isTraversable(value) {
    return (value !== null &&
        typeof value !== 'boolean' &&
        typeof value !== 'number' &&
        typeof value !== 'string');
}
/**
 * Handles the final value found in a selection.
 * If a @id, @value jsonld object is provided further
 * recursion might be nessacary.
 */
function resolveValue({ key, pointer, accept, fragment, value, propType, filter, spec, actionValue, store, details, }) {
    if (value === undefined) {
        details.hasMissing = true;
        return;
    }
    else if (value === null && isJSONObject(actionValue)) {
        for (const item of Object.values(actionValue)) {
            if (isTypeObject(item) && item["@type"] === 'https://schema.org/PropertyValueSpecification') {
                return;
            }
        }
    }
    if (spec != null && (
    // hit the for loop below if the action value
    // has editable properties and the value is an
    // array
    !isIterable(value) || !isJSONObject(actionValue))) {
        const pvs = resolvePropertyValueSpecification({
            spec,
            store,
        });
        if (isJSONObject(value) && isValueObject(value)) {
            value = value['@value'];
        }
        details.result.push({
            key,
            pointer,
            type: 'action-value',
            propType,
            value,
            actionValue,
            spec: pvs,
            readonly: pvs.readonly,
        });
        return;
    }
    if (!isTraversable(value)) {
        details.result.push({
            key,
            pointer: pointer,
            type: 'value',
            propType,
            value,
            readonly: true,
        });
        return;
    }
    else if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            let finalKey = key;
            const item = list[index];
            if (!isIRIObject(item)) {
                finalKey = updateKey(key, index);
            }
            else {
                finalKey = item['@id'];
            }
            resolveValue({
                key: finalKey,
                pointer: makePointer(pointer, index),
                accept,
                fragment,
                value: item,
                spec,
                actionValue,
                propType,
                filter,
                store,
                details,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    if (typeof filter === 'string' && !passesFilter({ value, filter })) {
        return;
    }
    if (isValueObject(value)) {
        resolveValue({
            key,
            pointer,
            accept,
            fragment,
            value: value['@value'],
            propType,
            store,
            details,
        });
        return;
    }
    else if (isMetadataObject(value)) {
        selectEntity({
            pointer,
            iri: value['@id'],
            filter,
            accept,
            fragment,
            store,
            details,
        });
        return;
    }
    if (isIRIObject(value)) {
        const iri = value['@id'];
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri,
            ok: true,
            value,
            contentType: undefined,
        });
        return;
    }
    details.result.push({
        key,
        pointer,
        type: 'value',
        readonly: true,
        propType,
        value,
    });
}
/**
 * Selects a type from a json value, handling invalid situations.
 */
function selectTypedValue({ key, pointer, accept, fragment, propType, value, actionValue, filter, store, details, }) {
    pointer = makePointer(pointer, propType);
    if (!isTraversable(value)) {
        return;
    }
    if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = updateKey(key, index);
            }
            selectTypedValue({
                key,
                pointer: makePointer(pointer, index),
                accept,
                fragment,
                propType,
                value: item,
                actionValue,
                filter,
                store,
                details,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    if (isMetadataObject(value) && isIRIObject(value)) {
        selectEntity({
            pointer,
            iri: value['@id'],
            selector: [{ subject: propType, filter }],
            accept,
            fragment,
            store,
            details,
        });
        return;
    }
    else if (isMetadataObject(value)) {
        return;
    }
    let spec;
    if (isJSONObject(actionValue) && actionValue[`${propType}-input`] == null) {
        // selecting for an action but the type is not editable
        return;
    }
    else if (isJSONObject(actionValue)) {
        spec = actionValue[`${propType}-input`];
    }
    resolveValue({
        key,
        pointer,
        accept,
        fragment,
        value: value[propType],
        spec,
        actionValue: actionValue?.[propType],
        propType,
        filter,
        store,
        details,
    });
}
/**
 * Recurses through the selection until there are no further selection items.
 */
function traverseSelector({ key, pointer, selector, accept, fragment, value, actionValue, store, details, defaultValue, }) {
    if (selector.length === 0) {
        return;
    }
    else if (!isTraversable(value)) {
        return;
    }
    if (isIterable(value)) {
        const list = getIterableValue(value);
        for (let index = 0; index < list.length; index++) {
            const item = list[index];
            if (!isIRIObject(item)) {
                key = updateKey(key, index);
            }
            // keep nesting on the full selector
            // as only objects can be subscripted
            // with propTypes
            traverseSelector({
                key,
                pointer: makePointer(pointer, index),
                selector,
                accept,
                fragment,
                value: item,
                actionValue,
                store,
                details,
                defaultValue,
            });
            if (details.hasErrors || details.hasMissing) {
                return;
            }
        }
        return;
    }
    else if (isValueObject(value)) {
        traverseSelector({
            key,
            pointer,
            selector,
            accept,
            fragment,
            value: value['@value'],
            actionValue,
            store,
            details,
            defaultValue,
        });
    }
    if (isMetadataObject(value) && isIRIObject(value)) {
        selectEntity({
            pointer,
            selector,
            accept,
            fragment,
            iri: value['@id'],
            store,
            details,
        });
        return;
    }
    // edit selections are a special case in that an input
    // should render even when no value is present.
    if (isJSONObject(value) &&
        actionValue !== undefined &&
        value[selector[0].subject] == null) {
        value = { [selector[0].subject]: defaultValue ?? null };
    }
    const [next, ...rest] = selector;
    const { subject: propType, filter } = next;
    // null is a placeholder for action payload types with no value.
    // jsonld drops null values otherwise.
    if (value[propType] === undefined) {
        details.hasMissing = true;
        return;
    }
    if (rest.length === 0 && isJSONObject(actionValue?.[propType])) {
        pointer = makePointer(pointer, propType);
        resolveValue({
            key: updateKey(key, propType),
            pointer,
            value: value[propType],
            propType,
            accept,
            fragment,
            details,
            store,
            actionValue: actionValue?.[propType],
            spec: actionValue[`${propType}-input`],
            filter,
        });
        return;
    }
    else if (rest.length === 0) {
        selectTypedValue({
            key,
            pointer,
            propType,
            accept,
            fragment,
            filter,
            value,
            actionValue,
            store,
            details,
        });
        return;
    }
    if (typeof filter === 'string' && !passesFilter({ value, filter })) {
        return;
    }
    let traversedActionValue;
    if (isJSONObject(actionValue?.[propType])) {
        traversedActionValue = actionValue[propType];
    }
    traverseSelector({
        key: updateKey(key, propType),
        pointer: makePointer(pointer, propType),
        accept,
        fragment,
        selector: rest,
        value: value[propType],
        actionValue: traversedActionValue,
        store,
        details,
    });
}
/**
 * Selects an entity from the store and continues the selection
 * if the branch has not completed.
 */
function selectEntity({ pointer, iri, fragment, accept, filter, selector, store, details, handledIRIs, }) {
    const normalizedURL = new URL(iri).toString();
    // reset the key for entities.
    // this creates duplicates if an iri is used twice in a response at the
    // same level of the selection. I see this as being unlikely, so a problem
    // to solve later...
    const key = normalizedURL;
    pointer = makePointer(pointer, normalizedURL);
    const cache = store.entity(normalizedURL, { accept });
    details.dependencies.push(normalizedURL);
    // if loading is required mark found as false
    if (cache == null || cache.loading) {
        if (!details.required.includes(normalizedURL)) {
            details.required.push(normalizedURL);
            details.accept = accept;
            details.fragment = fragment;
        }
        return;
    }
    if (!cache.ok) {
        details.hasErrors = true;
        details.isProblem = cache.isProblem;
        if (selector == null || selector.length === 0) {
            return;
        }
        details.result.push({
            key,
            pointer,
            type: 'entity',
            fragment,
            iri: cache.iri,
            ok: false,
            status: cache.status,
            value: cache.value,
            reason: cache.reason,
            contentType: cache.contentType,
        });
        return;
    }
    if (cache.type === 'alternative-success') {
        details.result.push({
            key,
            pointer,
            iri: cache.iri,
            fragment,
            ok: cache.ok,
            status: cache.status,
            type: 'alternative',
            contentType: cache.integration.contentType,
            integration: cache.integration,
            accept,
        });
        return;
    }
    const value = cache.value;
    if (isMetadataObject(value)) {
        // in theory several entities could be metadata objects
        // referencing each other and end up looping around...
        if (handledIRIs == null) {
            handledIRIs = new Set([value['@id']]);
        }
        else if (!handledIRIs.has(value['@id'])) {
            handledIRIs.add(value['@id']);
        }
        else {
            throw new CircularSelectionError(`Circular selection loop detected`);
        }
        // select the entity this entity is referencing
        return selectEntity({
            pointer,
            iri: value['@id'],
            fragment,
            accept,
            filter,
            selector,
            details,
            store,
            handledIRIs,
        });
    }
    // if the entity does not match the filter it is not relevant to the final selection
    if (typeof filter === 'string' && !passesFilter({ filter, value })) {
        return;
    }
    if (typeof selector === 'undefined') {
        details.result.push({
            key,
            pointer,
            type: 'entity',
            iri: cache.iri,
            ok: true,
            value: cache.value,
            contentType: cache.contentType,
        });
        return;
    }
    traverseSelector({
        key,
        pointer,
        accept,
        fragment,
        value,
        selector,
        store,
        details,
    });
    return;
}

function cachePrev(attrs) {
    return {
        selector: attrs.selector,
        value: attrs.value,
        actionValue: attrs.actionValue,
        args: {
            fragment: attrs.args.fragment,
        },
        parentArgs: {
            store: attrs.parentArgs.store,
        },
    };
}
function shouldReselect(next, prev) {
    return next.parentArgs.store !== prev.parentArgs.store ||
        next.selector !== prev.selector ||
        next.args.fragment !== prev.args.fragment ||
        next.value !== prev.value;
}
const ActionSelectionRenderer = (vnode) => {
    let currentAttrs = vnode.attrs;
    let details;
    let prev;
    const instances = new Map();
    function createInstances() {
        let hasChanges = false;
        const { parentArgs, selectionArgs } = currentAttrs;
        const nextKeys = [];
        for (let index = 0; index < details.result.length; index++) {
            const selectionResult = details.result[index];
            nextKeys.push(selectionResult.pointer);
            if (instances.has(selectionResult.pointer)) {
                const { rendererArgs, octiron } = instances.get(selectionResult.pointer);
                const update = (value) => {
                    return parentArgs.updatePointer(selectionResult.pointer, value, selectionArgs);
                };
                rendererArgs.value = octiron.value = selectionResult.value;
                rendererArgs.spec = selectionResult.spec;
                rendererArgs.update = update;
                continue;
            }
            hasChanges = true;
            const update = (value) => {
                return parentArgs.updatePointer(selectionResult.pointer, value, selectionArgs);
            };
            const actionValueRendererArgs = {
                index,
                value: selectionResult.actionValue,
                propType: selectionResult.propType,
            };
            const [actionValue, hooks] = selectionFactory(currentAttrs.args, parentArgs, actionValueRendererArgs);
            const rendererArgs = {
                index,
                update,
                actionValue,
                pointer: selectionResult.pointer,
                propType: selectionResult.propType,
                value: selectionResult.value,
                spec: selectionResult.spec,
            };
            const [actionSelection, actionSelectionHooks] = actionSelectionFactory(currentAttrs.args, parentArgs, rendererArgs);
            instances.set(selectionResult.pointer, {
                rendererArgs,
                selection: actionValue,
                selectionHooks: hooks,
                octiron: actionSelection,
                hooks: actionSelectionHooks,
                selectionResult,
            });
        }
        const prevKeys = instances.keys();
        for (const key of prevKeys) {
            if (!nextKeys.includes(key)) {
                hasChanges = true;
                instances.delete(key);
            }
        }
        if (hasChanges && typeof window !== 'undefined') {
            mithrilRedraw();
        }
    }
    function updateSelection() {
        const { selector, value, actionValue } = currentAttrs;
        const { store } = currentAttrs.parentArgs;
        if (!isJSONObject(value)) {
            return;
        }
        details = getSelection({
            selector,
            store,
            actionValue,
            value,
            defaultValue: currentAttrs.args.initialValue,
        });
        createInstances();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            prev = cachePrev(attrs);
            updateSelection();
        },
        onbeforeupdate: ({ attrs }) => {
            const reselect = shouldReselect(attrs, prev);
            currentAttrs = attrs;
            if (reselect) {
                updateSelection();
            }
            else {
                for (const instance of instances.values()) {
                }
            }
        },
        view: ({ attrs: { view, args } }) => {
            if (details == null) {
                return null;
            }
            const { pre, sep, post, fallback, } = args;
            if (typeof view === 'undefined') {
                return;
            }
            const list = Array.from(instances.values());
            const children = [pre];
            for (let index = 0; index < list.length; index++) {
                const { octiron, selectionResult } = list[index];
                octiron.position = index + 1;
                if (index !== 0) {
                    children.push(sep);
                }
                if (selectionResult.value == null && typeof fallback === 'function') {
                    children.push(null);
                    // children.push(fallback(octiron));
                }
                else if (selectionResult.value == null && fallback != null) {
                    children.push(fallback);
                }
                else {
                    children.push(view(octiron));
                }
            }
            children.push(post);
            return children;
        },
    };
};

/**
 * Gets the details on how to perform a submission
 * based off an action, payload and other context.
 *
 * @param args.payload The current payload value.
 * @param args.action The schema.org styled action object.
 */
function getSubmitDetails({ payload, action, }) {
    let urlTemplate;
    let body;
    let method = 'get';
    let contentType;
    let encodingType;
    let target = action['https://schema.org/target'];
    if (Array.isArray(target)) {
        for (const item of target) {
            if (item === 'string') {
                target = item;
                break;
            }
            else if (isJSONObject(target) && (target['https://schema.org/contentType'] == null || (target['https://schema.org/contentType'] === 'multipart/form-data' ||
                target['https://schema.org/contentType'] === 'application/ld+json'))) {
                target = item;
                break;
            }
        }
    }
    if (typeof target === 'string') {
        urlTemplate = target;
    }
    else if (isJSONObject(target)) {
        if (typeof target['https://schema.org/urlTemplate'] === 'string') {
            urlTemplate = target['https://schema.org/urlTemplate'];
        }
        if (typeof target['https://schema.org/httpMethod'] === 'string') {
            method = target['https://schema.org/httpMethod'].toLowerCase();
        }
        if (typeof target['https://schema.org/contentType'] === 'string') {
            contentType = target['https://schema.org/contentType'];
        }
        if (typeof target['https://schema.org/encodingType'] === 'string') {
            encodingType = target['https://schema.org/encodingType'];
        }
    }
    if (typeof urlTemplate !== 'string') {
        throw new Error('Action has invalid https://schema.org/target');
    }
    const fillArgs = {};
    const submitBody = Object.assign({}, payload);
    for (const [type, value] of Object.entries(action)) {
        if (!isTypeObject(value) ||
            value['@type'] !== 'https://schema.org/PropertyValueSpecification') {
            continue;
        }
        const valueName = value['https://schema.org/valueName'];
        if (valueName != null) {
            const propType = type.replace(/-input$/, '');
            fillArgs[valueName] = payload[propType];
            delete submitBody[propType];
        }
    }
    const template = uriTemplates(urlTemplate);
    // deno-lint-ignore no-explicit-any
    const url = template.fill(fillArgs);
    // only add body if supporting HTTP method
    if (method !== 'get' && method !== 'delete') {
        body = JSON.stringify(submitBody);
    }
    else {
        contentType = undefined;
        encodingType = undefined;
    }
    return {
        url,
        method,
        contentType,
        encodingType,
        body,
    };
}

const ActionStateRenderer3 = () => {
    let render;
    let not;
    let type;
    let octiron;
    let hooks;
    let fragment;
    let integration;
    let args;
    let parentArgs;
    const listener = (submitResult, selectionDetails) => {
        if (submitResult.loading) {
            return;
        }
        if ((!not && type === 'failure' && submitResult.ok) ||
            (not && type === 'failure' && !submitResult.ok) ||
            (not && type === 'success' && submitResult.ok) ||
            (!not && type === 'success' && !submitResult.ok)) {
            render = false;
            return;
        }
        render = true;
        if (submitResult.type === 'alternative-success') {
            octiron = null;
            hooks = null;
            fragment = selectionDetails.result[0].fragment;
            integration = submitResult.integration;
        }
        else {
            fragment = null;
            integration = null;
            [octiron, hooks] = selectionFactory(args, parentArgs, {
                index: 0,
                value: selectionDetails.result[0].value,
            });
        }
    };
    return {
        oninit(vnode) {
            not = vnode.attrs.not ?? false;
            type = vnode.attrs.type;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            render = not &&
                vnode.attrs.selector == null &&
                vnode.attrs.view == null;
            vnode.attrs.events.addListener(listener);
        },
        onbeforeupdate(vnode) {
            not = vnode.attrs.not ?? false;
            type = vnode.attrs.type;
        },
        onbeforeremove(vnode) {
            vnode.attrs.events.removeListener(listener);
        },
        view(vnode) {
            if (!render)
                return;
            if (integration != null) {
                return integration.render(
                //vnode.attrs.parentArgs.parent,
                fragment);
            }
            else if (vnode.attrs.selector != null && octiron != null) {
                return octiron.select(vnode.attrs.selector, vnode.attrs.args, vnode.attrs.view);
            }
            else if (vnode.attrs.view != null && octiron != null) {
                return vnode.attrs.view(octiron);
            }
            return vnode.children;
        },
    };
};

const ActionStateRenderer = () => {
    let key = Symbol('ActionStateRenderer');
    let submitResult;
    let octiron;
    let hooks;
    function setInstance(attrs) {
        if (attrs.submitResult == null) {
            submitResult = undefined;
            octiron = undefined;
        }
        else if (submitResult == null ||
            attrs.submitResult.ok !== submitResult.ok ||
            attrs.submitResult.status !== submitResult.status ||
            attrs.submitResult.value !== submitResult.value) {
            submitResult = attrs.submitResult;
            const rendererArgs = {
                index: 0,
                value: attrs.submitResult.value,
            }[hooks] = selectionFactory(attrs.args, attrs.parentArgs, rendererArgs);
        }
    }
    function listener(next) {
        if (next.result.length === 1 && next.result[0].value != null) {
            submitResult.value = next.result[0].value;
        }
    }
    function updateSubscription(attrs) {
        if (attrs.submitResult == null || attrs.submitResult.loading) {
            attrs.parentArgs.store.unsubscribe(key);
            return;
        }
        attrs.parentArgs.store.unsubscribe(key);
        attrs.parentArgs.store.subscribe({
            key,
            listener,
            selector: attrs.submitResult.iri,
            accept: attrs.args.accept,
            fragment: attrs.args.fragment,
            mainEntity: attrs.args.mainEntity,
        });
    }
    return {
        oninit: ({ attrs }) => {
            updateSubscription(attrs);
            setInstance(attrs);
        },
        onbeforeupdate: ({ attrs }) => {
            updateSubscription(attrs);
            setInstance(attrs);
        },
        view: ({ attrs: { type, selector, args, view, ...attrs }, children }) => {
            if (type === 'initial' && submitResult == null) {
                return children;
            }
            else if (submitResult == null || octiron == null) {
                return null;
            }
            let shouldRender = (type === 'success' && submitResult.ok) ||
                (type === 'failure' && !submitResult.ok);
            if (attrs.not) {
                shouldRender = !shouldRender;
            }
            octiron.position = 1;
            if (shouldRender && selector != null) {
                return octiron.select(selector, args, view);
            }
            else if (shouldRender && view != null) {
                return view(octiron);
            }
            else if (shouldRender && args != null) {
                return octiron.present(args);
            }
            octiron.position = -1;
            return null;
        },
    };
};

function actionFactory(args, parentArgs, rendererArgs, events) {
    const factoryArgs = Object.assign(Object.create(null), args);
    let payload = Object.create(null);
    let submitResult;
    if (isJSONObject(args.initialValue)) {
        payload = expandValue(parentArgs.store, args.initialValue);
    }
    else if (args.initialValue != null) {
        console.warn('o.perform() only supports receiving JSON objects as initial values.');
    }
    async function submit() {
        let isError = false;
        const { url, method, contentType, body } = getSubmitDetails({
            payload,
            action: refs.rendererArgs.value,
        });
        self.submitting = true;
        self.url = new URL(url, self.store.rootIRI);
        mithrilRedraw();
        try {
            if (typeof args.onSubmit === 'function') {
                args.onSubmit(self);
            }
            submitResult = await refs.parentArgs.store.submit(url, {
                method,
                mainEntity: args.mainEntity,
                accept: args.accept,
                contentType: contentType ?? 'application/ld+json',
                body,
            });
            if (submitResult != null)
                events.onSubmitResult(submitResult);
        }
        catch (err) {
            console.error(err);
            isError = true;
        }
        self.submitting = false;
        mithrilRedraw();
        if (isError && typeof args.onSubmitFailure === 'function' && isBrowserRender) {
            args.onSubmitFailure(self);
        }
        else if (!isError && typeof args.onSubmitSuccess === 'function' && isBrowserRender) {
            args.onSubmitSuccess(self);
        }
    }
    function update(value, args2) {
        const prev = payload;
        const next = {
            ...prev,
            ...value,
        };
        if (typeof args.interceptor === 'function') {
            const res = args.interceptor({
                next,
                prev,
                actionValue: refs.parentArgs.parent.value,
                o: self,
            });
            if (res === false) {
                return false;
            }
            payload = res;
        }
        else {
            payload = next;
        }
        childArgs.value = self.value = value;
        if (args2?.submit !== false && (args2?.submit || args.submitOnChange)) {
            submit();
        }
        else {
            mithrilRedraw();
        }
    }
    const updatePointer = (pointer, value, _args) => {
        const next = Object.assign({}, payload);
        const ptr = JsonPointer.create(pointer);
        if (value == null) {
            ptr.unset(next);
        }
        else {
            ptr.set(next, value, true);
        }
        update(next);
    };
    const childArgs = {
        value: payload,
        submitting: false,
        submit,
        updatePointer,
    };
    const refs = {
        factoryArgs,
        parentArgs,
        rendererArgs,
        childArgs,
    };
    const [self, hooks] = octironFactory('action', refs);
    self.value = payload;
    self.action = parentArgs.parent;
    self.actionValue = rendererArgs.actionValue;
    self.url = undefined;
    self.submitting = false;
    childArgs.action = self;
    childArgs.submitting = self.submitting;
    self.select = (arg1, arg2, arg3) => {
        const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
        return m(ActionSelectionRenderer, {
            parentArgs: childArgs,
            selector,
            value: self.value,
            actionValue: refs.rendererArgs.actionValue.value,
            args,
            view,
        });
    };
    self.submit = async function (arg1) {
        if (arg1 != null) {
            const res = typeof arg1 === 'function'
                ? update(arg1(payload), { submit: false })
                : update(arg1, { submit: false });
            if (res === false)
                return;
        }
        return submit();
    };
    self.update = async function (arg1, arg2) {
        const res = typeof arg1 === 'function'
            ? update(arg1(payload), arg2)
            : update(arg1, arg2);
        if (res === false)
            return;
    };
    self.append = (termOrType, value = {}, args = {}) => {
        const type = refs.parentArgs.store.expand(termOrType);
        if (!isJSONObject(self.value)) {
            return;
        }
        const prevValue = self.value[type];
        let nextValue = [];
        if (prevValue != null && !Array.isArray(prevValue)) {
            nextValue.push(prevValue);
        }
        else if (Array.isArray(prevValue)) {
            nextValue = [...prevValue.filter((value) => value != undefined)];
        }
        nextValue.push(value);
        return self.update({
            ...self.value,
            [type]: nextValue,
        }, args);
    };
    const makeInitialStateMethod = (not) => {
        return (children) => {
            return m(ActionStateRenderer, {
                not,
                type: 'initial',
                args: {},
                submitResult,
                parentArgs: childArgs,
            }, children);
        };
    };
    const makeActionStateMethod = (type, not) => {
        return (arg1, arg2, arg3) => {
            const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
            return m(ActionStateRenderer3, {
                not,
                type,
                selector,
                args,
                view,
                parentArgs: childArgs,
                events,
            });
        };
    };
    self.initial = makeInitialStateMethod();
    self.not.initial = makeInitialStateMethod(true);
    self.success = makeActionStateMethod('success');
    self.not.success = makeActionStateMethod('success', true);
    self.failure = makeActionStateMethod('failure');
    self.not.failure = makeActionStateMethod('failure', true);
    try {
        const submitDetails = getSubmitDetails({
            payload: self.value,
            action: refs.rendererArgs.value,
        });
        self.url = new URL(submitDetails.url);
        self.method = submitDetails.method;
    }
    catch (err) {
        console.error(err);
    }
    if (self.url != null) {
        submitResult = refs.parentArgs.store.entity(self.url, {
            method: self.method,
        });
    }
    if (args.submitOnInit) {
        if (submitResult == null || submitResult.type === 'entity-loading') {
            submit();
        }
        else if (submitResult != null) {
            events.onSubmitResult(submitResult);
        }
    }
    Object.seal(self);
    const wrappedHooks = {
        argsChanged: () => {
            hooks.argsChanged();
        },
        parentArgsChanged: () => {
            hooks.parentArgsChanged();
        },
        rendererArgsChanged: () => {
            self.index = refs.rendererArgs.index;
        },
    };
    return [self, wrappedHooks];
}

function applySubmission(key, listener, store, args, submitResult, listeners) {
    let selectionResult;
    let selectionDetails;
    if (submitResult.type !== 'alternative-success' &&
        isIRIObject(submitResult.value)) {
        selectionDetails = store.subscribe({
            key,
            listener,
            selector: submitResult.value['@id'],
        });
    }
    else {
        if (submitResult.type === 'entity-success') {
            selectionResult = {
                key: '/',
                pointer: '/',
                type: 'value',
                readonly: true,
                status: submitResult.status,
                reason: submitResult.reason,
                value: submitResult.value,
            };
        }
        else if (submitResult.type === 'alternative-success') {
            selectionResult = {
                key: '/',
                pointer: '/',
                type: 'alternative',
                iri: submitResult.iri,
                fragment: submitResult.fragment,
                accept: args.accept,
                ok: submitResult.ok,
                status: submitResult.status,
                contentType: submitResult.contentType,
                reason: submitResult.reason,
                integration: store.integration(submitResult.contentType),
            };
        }
        store.unsubscribe(key);
        selectionDetails = {
            complete: true,
            hasErrors: !submitResult.ok,
            hasMissing: false,
            isProblem: submitResult.isProblem,
            fragment: args.fragment,
            accept: args.accept,
            dependencies: [],
            required: [],
            result: [selectionResult],
            selector: submitResult.iri,
        };
    }
    for (let i = 0, l = listeners.length; i < l; i++) {
        listeners[i](submitResult, selectionDetails);
    }
    return selectionDetails;
}
const ActionRenderer2 = () => {
    const key = Symbol('ActionRenderer');
    let octiron;
    let hooks;
    let store;
    let args;
    let parentArgs;
    let submitResult;
    let selectionDetails;
    const listeners = [];
    const addListener = (listener) => {
        listeners.push(listener);
        if (submitResult != null) {
            listener(submitResult, selectionDetails);
        }
    };
    const removeListener = (listener) => {
        listeners.splice(listeners.indexOf(listener), 1);
    };
    const listener = (next) => {
        selectionDetails = next;
        for (let i = 0, l = listeners.length; i < l; i++) {
            listeners[i](submitResult, selectionDetails);
        }
    };
    const onSubmitResult = (next) => {
        submitResult = next;
        selectionDetails = applySubmission(key, listener, store, args, submitResult, listeners);
    };
    return {
        oninit(vnode) {
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            [octiron, hooks] = actionFactory(args, parentArgs, vnode.attrs.rendererArgs, {
                onSubmitResult,
                addListener,
                removeListener,
            });
        },
        onbeforeupdate(vnode) {
            const prev = store;
            const changed = prev !== (vnode.attrs.args.store ?? vnode.attrs.parentArgs.store);
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            store = args.store ?? parentArgs.store;
            if (changed) {
                store.unsubscribe(key);
                if (submitResult != null) {
                    onSubmitResult(submitResult);
                }
            }
        },
        onbeforeremove() {
            store.unsubscribe(key);
        },
        view(vnode) {
            return vnode.attrs.view(octiron);
        },
    };
};

function createInstances$1(instances, args, parentArgs, selectionDetails) {
    const prevKeys = Array.from(instances.keys());
    const nextKeys = [];
    for (let i = 0, l = selectionDetails.result.length; i < l; i++) {
        const selectionResult = selectionDetails.result[i];
        nextKeys.push(selectionResult.pointer);
        if (instances.has(selectionResult.pointer)) {
            const next = selectionResult;
            const prev = instances.get(selectionResult.pointer).selectionResult;
            if (prev.type === 'value' &&
                next.type === 'value' &&
                next.value === prev.value) {
                continue;
            }
            else if (prev.type === 'entity' &&
                next.type === 'entity' &&
                next.ok === prev.ok &&
                next.status === prev.status &&
                next.value === prev.value) {
                continue;
            }
        }
        const selectionRendererArgs = {
            index: i,
            value: selectionResult.value,
            propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
        };
        const [octiron, hooks] = selectionFactory(args, parentArgs, selectionRendererArgs);
        const rendererArgs = {
            index: i,
            value: selectionResult.value,
            propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
            actionValue: octiron,
        };
        instances.set(selectionResult.pointer, {
            octiron,
            hooks,
            selectionResult,
            rendererArgs,
        });
    }
    if (prevKeys.length > 0) {
        for (let i = 0, l = prevKeys.length; i < l; i++) {
            if (!nextKeys.includes(prevKeys[i])) {
                instances.delete(prevKeys[i]);
            }
        }
    }
}
async function fetchRequired$1(store, args, selectionDetails) {
    if (selectionDetails.required.length === 0)
        return;
    const promises = [];
    for (let i = 0, l = selectionDetails.required.length; i < l; i++) {
        promises.push(store.fetch(selectionDetails.required[i], args));
    }
    await Promise.allSettled(promises);
}
function subscribe$1(key, listener, instances, store, selector, args, parentArgs) {
    if (selector != null &&
        !isJSONObject$1(parentArgs.parent.value)) {
        // Actions can only be performed on JSON objects.
        store.unsubscribe(key);
        instances.clear();
        return;
    }
    let selectionDetails;
    if (selector != null) {
        selectionDetails = store.subscribe({
            key,
            listener,
            selector,
            value: parentArgs.parent.value,
        });
        if (selectionDetails.required.length > 0) {
            fetchRequired$1(store, args, selectionDetails);
        }
    }
    else {
        // If there is no selector this perform is being done against the
        // current value.
        selectionDetails = {
            selector: '/',
            complete: true,
            hasErrors: false,
            hasMissing: false,
            isProblem: false,
            dependencies: [],
            required: [],
            result: [{
                    key: '/',
                    pointer: '/',
                    type: 'value',
                    readonly: true,
                    value: parentArgs.parent.value,
                }],
        };
        createInstances$1(instances, args, parentArgs, selectionDetails);
    }
    return selectionDetails;
}
const PerformRenderer3 = () => {
    let key = Symbol('PerformRenderer');
    let loading;
    let store;
    let selector;
    let args;
    let parentArgs;
    let instances;
    const listener = (selectionDetails) => {
        loading = !selectionDetails.complete;
        if (selectionDetails.required.length > 0) {
            fetchRequired$1(store, args, selectionDetails);
        }
        else {
            createInstances$1(instances, args, parentArgs, selectionDetails);
        }
    };
    return {
        oninit(vnode) {
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            instances = new Map();
            loading = !subscribe$1(key, listener, instances, store, selector, args, parentArgs)?.complete;
        },
        onbeforeupdate(vnode) {
            const prev = store;
            const changed = store !== (vnode.attrs.args.store ?? vnode.attrs.parentArgs.store) ||
                selector !== vnode.attrs.selector;
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            if (changed) {
                prev.unsubscribe(key);
                loading = !subscribe$1(key, listener, instances, store, selector, args, parentArgs)?.complete;
            }
        },
        onbeforeremove() {
            store.unsubscribe(key);
        },
        view(vnode) {
            if (loading && instances.size === 0) {
                return vnode.attrs.args.loading;
            }
            const children = [vnode.attrs.args.pre];
            const list = Array.from(instances.values());
            for (let i = 0, l = list.length; i < l; i++) {
                list[i].octiron.position = i + 1;
                if (i !== 0)
                    children.push(vnode.attrs.args.sep);
                if (list[i].selectionResult.type !== 'value' &&
                    !list[i].selectionResult.ok) {
                    if (typeof vnode.attrs.args.fallback === 'function') {
                        children.push(vnode.attrs.args.fallback(list[i].octiron, list[i].selectionResult.reason));
                    }
                    else {
                        children.push(vnode.attrs.args.fallback);
                    }
                }
                else {
                    children.push(m(ActionRenderer2, {
                        args: vnode.attrs.args,
                        parentArgs: vnode.attrs.parentArgs,
                        rendererArgs: list[i].rendererArgs,
                        selection: list[i].octiron,
                        view: vnode.attrs.view,
                    }));
                }
            }
            children.push(vnode.attrs.args.post);
            return children;
        },
    };
};

const PresentRenderer = ({ attrs: { args, factoryArgs, parentArgs, rendererArgs, }, }) => {
    let [attrs, component] = selectComponentFromArgs('present', parentArgs, rendererArgs, args, factoryArgs);
    return {
        //onbeforeupdate({ attrs: { args, factoryArgs, parentArgs, rendererArgs }}) {
        // [attrs, component] = selectComponentFromArgs(
        //   'present',
        //   parentArgs,
        //   rendererArgs,
        //   args,
        //   factoryArgs,
        // );
        //},
        view({ attrs: { o, rendererArgs }, children }) {
            if (component == null) {
                return null;
            }
            // deno-lint-ignore no-explicit-any
            return m(component, {
                o,
                renderType: "present",
                value: rendererArgs.value,
                attrs,
            }, children);
        },
    };
};

/**
 * Creates Octiron instances used when rendering this selection.
 * If an instance is an entity it will get re-ordered into the
 * next selection. Otherwise it will be re-purposed.
 */
function createInstances(instances, args, parentArgs, selectionDetails) {
    let selectionResult;
    const prev = new Map(instances);
    instances.clear();
    for (let i = 0, l = selectionDetails.result.length; i < l; i++) {
        selectionResult = selectionDetails.result[i];
        if (prev.has(selectionResult.key) && selectionResult.type !== 'alternative') {
            const instance = prev.get(selectionResult.key);
            instance.refs.rendererArgs.index = i;
            instance.refs.rendererArgs.value = selectionResult.value;
            instance.refs.rendererArgs.propType = selectionResult.type === 'entity'
                ? undefined
                : selectionResult.propType;
            instance.hooks.rendererArgsChanged();
            instances.set(selectionResult.key, instance);
        }
        else if (selectionResult.type != 'alternative') {
            const rendererArgs = {
                index: i,
                value: selectionResult.value,
                propType: selectionResult.type === 'entity' ? undefined : selectionResult.propType,
            };
            const [octiron, hooks] = selectionFactory(args, parentArgs, rendererArgs);
            const refs = {
                args,
                parentArgs,
                rendererArgs,
            };
            instances.set(selectionResult.key, {
                refs,
                selectionResult,
                octiron,
                hooks,
            });
        }
        else {
            instances.set(selectionResult.key, {
                selectionResult,
            });
        }
    }
}
async function fetchRequired(store, args, selectionDetails) {
    if (selectionDetails.required.length === 0)
        return;
    const promises = [];
    for (let i = 0, l = selectionDetails.required.length; i < l; i++) {
        promises.push(store.fetch(selectionDetails.required[i], args));
    }
    await Promise.allSettled(promises);
}
function subscribe(key, listener, instances, store, entity, selector, args, parentArgs) {
    if (!entity && !isJSONObject$1(parentArgs.parent.value)) {
        store.unsubscribe(key);
        instances.clear();
        return;
    }
    const selectionDetails = store.subscribe({
        key,
        selector,
        listener,
        fragment: args.fragment,
        accept: args.accept,
        value: entity ? undefined : parentArgs.value,
        mainEntity: args.mainEntity,
    });
    if (selectionDetails.required.length > 0) {
        fetchRequired(store, args, selectionDetails);
    }
    createInstances(instances, args, parentArgs, selectionDetails);
    return selectionDetails;
}
const SelectionRenderer2 = () => {
    let key = Symbol('SelectionRenderer');
    let loading;
    let store;
    let entity;
    let selector;
    let args;
    let parentArgs;
    let value;
    let instances;
    const listener = (selectionDetails) => {
        loading = !selectionDetails.complete;
        if (selectionDetails.required.length > 0) {
            fetchRequired(store, args, selectionDetails);
        }
        else if (!loading) {
            createInstances(instances, args, parentArgs, selectionDetails);
        }
    };
    return {
        oninit(vnode) {
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            entity = vnode.attrs.entity ?? false;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            value = parentArgs.value;
            instances = new Map();
            loading = !subscribe(key, listener, instances, store, entity, selector, args, parentArgs)?.complete;
        },
        onbeforeupdate(vnode) {
            const prev = store;
            const changed = entity != (vnode.attrs.entity ?? false) ||
                store !== (vnode.attrs.args.store ?? vnode.attrs.parentArgs.store) ||
                selector !== vnode.attrs.selector ||
                value !== vnode.attrs.parentArgs.value;
            store = vnode.attrs.args.store ?? vnode.attrs.parentArgs.store;
            entity = vnode.attrs.entity ?? false;
            selector = vnode.attrs.selector;
            args = vnode.attrs.args;
            parentArgs = vnode.attrs.parentArgs;
            value = parentArgs.value;
            if (changed) {
                prev.unsubscribe(key);
                loading = !subscribe(key, listener, instances, store, entity, selector, args, parentArgs)?.complete;
            }
        },
        onbeforeremove() {
            store.unsubscribe(key);
        },
        view(vnode) {
            if (loading && instances.size === 0) {
                return vnode.attrs.args.loading;
            }
            const children = [m.fragment({ key: '@pre' }, [vnode.attrs.args.pre])];
            let child;
            let l1 = Array.from(instances.values());
            let l2;
            if (vnode.attrs.args.predicate != null) {
                l2 = [];
                for (let i = 0, l = l1.length; i < l; i++) {
                    if (vnode.attrs.args.predicate(l1[i].octiron)) {
                        l2.push(l1[i]);
                    }
                }
            }
            else {
                l2 = l1;
            }
            if (vnode.attrs.args.end != null) {
                l2.splice(0, vnode.attrs.args.end);
            }
            if (vnode.attrs.args.start != null) {
                l2.splice(vnode.attrs.args.start);
            }
            for (let i = 0, l = l2.length; i < l; i++) {
                child = [];
                if (l2[i].octiron !== undefined) {
                    l2[i].octiron.position = i + 1;
                }
                if (i !== 0)
                    child.push(m.fragment({ key: '@sep' }, [vnode.attrs.args.sep]));
                if (l2[i].selectionResult.type === 'value') {
                    child.push(m.fragment({ key: '@value' }, [vnode.attrs.view(l2[i].octiron)]));
                }
                else if (!l2[i].selectionResult.ok && typeof vnode.attrs.args.fallback === 'function') {
                    throw new Error(`Fallback functions are not yet supported`);
                }
                else if (!l2[i].selectionResult.ok) {
                    child.push(m.fragment({ key: '@value' }, [vnode.attrs.args.fallback]));
                }
                else if (l2[i].selectionResult.type === 'entity') {
                    child.push(m.fragment({ key: '@value' }, [vnode.attrs.view(l2[i].octiron)]));
                }
                else {
                    child.push(m.fragment({ key: '@value' }, [
                        l2[i].selectionResult.integration.render(
                        //vnode.attrs.parentArgs.parent,
                        vnode.attrs.args.fragment),
                    ]));
                }
                children.push(m.fragment({ key: l2[i].selectionResult.key }, child));
            }
            children.push(m.fragment({ key: '@post' }, [vnode.attrs.args.post]));
            return children;
        },
    };
};

let counter = 0;
/**
 * Generates a unique key.
 */
function key() {
    const key = `oct-${counter.toString().padStart(8, '0')}`;
    counter++;
    return key;
}

const TypeKeys = {
    'root': 0,
    'selection': 1,
    'action': 2,
    'action-selection': 3,
};
/**
 * Creates the base Octiron instance.
 *
 * @param octironType - The Octiron instance type to create.
 * @param factoryArgs - User specified args passed to the Octiron method creating the factory.
 * @param parentArgs - Args passed from the Octiron parent instance of this instance.
 * @param rendererArgs - Args passed from the Mithril renderer component.
 * @param childArgs - Args to pass through to any child renderers, to be their parent args.
 */
function octironFactory(octironType, refs) {
    refs.rendererArgs ??= {};
    refs.childArgs ??= {};
    const typeKey = TypeKeys[octironType];
    const name = isIRIObject(refs.rendererArgs.value)
        ? refs.rendererArgs.value['@id'] : refs.rendererArgs.propType ?? 'octiron';
    // hack to give the function a dynamically set name...
    const self = ({ [name]: (predicate, children) => {
            const passes = predicate(self);
            if (passes) {
                return children;
            }
            return null;
        } })[name];
    self.id = key();
    self.isOctiron = true;
    self.octironType = octironType;
    self.readonly = true;
    self.value = refs.rendererArgs.value ?? null;
    self.store = refs.parentArgs.store;
    self.index = refs.rendererArgs.index ?? 0;
    self.position = -1;
    self.expand = (typeOrTerm) => refs.parentArgs.store.expand(typeOrTerm);
    // easiest to define the common child args here
    // but the object is passed in from the parent factory
    // so it has references and control over the values.
    refs.childArgs.value = self.value;
    refs.childArgs.parent = self;
    refs.childArgs.store = refs.factoryArgs.store ?? refs.parentArgs.store;
    refs.childArgs.typeHandlers = refs.factoryArgs.typeHandlers ?? refs.parentArgs.typeHandlers;
    if (typeKey !== TypeKeys['root']) {
        self.propType = refs.rendererArgs.propType;
        self.dataType = getDataType(refs.rendererArgs.value);
    }
    self.not = (predicate, children) => {
        if (self == null) {
            return null;
        }
        const passes = predicate(self);
        if (!passes) {
            return children;
        }
        return null;
    };
    self.get = ((termOrType) => {
        if (!isJSONObject(self.value)) {
            return null;
        }
        if (termOrType.startsWith('@')) {
            return self.value[termOrType];
        }
        const type = self.store.expand(termOrType);
        const value = self.value[type] ?? null;
        if (isIterable(value)) {
            return getIterableValue(value);
        }
        return self.value[type] ?? null;
    });
    self.enter = (arg1, arg2, arg3) => {
        const [selector, args, view] = unravelArgs(arg1 instanceof URL ? arg1.toString() : arg1, arg2, arg3);
        return m(SelectionRenderer2, {
            entity: true,
            selector,
            args,
            view,
            parentArgs: refs.childArgs,
        });
    };
    const rootChildArgs = {
        ...refs.childArgs,
        value: refs.parentArgs.store.entity(refs.parentArgs.store.rootIRI, {
            accept: refs.factoryArgs.accept,
        })?.value,
    };
    self.root = (arg1, arg2, arg3) => {
        let selector;
        const [childSelector, args, view] = unravelArgs(arg1, arg2, arg3);
        if (childSelector == null) {
            selector = refs.parentArgs.store.rootIRI;
        }
        else {
            selector = `${refs.parentArgs.store.rootIRI} ${childSelector}`;
        }
        return m(SelectionRenderer2, {
            entity: true,
            selector,
            args,
            view,
            parentArgs: rootChildArgs,
        });
    };
    // action and action selection define their own select method
    switch (typeKey) {
        case TypeKeys['root']:
            self.select = self.root;
            break;
        case TypeKeys['selection']:
            self.select = ((arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                if (!isJSONObject(refs.rendererArgs.value)) {
                    return null;
                }
                return m(SelectionRenderer2, {
                    selector,
                    args,
                    view,
                    parentArgs: refs.childArgs,
                });
            });
    }
    switch (typeKey) {
        case TypeKeys['root']:
            self.present = self.root;
            break;
        default:
            self.present = (args) => {
                return m(PresentRenderer, {
                    o: self,
                    args: args,
                    factoryArgs: refs.factoryArgs,
                    parentArgs: refs.parentArgs,
                    rendererArgs: refs.rendererArgs,
                });
            };
    }
    self.default = (args) => {
        return self.present(Object.assign({ component: null }, args));
    };
    switch (typeKey) {
        case TypeKeys['root']:
            self.perform = (arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                if (typeof selector === 'string') {
                    return self.select(selector, args, o => o.perform(args, view));
                }
                return self.root(o => o.perform(args, view));
            };
            break;
        default: {
            self.perform = (arg1, arg2, arg3) => {
                const [selector, args, view] = unravelArgs(arg1, arg2, arg3);
                return m(PerformRenderer3, {
                    selector,
                    args,
                    view,
                    parentArgs: refs.childArgs,
                });
            };
            break;
        }
    }
    const hooks = {
        argsChanged() {
            self.store = refs.factoryArgs.store ?? refs.parentArgs.store;
        },
        parentArgsChanged() {
            self.store = refs.factoryArgs.store ?? refs.parentArgs.store;
        },
        rendererArgsChanged() {
            self.value = refs.rendererArgs.value ?? null;
            self.index = refs.rendererArgs.index;
            refs.childArgs.value = self.value;
            if (typeKey !== TypeKeys['root']) {
                self.propType = refs.rendererArgs.propType;
                self.dataType = getDataType(refs.rendererArgs.value);
            }
        },
    };
    return [self, hooks];
}

function rootFactory(parentArgs) {
    const factoryArgs = {};
    const res = octironFactory('root', {
        factoryArgs,
        parentArgs,
        rendererArgs: {},
        childArgs: {},
    });
    Object.seal(res[0]);
    return res;
}

/**
 * @description
 * Aggregates a list of type handlers into an easier to access
 * type handler config object.
 *
 * @param typeHandlers The type handlers to aggregate.
 */
function makeTypeHandlers(
// deno-lint-ignore no-explicit-any
storeOrTypeHandler, ...typeHandlers) {
    const config = {};
    if (storeOrTypeHandler.type === 'octiron-store') {
        for (const typeHandler of typeHandlers) {
            if (typeHandler.type === '@id') {
                config['@id'] = typeHandler;
            }
            else {
                // deno-lint-ignore no-explicit-any
                config[storeOrTypeHandler.expand(typeHandler.type)] = typeHandler;
            }
        }
    }
    else {
        // deno-lint-ignore no-explicit-any
        config[storeOrTypeHandler.type] = storeOrTypeHandler;
        for (const typeHandler of typeHandlers) {
            // deno-lint-ignore no-explicit-any
            config[typeHandler.type] = typeHandler;
        }
    }
    return config;
}

const ElementRenderer = {
    oninit(vnode) {
        if (!isBrowserRender) {
            vnode.attrs.onRendered();
        }
    },
    oncreate(vnode) {
        if (vnode.attrs.createHandler != null) {
            const fragmentValue = vnode.attrs.hashParser !== null
                ? vnode.attrs.hashParser(vnode.attrs.fragment)
                : '';
            vnode.state.context = {
                dom: vnode.dom,
                fragment: vnode.attrs.fragment,
                fragmentValue,
            };
            const result = vnode.attrs.createHandler(vnode.state.context);
            if (result?.onFragmentChange != null) {
                vnode.state.onFragmentChange = result.onFragmentChange;
            }
            if (result?.onRemove != null) {
                vnode.state.onRemove = result.onRemove;
            }
        }
    },
    onbeforeupdate(vnode) {
        if (vnode.state.onFragmentChange != null &&
            vnode.attrs.fragment !== vnode.attrs.fragment) {
            const fragmentValue = vnode.attrs.hashParser !== null
                ? vnode.attrs.hashParser(vnode.attrs.fragment)
                : '';
            vnode.state.context.fragment = vnode.attrs.fragment;
            vnode.state.context.fragmentValue = fragmentValue;
            vnode.state.onFragmentChange(fragmentValue, vnode.attrs.fragment);
            vnode.state.fragment = vnode.attrs.fragment;
        }
    },
    onbeforeremove(vnode) {
        if (vnode.state.onRemove != null)
            vnode.state.onRemove();
    },
    view(vnode) {
        return m.dom(vnode.attrs.dom);
    },
};
const ElementIntegration = ((args, handler) => {
    let rendered = false;
    const hashParser = handler.hashParser;
    const createHandler = handler.createHandler;
    const html = args.content.html;
    let dom = args.content.dom;
    const onRendered = () => {
        rendered = true;
    };
    const integration = {
        iri: args.iri,
        method: args.method,
        contentType: args.contentType,
        integrationType: 'element',
        render(hash) {
            if (dom === undefined) {
                const template = document.createElement('template');
                template.innerHTML = html;
                dom = template.content.children[0] ?? null;
            }
            if (dom === null)
                return;
            return m(ElementRenderer, {
                dom: dom,
                fragment: hash,
                hashParser,
                createHandler,
                onRendered,
            });
        },
        getStateInfo() {
            return {
                iri: args.iri,
                method: args.method,
                contentType: args.contentType,
                integrationType: 'element',
                rendered,
                selector: args.content.selector,
            };
        },
        toInitialState() {
            if (!rendered) {
                return `<template id="element:${args.iri}|${args.method}|${args.contentType}">${html}</template>`;
            }
            return '';
        },
    };
    return Object.freeze(integration);
});
ElementIntegration.type = 'element';
ElementIntegration.fromInitialState = (stateInfo, handler) => {
    const content = {
        selector: stateInfo.selector,
        html: '',
        dom: undefined,
    };
    if (stateInfo.rendered) {
        content.dom = document.querySelector(stateInfo.selector) ?? null;
    }
    else {
        const template = document.getElementById(`element:${stateInfo.iri}|${stateInfo.method}|${stateInfo.contentType}`);
        if (template != null || !(template instanceof HTMLTemplateElement)) {
            content.dom = template.children[0] ?? null;
        }
    }
    return ElementIntegration({
        iri: stateInfo.iri,
        method: stateInfo.method,
        contentType: stateInfo.contentType,
        content,
    }, handler);
};
Object.freeze(ElementIntegration);

/**
 * Populates the dom value in a fragment.
 *
 * @param fragment The fragment cache entry.
 */
function populateDOM(fragment) {
    const template = document.createElement('template');
    template.innerHTML = fragment[2];
    fragment[3] = Array.from(template.content.children);
}
/**
 * Finds the fragment relating to a URL hash and caches the it.
 * If the fragment is a template it is processed before being
 * cached against the hash.
 *
 * @param hash The URL fragment.
 * @param hashParser Parser function that can separate the fragment identifier from any template args.
 * @param content The HTML fragments content.
 * @param cache A map of URL fragments to the processed fragment.
 */
function cacheFragment(hash, hashParser, templateParser, fragmentHook, content, cache) {
    let fragmentCache = null;
    if (hashParser == null) {
        const fragment = content.fragments[hash];
        if (fragment != null) {
            fragmentCache = [fragment.id, fragment.type, fragment.html, fragment.dom];
        }
    }
    else {
        const result = hashParser(hash);
        if (result?.args != null && templateParser != null) {
            const template = content.templates != null ? content.templates[result.identifier] : undefined;
            if (template != null) {
                const html = templateParser(template, result.args, fragmentHook);
                fragmentCache = [result.identifier, undefined, html];
            }
        }
        else if (result != null && result.args == null) {
            const fragment = content.fragments[result.identifier];
            fragmentCache = [result.identifier, fragment.type, fragment.html, fragment.dom];
        }
    }
    cache.set(hash, fragmentCache);
}
const FragmentRenderer = {
    oninit(vnode) {
        vnode.state.fragment = vnode.attrs.fragment;
        if (!isBrowserRender) {
            // used for SSR to determine if a fragment has been
            // written to the HTML document or should be appended
            // as a template.
            vnode.attrs.onRendered(vnode.attrs.fragment[0]);
        }
        if (isBrowserRender && vnode.attrs.fragment[3] == null) {
            populateDOM(vnode.attrs.fragment);
        }
    },
    oncreate(vnode) {
        if (vnode.attrs.handler != null) {
            vnode.state.onRemove = vnode.attrs.handler(vnode.dom);
        }
    },
    onbeforeupdate(vnode) {
        if (vnode.attrs.fragment !== vnode.state.fragment) {
            vnode.state.didChange = true;
            vnode.state.fragment = vnode.attrs.fragment;
            if (vnode.attrs.fragment[3] == null) {
                populateDOM(vnode.attrs.fragment);
            }
            if (vnode.state.onRemove != null) {
                vnode.state.onRemove();
            }
        }
    },
    onupdate(vnode) {
        if (vnode.state.didChange && vnode.attrs.handler != null) {
            vnode.state.didChange = false;
            if (vnode.attrs.handler != null) {
                vnode.state.onRemove = vnode.attrs.handler(vnode.dom);
            }
        }
    },
    onbeforeremove(vnode) {
        if (vnode.state.onRemove != null)
            vnode.state.onRemove();
    },
    view(vnode) {
        if (vnode.attrs.fragment[1] === 'text' || !isBrowserRender) {
            return m.trust(vnode.attrs.fragment[2]);
        }
        return m.dom(vnode.attrs.fragment[3]);
    },
};
const FragmentsIntegration = ((args, handler) => {
    let root;
    let renderedRoot = false;
    const cache = new Map();
    const rendered = [];
    const hashParser = handler.hashParser;
    const templateParser = handler.templateParser;
    const content = args.content;
    const fragmentHook = (fragmentIdentifier) => {
        const fragment = content.fragments[fragmentIdentifier];
        return fragment?.html;
    };
    const onRendered = (identifier) => {
        if (identifier == null) {
            renderedRoot = true;
        }
        else {
            rendered.push(identifier);
        }
    };
    const integration = {
        iri: args.iri,
        method: args.method,
        contentType: args.contentType,
        text(hash) {
            if (hash == null)
                return;
            if (!cache.has(hash)) {
                cacheFragment(hash, hashParser, templateParser, fragmentHook, content, cache);
            }
            const fragment = cache.get(hash);
            if (fragment[1] !== 'text') {
                return;
            }
            return fragment[2];
        },
        render(hash) {
            if (hash == null) {
                if (Array.isArray(root)) {
                    return m(FragmentRenderer, {
                        fragment: root,
                        onRendered,
                    });
                }
                else if (args.content.root == null) {
                    return;
                }
                root = [undefined, undefined, args.content.root, args.content.dom];
                return m(FragmentRenderer, {
                    fragment: root,
                    onRendered,
                });
            }
            if (!cache.has(hash)) {
                cacheFragment(hash, hashParser, templateParser, fragmentHook, content, cache);
            }
            const fragment = cache.get(hash);
            if (fragment == null)
                return;
            return m(FragmentRenderer, {
                fragment,
                onRendered,
            });
        },
        getStateInfo() {
            const text = {};
            const fragments = [];
            const entries = Object.values(content.fragments);
            for (let i = 0, l = entries.length; i < l; i++) {
                if (entries[i].type === 'text') {
                    text[entries[i].id] = entries[i].html;
                }
                else {
                    fragments.push({
                        id: entries[i].id,
                        type: entries[i].type,
                        selector: entries[i].selector,
                        rendered: rendered.includes(entries[i].id),
                    });
                }
            }
            return {
                iri: args.iri,
                method: args.method,
                contentType: args.contentType,
                integrationType: 'fragments',
                rendered: renderedRoot,
                selector: content.selector,
                templates: content.templates,
                text,
                fragments,
            };
        },
        toInitialState() {
            let html = '';
            const entries = Object.values(content.fragments);
            if (content.root != null && !renderedRoot) {
                html += `<template id="fragment:${args.iri}|${args.method}|${args.contentType}">${content.root}</template>\n`;
            }
            for (let i = 0, l = entries.length; i < l; i++) {
                if (entries[i].type === 'text') {
                    continue;
                }
                if (!rendered.includes(entries[i].id)) {
                    html += `<template data-fragment="${entries[i].id}">${entries[i].html}</template>\n`;
                }
            }
            return html;
        },
    };
    return Object.freeze(integration);
});
FragmentsIntegration.type = 'fragments';
FragmentsIntegration.fromInitialState = (stateInfo, handler) => {
    const content = Object.create(null);
    content.fragments = Object.create(null);
    content.templates = stateInfo.templates;
    if (stateInfo.selector != null && stateInfo.rendered) {
        const element = document.querySelector(stateInfo.selector);
        if (element != null) {
            content.root = element.outerHTML;
        }
    }
    else if (stateInfo.selector != null) {
        const template = document.getElementById(`fragment:${stateInfo.iri}|${stateInfo.contentType}`);
        content.root = template?.textContent;
    }
    const textEntries = Object.entries(stateInfo.text);
    for (let i = 0, l = textEntries.length; i < l; i++) {
        content.fragments[textEntries[i][0]] = {
            id: textEntries[i][0],
            type: 'text',
            html: textEntries[i][1],
        };
    }
    for (let i = 0, l = stateInfo.fragments.length; i < l; i++) {
        const fragment = stateInfo.fragments[i];
        if (fragment.rendered) {
            let element;
            switch (fragment.type) {
                case 'embed': {
                    element = document.getElementById(fragment.id);
                    if (element == null) {
                        break;
                    }
                    content.fragments[fragment.id] = {
                        id: fragment.id,
                        type: fragment.type,
                        dom: [element],
                        selector: fragment.selector,
                    };
                    break;
                }
                case 'bare': {
                    element = document.querySelector(fragment.selector);
                    if (element == null) {
                        break;
                    }
                    content.fragments[fragment.id] = {
                        id: fragment.id,
                        type: fragment.type,
                        dom: [element],
                        selector: fragment.selector,
                    };
                    break;
                }
                case 'range': {
                    const elements = document.querySelectorAll(fragment.selector);
                    content.fragments[fragment.id] = {
                        id: fragment.id,
                        type: fragment.type,
                        selector: fragment.selector,
                        dom: Array.from(elements),
                    };
                }
            }
        }
        else {
            const template = document.querySelector(`[data-fragment="${fragment.id}"]`);
            if (template == null) {
                continue;
            }
            content.fragments[fragment.id] = {
                id: fragment.id,
                type: fragment.type,
                dom: Array.from(template.content.children),
                selector: fragment.selector,
            };
        }
    }
    return FragmentsIntegration({
        iri: stateInfo.iri,
        method: stateInfo.method,
        contentType: stateInfo.contentType,
        content,
    }, handler);
};
Object.freeze(FragmentsIntegration);

const UnrecognisedIntegration = ((args) => {
    const integration = {
        iri: args.iri,
        method: args.method,
        contentType: args.contentType,
        getStateInfo() {
            return {
                iri: args.iri,
                method: args.method,
                contentType: args.contentType,
            };
        },
    };
    return Object.freeze(integration);
});
UnrecognisedIntegration.type = 'unrecognised';
UnrecognisedIntegration.fromInitialState = UnrecognisedIntegration;

class HTTPFailure {
    #status;
    #res;
    constructor(status, res) {
        this.#status = status;
        this.#res = res;
    }
    get status() {
        return this.#status;
    }
    get res() {
        return this.#res;
    }
    undefined() {
        return null;
    }
    http(arg) {
        if (typeof arg === 'function') {
            return arg(this.#status);
        }
        return arg;
    }
    unparserable() {
        return null;
    }
}

/**
 * @description
 * Locates all IRI objects in a potentially deeply nested JSON-ld structure and
 * returns an array of the located IRI objects.
 *
 * Objects identified as IRI objects are not modified beyond being placed in
 * an array together.
 *
 * @param value - The value to flatten.
 * @param agg - An array to fill with the flattened IRI objects.
 *              This is required for the internal recursing performed by this
 *              function and isn't required by upstream callers.
 */
function flattenIRIObjects(value, agg = []) {
    if (Array.isArray(value) || isJSONObject(value)) {
        Object.freeze(value);
    }
    if (Array.isArray(value)) {
        for (const item of value) {
            flattenIRIObjects(item, agg);
        }
    }
    else if (isJSONObject(value)) {
        if (isMetadataObject(value)) {
            return agg;
        }
        if (isIRIObject(value)) {
            agg.push(value);
        }
        if (isValueObject(value)) {
            flattenIRIObjects(value['@value'], agg);
        }
        else if (isIterable(value)) {
            flattenIRIObjects(getIterableValue(value), agg);
        }
        else {
            for (const [term, item] of Object.entries(value)) {
                if (term.startsWith('@')) {
                    continue;
                }
                flattenIRIObjects(item, agg);
            }
        }
    }
    return agg;
}

/**
 * The accept header used for requests by the store if none is provided.
 */
const defaultAccept = 'application/problem+json, application/ld+json';
/**
 * Integration factories.
 */
const integrations = {
    unrecognised: UnrecognisedIntegration,
    element: ElementIntegration,
    fragments: FragmentsIntegration,
};
/**
 * The accept key is used to locate the last content type
 * value that was returned for an equivalent request.
 *
 * For Octiron an equivalent request is one that has
 * the same method, IRI (less the fragment) and accept header value.
 *
 * TODO: Determine handling of requests with bodies.
 */
function makeContentTypeKey(iri, args) {
    let url = new URL(iri);
    url.hash = '';
    url = url.toString();
    const method = args?.method?.toLowerCase() ?? 'get';
    const accept = args?.accept ?? '';
    return `${method}|${url}|${accept}`;
}
/**
 * Creates the primary key as well as the content type key since
 * they are often used together if the primary key is used.
 *
 * The primary cache is shared by JSONLD content types (theoretically
 * including any RDF type if one wanted to used them) and the problem
 * detail types. The primary cache is not varied by content type since
 * it should either have a current JSONLD equiv state (this could be
 * an bad response) or hold problem details (which should be a bad
 * response).
 *
 * TODO: Redesign the sharing of the primary cache for JSONLD and
 * problem details responses. Bad alternative responses would cause
 * overwrites on JSONLD responses, even if they were for an
 * incompatible content type.
 */
function makePrimaryKey(iri, args) {
    let url = new URL(iri);
    url.hash = '';
    url = url.toString();
    const method = args?.method?.toLowerCase() ?? 'get';
    const accept = args?.accept ?? defaultAccept;
    const primaryKey = `${method}|${url}`;
    return [
        primaryKey,
        `${primaryKey}|${accept}`,
        url,
    ];
}
/**
 * The alternative type key is used to locate a entity state from
 * the alternative cache.
 */
function makeAlternativeKey(iri, contentType, args) {
    let url = new URL(iri);
    url.hash = '';
    url = url.toString();
    const method = args?.method?.toLowerCase() ?? 'get';
    return `${method}|${url}|${contentType ?? ''}`;
}
/**
 * Creates a function that cleans up when a listener unsubscribes.
 */
function makeCleanupFn(key, details, primary, dependencies, listeners) {
    return () => {
        listeners.delete(key);
        for (const dependency of details.dependencies) {
            const normalizedURL = new URL(dependency).toString();
            dependencies.delete(normalizedURL);
            if (isBrowserRender) {
                // TODO: Make this configurable and support deleting alternatives
                setTimeout(() => {
                    if (dependencies.get(normalizedURL)?.size === 0) {
                        const [primaryKey] = makePrimaryKey(dependency);
                        primary.delete(primaryKey);
                    }
                }, 5000);
            }
        }
    };
}
/**
 * Loops over all listeners registers against an entity,
 * calling them with an updated selection.
 */
function publish(normalizedURL, contentType, contentTypeKey, acceptMap, primary, dependencies, listeners, store) {
    const keys = dependencies.get(normalizedURL);
    if (keys == null) {
        return;
    }
    for (const key of keys) {
        const listenerDetails = listeners.get(key);
        if (listenerDetails == null) {
            continue;
        }
        const mappedType = acceptMap.get(contentTypeKey);
        // TODO: A more sophisticated check might be required 
        // to correctly check the content type matches the
        // listener's accept header
        // TODO: Review this is required. The accept map should be
        // source of truth.
        if (contentType !== mappedType)
            continue;
        const details = getSelection({
            selector: listenerDetails.selector,
            value: listenerDetails.value,
            fragment: listenerDetails.fragment,
            accept: listenerDetails.accept,
            store,
        });
        const cleanup = makeCleanupFn(key, details, primary, dependencies, listeners);
        for (const dependency of details.dependencies) {
            const normalizedURL = new URL(dependency).toString();
            let depSet = dependencies.get(normalizedURL);
            if (depSet == null) {
                depSet = new Set([key]);
                dependencies.set(normalizedURL, depSet);
            }
            else {
                depSet.add(key);
            }
        }
        listenerDetails.cleanup = cleanup;
        listenerDetails.listener(details);
    }
}
function handleJSONLD(res, content, normalizedURL, contentType, contentTypeKey, primaryKey, acceptMap, primary, dependencies, listeners, store) {
    const iris = [normalizedURL];
    if (res.ok) {
        primary.set(primaryKey, {
            type: 'entity-success',
            iri: normalizedURL,
            fragment: undefined,
            loading: false,
            ok: true,
            contentType,
            integrationType: 'jsonld',
            value: content,
            isProblem: false,
        });
    }
    else {
        const reason = new HTTPFailure(res.status, res);
        primary.set(primaryKey, {
            type: 'entity-failure',
            iri: normalizedURL,
            loading: false,
            ok: false,
            value: content,
            contentType,
            integrationType: 'jsonld',
            status: res.status,
            isProblem: false,
            reason,
        });
    }
    for (const entity of flattenIRIObjects(content)) {
        const [primaryKey, , normalizedURL] = makePrimaryKey(entity['@id']);
        if (iris.includes(normalizedURL)) {
            continue;
        }
        primary.set(primaryKey, {
            type: 'entity-success',
            iri: normalizedURL,
            fragment: undefined,
            loading: false,
            ok: true,
            value: entity,
            contentType,
            integrationType: 'jsonld',
            isProblem: false,
        });
    }
    for (const iri of iris) {
        publish(iri, contentType, contentTypeKey, acceptMap, primary, dependencies, listeners, store);
    }
}
/**
 * Handles a resolved response object, parsing the content and
 * caching the results in the correct store.
 *
 * TODO: Support responses with no content / no content-type.
 */
async function handleResponse(res, method, normalizedURL, contentTypeKey, primaryKey, handlers, acceptMap, primary, alternatives, dependencies, listeners, store, args) {
    const contentType = res.headers.get('Content-Type')?.split?.(';')?.[0];
    const etag = res.headers.get('Etag');
    if (contentType == null) {
        throw new Error('Content type not specified in response');
    }
    const handler = handlers.get(contentType);
    const alternativeKey = makeAlternativeKey(normalizedURL, contentType, args);
    if (handler?.integrationType === 'jsonld') {
        const content = await handler.handler({
            res,
        });
        handleJSONLD(res, content, normalizedURL, contentType, contentTypeKey, primaryKey, acceptMap, primary, dependencies, listeners, store);
    }
    else {
        const content = await handler.handler({
            res,
        });
        const integration = integrations[handler?.integrationType ?? 'unrecognised']({
            iri: normalizedURL,
            method,
            contentType,
            content,
        }, handler);
        alternatives.set(alternativeKey, {
            type: 'alternative-success',
            ok: res.ok,
            status: res.status,
            iri: normalizedURL,
            contentType,
            integrationType: handler?.integrationType ?? 'unrecognised',
            isProblem: false,
            etag,
            integration,
        });
        publish(normalizedURL, contentType, contentTypeKey, acceptMap, primary, dependencies, listeners, store);
    }
}
async function performFetch(iri, args, rootOrigin, headers, origins, inflight, fetcher, handlers, acceptMap, primary, alternatives, dependencies, listeners, responseHook, store) {
    let status;
    const url = new URL(iri);
    const method = args?.method || 'get';
    const accept = args?.accept ?? headers.get('Accept') ?? defaultAccept;
    const [primaryKey, contentTypeKey, normalizedURL] = makePrimaryKey(iri, {
        method,
        accept,
    });
    if (inflight.has(contentTypeKey)) {
        return;
    }
    if (url.origin === rootOrigin) {
        headers = new Headers(headers);
    }
    else if (origins.has(url.origin)) {
        headers = new Headers(origins.get(url.origin));
    }
    else {
        throw new Error(`Un-configured origin "${url.origin}"`);
    }
    headers.set('Accept', accept);
    if (args?.body != null && args?.contentType != null) {
        headers.set('Content-Type', args.contentType);
    }
    inflight.add(contentTypeKey);
    mithrilRedraw();
    // This promise wrapping is so SSR can hook in and await the promise.
    const promise = new Promise(async (resolve) => {
        let res;
        if (fetcher != null) {
            res = await fetcher(normalizedURL, {
                method,
                headers,
                body: args?.body,
            });
        }
        else {
            res = await fetch(normalizedURL, {
                method,
                headers,
                body: args?.body,
            });
        }
        const contentType = res.headers.get('Content-Type');
        acceptMap.set(contentTypeKey, contentType);
        // Loading state must be reset before handling responses.
        inflight.delete(contentTypeKey);
        await handleResponse(res, method, normalizedURL, contentTypeKey, primaryKey, handlers, acceptMap, primary, alternatives, dependencies, listeners, store, args);
        mithrilRedraw();
        resolve(res);
    });
    if (responseHook != null) {
        responseHook(promise);
    }
    await promise;
    return status;
}
const makeStore = ((args) => {
    let status;
    const rootIRI = args.rootIRI;
    const rootOrigin = new URL(rootIRI).origin;
    const headers = new Headers(args.headers);
    const vocab = args.vocab;
    const aliases = Object.create(null);
    const context = Object.create(null);
    const termExpansions = new Map();
    const fetcher = args.fetcher ?? fetch;
    const origins = args.origins ?? Object.create(null);
    const handlers = new Map();
    /**
     * The primary cache behaves differently to the alternatives.
     * JSONLD is a concrete implementation of RDF. In theory other
     * RDF implementations can map to JSONLD, and Octiron can
     * in theory be configured to have them use the JSONLD integration
     * type push their representations into the primary cache as an
     * alternative to JSONLD. The primary cache COULD be used as a cache
     * for all RDF media-types, but their handlers would have to parse
     * their content into the JSONLD data model for that to work.
     */
    const primary = new Map(args.primary);
    /**
     * The alternatives cache.
     * This stores all non-JSONLD equiv content types.
     */
    const alternatives = new Map(args.alternatives);
    // Set of accept keys which currently have requests inflight.
    const inflight = new Set();
    // Maps the accept key to the resolved content type
    // of the last response for that representation.
    const acceptMap = new Map(args.acceptMap);
    // Content types that are used in the primary store.
    // Typically this will be JSONLD compat types.
    const primaryContentTypes = new Set();
    const dependencies = new Map();
    const listeners = new Map();
    const responseHook = args.responseHook;
    if (vocab != null) {
        context['@vocab'] = vocab;
    }
    if (args.aliases != null) {
        for (const [key, value] of Object.entries(args.aliases)) {
            aliases[key] = value;
            context[key] = value;
        }
    }
    if (args.origins != null) {
        for (const [origin, headers] of Object.entries(args.origins)) {
            origins.set(origin, new Headers(headers));
        }
    }
    if (args.handlers != null) {
        for (let i = 0, l = args.handlers.length; i < l; i++) {
            handlers.set(args.handlers[i].contentType, args.handlers[i]);
            if (args.handlers[i].integrationType === 'jsonld') {
                primaryContentTypes.add(args.handlers[i].contentType);
            }
        }
    }
    Object.freeze(aliases);
    Object.freeze(context);
    const store = {
        type: 'octiron-store',
        rootIRI,
        vocab,
        aliases,
        context,
        get status() {
            return status;
        },
        expand(termOrType) {
            const cached = termExpansions.get(termOrType);
            if (cached != null) {
                return cached;
            }
            let expanded;
            if (vocab != null && !/^[\w\d]+\:/.test(termOrType)) {
                expanded = vocab + termOrType;
            }
            else if (/https?:\/\//.test(termOrType)) {
                // is a type
                expanded = termOrType;
            }
            else {
                for (const [key, value] of Object.entries(aliases)) {
                    const reg = new RegExp(`^${key}:`);
                    if (reg.test(termOrType)) {
                        expanded = termOrType.replace(reg, value);
                        break;
                    }
                }
            }
            termExpansions.set(termOrType, expanded ?? termOrType);
            return expanded ?? termOrType;
        },
        inflight(iri, args) {
            return inflight.has(makeContentTypeKey(iri, args));
        },
        entity(iri, args) {
            const [primaryKey, contentTypeKey, normalizedURL,] = makePrimaryKey(iri, args);
            if (inflight.has(contentTypeKey)) {
                return {
                    type: 'entity-loading',
                    iri: normalizedURL,
                    loading: true,
                    isProblem: false,
                };
            }
            const contentType = acceptMap.get(contentTypeKey);
            if (contentType == null) {
                return;
            }
            else if (primaryContentTypes.has(contentType)) {
                return primary.get(primaryKey);
            }
            const alternativeKey = makeAlternativeKey(normalizedURL, contentType, args);
            return alternatives.get(alternativeKey);
        },
        text(iri, args) {
            const [key, fragment] = iri.toString().split('#');
            const entity = this.entity(key, args);
            if (entity == null ||
                entity.type !== 'alternative-success' ||
                entity.integration.text == null) {
                return;
            }
            return entity.integration.text(fragment);
        },
        select(selector, value, args) {
            return getSelection({
                selector: selector.toString(),
                value,
                accept: args?.accept,
                store: this,
            });
        },
        async fetch(iri, args) {
            const responseStatus = await performFetch(iri, args, rootOrigin, headers, origins, inflight, fetcher, handlers, acceptMap, primary, alternatives, dependencies, listeners, responseHook, store);
            if (args?.mainEntity &&
                !isBrowserRender &&
                (status == null || status < 400) &&
                (responseStatus < 300 || responseStatus <= 400)) {
                status = responseStatus;
            }
            return this.entity(iri, args);
        },
        async submit(iri, args) {
            const url = new URL(iri);
            args.fragment = url.hash === '' ? undefined : url.hash.substring(1, url.hash.length);
            const responseStatus = await performFetch(iri, args, rootOrigin, headers, origins, inflight, fetcher, handlers, acceptMap, primary, alternatives, dependencies, listeners, responseHook, store);
            if (args?.mainEntity &&
                !isBrowserRender &&
                (status == null || status < 400) &&
                (responseStatus < 300 || responseStatus <= 400)) {
                // if SSR store the first 400+ status for the final HTTP response
                status = responseStatus;
            }
            const loading = this.inflight(iri, args);
            if (loading && !isBrowserRender) {
                const key = Symbol();
                const { promise, resolve } = Promise.withResolvers();
                this.subscribe({
                    key,
                    selector: iri.toString(),
                    // fragment,
                    accept: args.accept,
                    listener: () => {
                        this.unsubscribe(key);
                        resolve(this.entity(iri, args));
                    }
                });
                return promise;
            }
            return this.entity(iri, args);
        },
        subscribe(args) {
            const selector = args.selector.toString();
            const details = getSelection({
                selector,
                value: args.value,
                accept: args.accept,
                fragment: args.fragment,
                store,
            });
            const cleanup = makeCleanupFn(args.key, details, primary, dependencies, listeners);
            for (const dependency of details.dependencies) {
                const normalizedURL = new URL(dependency).toString();
                const depSet = dependencies.get(normalizedURL);
                if (depSet == null) {
                    dependencies.set(normalizedURL, new Set([args.key]));
                }
                else {
                    depSet.add(args.key);
                }
            }
            listeners.set(args.key, {
                selector,
                key: args.key,
                value: args.value,
                fragment: args.fragment,
                accept: args.accept,
                required: details.required,
                dependencies: details.dependencies,
                listener: args.listener,
                cleanup,
            });
            // If this is the main entity and the details has
            // missing deps simulate a 404 if no other bad
            // status code has been set
            if (!isBrowserRender &&
                args.mainEntity &&
                details.hasMissing &&
                status < 400) {
                status = 404;
            }
            return details;
        },
        unsubscribe(key) {
            listeners.get(key)?.cleanup();
        },
        toInitialState() {
            const initialState = [
                Array.from(acceptMap.entries()),
                Array.from(primary.entries()),
                Array.from(alternatives.entries())
                    .map(([contentTypeKey, alternative]) => {
                    const stateInfo = alternative.integration.getStateInfo();
                    delete alternative.integration;
                    return [contentTypeKey, alternative, stateInfo];
                }),
            ];
            return `<script id="oct-state" type="application/json">${JSON.stringify(initialState)}</script>`;
        },
    };
    return Object.freeze(store);
});
makeStore.fromInitialState = ({ rootIRI, vocab, aliases, headers, origins, handlers, enableLogs, }) => {
    performance.mark('octiron:from-initial-state:start');
    const storeArgs = {
        rootIRI,
        vocab,
        aliases,
        handlers,
        headers,
        origins,
    };
    try {
        let initialState;
        const el = document.getElementById('oct-state');
        if (el == null) {
            if (enableLogs) {
                console.warn('Could not locate initial state');
            }
            return makeStore(storeArgs);
        }
        try {
            initialState = JSON.parse(el.innerText);
        }
        catch {
            if (enableLogs) {
                console.warn('Failed to construct store from initial state');
                console.info(el);
            }
            return makeStore(storeArgs);
        }
        if (!Array.isArray(initialState) ||
            initialState.length !== 3) {
            if (enableLogs) {
                console.warn('Invalid initial state');
                console.info(el);
                console.info(initialState);
            }
            return makeStore(storeArgs);
        }
        const stateInfo = JSON.parse(el.innerText);
        const alternatives = [];
        const handlersMap = handlers.reduce((acc, handler) => {
            acc[handler.contentType] = handler;
            return acc;
        }, {});
        for (let i = 0, l = stateInfo[2].length; i < l; i++) {
            const [contentTypeKey, alternative, altInfo] = stateInfo[2][i];
            const factory = integrations[altInfo.integrationType];
            const handler = handlersMap[altInfo.contentType];
            if (factory == null)
                continue;
            alternative.integration = factory.fromInitialState(altInfo, handler);
            alternatives.push([contentTypeKey, alternative]);
        }
        const store = makeStore({
            ...storeArgs,
            alternatives,
            acceptMap: stateInfo[0],
            primary: stateInfo[1],
        });
        performance.mark('octiron:from-initial-state:end');
        performance.measure('octiron:from-initial-state:duration', 'octiron:from-initial-state:start', 'octiron:from-initial-state:end');
        return store;
    }
    catch (err) {
        if (enableLogs) {
            console.warn('Failed to construct Octiron state from initial state');
            console.error(err);
        }
        const store = makeStore(storeArgs);
        performance.mark('octiron:from-initial-state:end');
        performance.measure('octiron:from-initial-state:duration', 'octiron:from-initial-state:start', 'octiron:from-initial-state:end');
        return store;
    }
};

/**
 * Merges arguments into a single css class string
 */
function classes(...classArgs) {
    const cls = [];
    for (const classArg of classArgs) {
        if (typeof classArg === 'undefined' || classArg === null) {
            continue;
        }
        else if (typeof classArg === 'string') {
            cls.push(classArg);
        }
        else if (Array.isArray(classArg)) {
            for (const name of classArg) {
                cls.push(name);
            }
        }
        else {
            for (const [name, active] of Object.entries(classArg)) {
                if (active) {
                    cls.push(name);
                }
            }
        }
    }
    return cls.join(' ');
}

/**
 * @description
 * Utility for creating a well typed typeHandler.
 *
 * @param typeHandler An object to property define the types for.
 */
function makeTypeHandler(typeHandler) {
    return typeHandler;
}

let store;
const makeJSONLDHandler = (args) => {
    if (args?.store != null) {
        store = args.store;
    }
    return {
        integrationType: 'jsonld',
        contentType: 'application/ld+json',
        handler: async ({ res }) => {
            const { expand, JSONLDContextStore } = await import('@occultist/mini-jsonld');
            if (store == undefined) {
                store = new JSONLDContextStore({ cacheMethod: 'cache' });
            }
            const json = await res.json();
            return expand(json, { store, url: res.url });
        },
    };
};

const longformHandler = {
    integrationType: 'fragments',
    contentType: 'text/longform',
    handler: async ({ res }) => {
        const { longform } = await import('@longform/longform');
        return longform(await res.text());
    },
    hashParser(hash) {
        const [identifier, templateArgs] = hash.split('?');
        if (templateArgs == null) {
            return {
                identifier,
            };
        }
        return {
            identifier,
            args: Object.fromEntries(new URLSearchParams(templateArgs).entries()),
        };
    },
};

const problemDetailsJSONHandler = {
    integrationType: 'problem-details',
    contentType: 'application/problem+json',
    handler: async ({ res }) => {
        return res.json();
    },
};

const OctironJSON = () => {
    function renderIRI(iri) {
        return m('code', [
            m('span.oct-json-quote', '"'),
            m('a.oct-json-iri', {
                href: iri,
            }, iri),
            m('span.oct-json-quote', '"'),
        ]);
    }
    function renderPrimitive(value) {
        const className = typeof value === 'boolean'
            ? 'oct-json-boolean'
            : typeof value === 'number'
                ? 'oct-json-number'
                : 'oct-json-string';
        let presentValue;
        if (typeof value === 'boolean' && value) {
            presentValue = 'true';
        }
        else if (typeof value === 'boolean') ;
        else if (typeof value === 'string') {
            presentValue = [
                m('span.oct-json-quote', '"'),
                value,
                m('span.oct-json-quote', '"'),
            ];
        }
        else {
            presentValue = value;
        }
        return m('code', { className }, presentValue);
    }
    function renderArray(list, url, selector = '') {
        const children = [];
        for (let index = 0; index < list.length; index++) {
            const value = list[index];
            children.push(m('li.oct-json-arr-item', maybeRenderDetails(null, value, url, selector)));
        }
        return m('ul.oct-json-arr', children);
    }
    const terminalTypes = ['@id', '@type', '@context'];
    function renderObject(value, url, selector = '') {
        const items = [];
        const list = Object.entries(value);
        list.sort();
        for (let index = 0; index < list.length; index++) {
            const [term, value] = list[index];
            let children;
            const summary = [
                m('span.oct-json-quote', '"'),
                m('span.oct-json-obj-key', term),
                m('span.oct-json-quote', '"'),
                m('span.oct-json-obj-colon', ': '),
            ];
            if (term === '@id') {
                children = [m('code', summary), renderIRI(value)];
            }
            else if (url == null || terminalTypes.includes(term)) {
                children = maybeRenderDetails(summary, value);
            }
            else if (term.startsWith('@')) {
                children = maybeRenderDetails(summary, value, url, selector);
            }
            else {
                const currentSelector = `${selector} ${term}`;
                const currentURL = new URL(url);
                currentURL.searchParams.set('selector', currentSelector);
                const summary = [
                    m('span.oct-json-quote', '"'),
                    m('span.oct-json-obj-key', m('a', { href: currentURL }, term)),
                    m('span.oct-json-quote', '"'),
                    m('span.oct-json-obj-colon', ': '),
                ];
                children = maybeRenderDetails(summary, value, url, currentSelector);
            }
            items.push(m('li.oct-json-obj-item', children));
        }
        return m('ul.oct-json-obj', items);
    }
    function maybeRenderDetails(summary, value, url, selector = '') {
        if (isJSONObject(value)) {
            return [
                m('details.oct-json-details', { open: true }, m('summary.oct-json-details-sum', m('code', summary, m('span.oct-json-obj-open', '{'))), renderValue(value, url, selector)),
                m('code.oct-json-obj-close', '}'),
            ];
        }
        else if (Array.isArray(value)) {
            return [
                m('details.oct-json-details', { open: true }, m('summary.oct-json-details-sum', m('code', summary, m('span.oct-json-obj-open', '['))), renderValue(value, url, selector)),
                m('code.oct-json-obj-close', ']'),
            ];
        }
        return [m('code', summary), renderValue(value, url, selector)];
    }
    function renderValue(value, url, selector = '') {
        if (isJSONObject(value)) {
            return renderObject(value, url, selector);
        }
        else if (Array.isArray(value)) {
            return renderArray(value, url, selector);
        }
        return renderPrimitive(value);
    }
    return {
        view: ({ attrs: { value, selector, location } }) => {
            const url = location != null ? new URL(location) : undefined;
            return m('.oct-json', [
                maybeRenderDetails(null, value, url, typeof selector === 'string' ? selector.trim() : undefined),
            ]);
        },
    };
};

const OctironDebug = ({ attrs, }) => {
    let currentAttrs = attrs;
    let value = attrs.o.value;
    let rendered;
    let presentationStyle = attrs.initialPresentationStyle ?? 'value';
    function onRender(redraw = true) {
        const { o } = currentAttrs;
        if (presentationStyle === 'value') {
            rendered = m(OctironJSON, {
                value,
                selector: currentAttrs.selector,
                location: currentAttrs.location,
            });
        }
        else if (presentationStyle === 'action-value' && (o.octironType === 'action' ||
            o.octironType === 'action-selection')) {
            rendered = m(OctironJSON, { value: o.actionValue.value, selector: currentAttrs.selector, location: currentAttrs.location });
        }
        if (redraw) {
            mithrilRedraw();
        }
    }
    function onSetValue(e) {
        e.redraw = false;
        presentationStyle = 'value';
        onRender();
    }
    function onSetActionValue(e) {
        e.redraw = false;
        presentationStyle = 'action-value';
        onRender();
    }
    function onSetComponent(e) {
        e.redraw = false;
        presentationStyle = 'component';
        onRender();
    }
    return {
        oninit: ({ attrs }) => {
            currentAttrs = attrs;
            onRender(false);
        },
        onbeforeupdate: ({ attrs }) => {
            if (attrs.o.value !== value) {
                value = attrs.o.value;
                onRender(true);
            }
        },
        view: ({ attrs: { o, availableControls } }) => {
            let children;
            let actionValueAction;
            const controls = [];
            if (presentationStyle === 'component') {
                children = m('.oct-debug-body', o.default());
            }
            else {
                children = m('.oct-debug-body', rendered);
            }
            if (o.octironType === 'action' || o.octironType === 'action-selection') {
                actionValueAction = m('button.oct-button', { type: 'button', onclick: onSetActionValue }, 'Action value');
            }
            if (availableControls == null || availableControls.includes('value')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: onSetValue }, 'Value'));
            }
            else if (actionValueAction != null && (availableControls == null ||
                availableControls.includes('action-value'))) {
                controls.push(actionValueAction);
            }
            else if (availableControls == null || availableControls.includes('component')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: onSetComponent }, 'Component'));
            }
            else if (availableControls == null || availableControls.includes('log')) {
                controls.push(m('button.oct-button', { type: 'button', onclick: () => console.debug(o) }, 'Log'));
            }
            return m('aside.oct-debug', m('.oct-debug-controls', m('.oct-button-group', ...controls)), children);
        },
    };
};
const Debug = {
    view: ({ attrs: { o } }) => {
        return m(OctironDebug, { o });
    },
};

const OctironExplorer = ({ attrs, }) => {
    let value = attrs.selector || '';
    let previousSelector = value;
    let selector = value;
    let presentationStyle = 'value';
    let onChange = attrs.onChange;
    const fallbackComponent = {
        view: ({ attrs: { o } }) => {
            return m(OctironDebug, { o, location: attrs.location });
        },
    };
    function onSearch(evt) {
        value = evt.target.value;
    }
    function onEnter(evt) {
        if (evt.key === 'Enter') {
            onApply();
        }
    }
    function onApply() {
        selector = value;
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    function onSetValue(evt) {
        evt.preventDefault();
        presentationStyle = 'value';
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    function onSetActionValue(evt) {
        evt.preventDefault();
        presentationStyle = 'action-value';
        if (typeof onChange === 'function') {
            onChange(selector, presentationStyle);
        }
    }
    return {
        oninit: ({ attrs }) => {
            onChange = attrs.onChange;
        },
        onbeforeupdate: ({ attrs }) => {
            selector = attrs.selector ?? '';
            if (selector !== previousSelector) {
                value = previousSelector = selector;
            }
            onChange = attrs.onChange;
        },
        view: ({ attrs: { autofocus, o } }) => {
            let children;
            let upURL;
            let valueURL;
            let actionValueURL;
            if (selector.length !== 0 && presentationStyle === 'value') {
                children = o.root(selector, (o) => m(OctironDebug, {
                    o,
                    selector,
                    location: attrs.location,
                    initialPresentationStyle: attrs.presentationStyle,
                    availableControls: !!attrs.childControls == false ? undefined : [],
                }));
            }
            else if (selector.length !== 0) {
                children = o.root(selector, (o) => m('div', o.default({ fallbackComponent, attrs: { selector } })));
            }
            else if (presentationStyle === 'value') {
                children = o.root((o) => m(OctironDebug, {
                    o,
                    selector,
                    location: attrs.location,
                    initialPresentationStyle: attrs.presentationStyle,
                    availableControls: !!attrs.childControls ? undefined : [],
                }));
            }
            else {
                children = o.root((o) => m('div', o.default({ fallbackComponent, attrs: { selector } })));
            }
            if (attrs.location != null && selector.length !== 0) {
                const upSelector = attrs.selector.trim().includes(' ')
                    ? attrs.selector.replace(/\s+([^\s]+)$/, '')
                    : '';
                upURL = new URL(attrs.location);
                if (upSelector != null) {
                    upURL.searchParams.set('selector', upSelector);
                }
                else {
                    upURL.searchParams.delete('selector');
                }
            }
            if (attrs.location != null) {
                valueURL = new URL(attrs.location);
                actionValueURL = new URL(attrs.location);
                valueURL.searchParams.set('presentationStyle', 'value');
                actionValueURL.searchParams.set('presentationStyle', 'action-value');
            }
            return m('.oct-explorer', m('.oct-explorer-controls', m('form.oct-form-group', {
                action: attrs.location?.toString?.(),
                onsubmit: (evt) => {
                    evt.preventDefault();
                    onApply();
                },
            }, [
                upURL != null
                    ? m('a.oct-button', { href: upURL.toString() }, 'Up')
                    : m('button.oct-button', { type: 'button', disabled: true }, 'Up'),
                m('input', {
                    name: 'selector',
                    value,
                    autofocus,
                    oninput: onSearch,
                    onkeypress: onEnter,
                }),
                m('button.oct-button', {
                    type: 'submit',
                    disabled: selector === value && typeof window !== 'undefined',
                }, 'Apply'),
            ]), m('.oct-button-group', presentationStyle === 'value' || valueURL == null
                ? m('button.oct-button', {
                    type: 'button',
                    disabled: typeof window === 'undefined',
                    onclick: onSetValue,
                }, 'Value')
                : m('a.oct-button', {
                    href: valueURL.toString(),
                    onclick: onSetValue,
                }, 'Value'), presentationStyle === 'action-value' || actionValueURL == null
                ? m('button.oct-button', {
                    type: 'button',
                    disabled: typeof window === 'undefined',
                    onclick: onSetActionValue,
                }, 'Action value')
                : m('a.oct-button', {
                    href: actionValueURL.toString(),
                    onclick: onSetActionValue,
                }, 'Action value'))), m('pre.oct-explorer-body', children));
        },
    };
};

const OctironForm = (vnode) => {
    const o = vnode.attrs.o;
    const method = o.method?.toUpperCase() || 'POST';
    const enctypes = {
        GET: 'application/x-www-form-urlencoded',
        POST: 'multipart/form-data',
    };
    return {
        view: ({ attrs: { o, ...attrs }, children }) => {
            return m('form.oct-form', {
                ...attrs,
                method,
                enctype: enctypes[method],
                action: o.url,
                onsubmit: (evt) => {
                    evt.preventDefault();
                    o.submit();
                },
            }, children);
        },
    };
};

const OctironSubmitButton = () => {
    return {
        view: ({ attrs, children }) => {
            return m('button.oct-button.oct-submit-button', {
                id: attrs.id,
                type: 'submit',
                class: classes(attrs.class),
            }, children);
        },
    };
};

/**
 * Creates a root octiron instance.
 */
function octiron({ typeHandlers, ...storeArgs }) {
    const store = makeStore(storeArgs);
    const config = typeHandlers != null
        ? makeTypeHandlers(store, ...typeHandlers)
        : {};
    return rootFactory({
        store,
        typeHandlers: config,
    })[0];
}
octiron.fromInitialState = ({ typeHandlers, ...storeArgs }) => {
    const store = makeStore.fromInitialState({
        ...storeArgs,
    });
    const config = typeHandlers != null
        ? makeTypeHandlers(store, ...typeHandlers)
        : {};
    return rootFactory({
        store,
        typeHandlers: config,
    })[0];
};

export { Debug, OctironDebug, OctironExplorer, OctironForm, OctironJSON, OctironSubmitButton, classes, longformHandler, makeJSONLDHandler, makeTypeHandler, makeTypeHandlers, octiron, problemDetailsJSONHandler };
//# sourceMappingURL=octiron.js.map
